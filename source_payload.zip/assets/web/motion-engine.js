/* ==========================================================================
   KisiKit Motion Engine - GSAP + ScrollTrigger + Motion + Lenis
   ========================================================================== */
(() => {
  const reducedMotion =
    window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const hasGsap = typeof window.gsap !== "undefined";
  const hasScrollTrigger = typeof window.ScrollTrigger !== "undefined";
  const hasLenis = typeof window.Lenis !== "undefined";
  const hasMotion =
    typeof window.Motion !== "undefined" && typeof window.Motion.animate === "function";

  if (hasGsap && hasScrollTrigger) {
    window.gsap.registerPlugin(window.ScrollTrigger);
  }

  let lenis = null;
  const scopedTriggers = new Map();

  function initLenis() {
    if (!hasLenis || reducedMotion) return;
    try {
      lenis = new window.Lenis({
        lerp: 0.1,
        duration: 1.05,
        smoothWheel: true,
        wheelMultiplier: 1,
        touchMultiplier: 1.35,
        autoRaf: false,
      });

      if (hasGsap && hasScrollTrigger) {
        lenis.on("scroll", window.ScrollTrigger.update);
        window.gsap.ticker.add((time) => {
          lenis.raf(time * 1000);
        });
        window.gsap.ticker.lagSmoothing(0);
      } else {
        const raf = (time) => {
          lenis.raf(time);
          requestAnimationFrame(raf);
        };
        requestAnimationFrame(raf);
      }
    } catch (e) {
      lenis = null;
    }
  }

  function clearScope(scope) {
    const list = scopedTriggers.get(scope);
    if (Array.isArray(list)) {
      list.forEach((st) => {
        try {
          st.kill();
        } catch (e) {}
      });
    }
    scopedTriggers.set(scope, []);
  }

  function trackTrigger(scope, st) {
    if (!st) return;
    if (!scopedTriggers.has(scope)) scopedTriggers.set(scope, []);
    scopedTriggers.get(scope).push(st);
  }

  function refreshScroll() {
    if (lenis) {
      try {
        lenis.resize();
      } catch (e) {}
    }
    if (hasScrollTrigger) {
      requestAnimationFrame(() => {
        try {
          window.ScrollTrigger.refresh();
        } catch (e) {}
      });
    }
  }

  function scrollToTop(instant = false) {
    if (lenis && !reducedMotion) {
      lenis.scrollTo(0, { immediate: instant, duration: instant ? 0 : 0.6 });
    } else {
      window.scrollTo({ top: 0, behavior: instant || reducedMotion ? "auto" : "smooth" });
    }
  }

  function lockScroll() {
    if (lenis) lenis.stop();
    document.body.style.overflow = "hidden";
  }

  function unlockScroll() {
    if (lenis) lenis.start();
    document.body.style.overflow = "";
  }

  /* ------------------------------------------------------------------------
     GSAP: Home View Entrance Choreography
     ------------------------------------------------------------------------ */
  function animateHome() {
    if (reducedMotion || !hasGsap) return;
    const gsap = window.gsap;
    const heroItems = document.querySelectorAll(
      "#homeView .hero-title, #homeView .hero-sub, #homeView .feature-pill"
    );
    const layoutCards = document.querySelectorAll("#homeView .home-layout > *");

    if (heroItems.length) {
      gsap.killTweensOf(heroItems);
      gsap.fromTo(
        heroItems,
        { opacity: 0, y: 18 },
        {
          opacity: 1,
          y: 0,
          duration: 0.55,
          stagger: 0.06,
          ease: "power3.out",
          clearProps: "transform,opacity",
        }
      );
    }

    if (layoutCards.length) {
      gsap.killTweensOf(layoutCards);
      gsap.fromTo(
        layoutCards,
        { opacity: 0, y: 22 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          delay: 0.14,
          stagger: 0.09,
          ease: "power3.out",
          clearProps: "transform,opacity",
        }
      );
    }

    refreshScroll();
  }

  /* ------------------------------------------------------------------------
     GSAP: Generic View / Tab Panel Entrance
     ------------------------------------------------------------------------ */
  function animatePanel(el) {
    if (!el || reducedMotion || !hasGsap) return;
    window.gsap.killTweensOf(el);
    window.gsap.fromTo(
      el,
      { opacity: 0, y: 12 },
      {
        opacity: 1,
        y: 0,
        duration: 0.36,
        ease: "power3.out",
        clearProps: "transform,opacity",
      }
    );
    refreshScroll();
  }

  /* ------------------------------------------------------------------------
     GSAP + ScrollTrigger: Material Reading Panel Reveals
     ------------------------------------------------------------------------ */
  function animateMaterial() {
    clearScope("material");
    if (reducedMotion || !hasGsap) return;
    const gsap = window.gsap;

    const tldr = document.querySelector("#materialPanel .tldr-card");
    if (tldr) {
      gsap.fromTo(
        tldr,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 0.48,
          ease: "power3.out",
          clearProps: "transform,opacity",
        }
      );
    }

    if (!hasScrollTrigger) return;

    const topicCards = gsap.utils.toArray("#materialSections .topic-card");
    topicCards.forEach((card, i) => {
      const tween = gsap.fromTo(
        card,
        { opacity: 0, y: 24 },
        {
          opacity: 1,
          y: 0,
          duration: 0.52,
          delay: i < 2 ? i * 0.06 : 0,
          ease: "power3.out",
          clearProps: "transform,opacity",
          scrollTrigger: {
            trigger: card,
            start: "top 90%",
            once: true,
          },
        }
      );
      trackTrigger("material", tween.scrollTrigger);
    });

    const cheatWrap = document.getElementById("cheatSheetWrap");
    if (cheatWrap && !cheatWrap.classList.contains("hidden")) {
      const cheatItems = cheatWrap.querySelectorAll(".cheat-item");
      const tween = gsap.fromTo(
        cheatWrap,
        { opacity: 0, y: 22 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: "power3.out",
          clearProps: "transform,opacity",
          scrollTrigger: {
            trigger: cheatWrap,
            start: "top 88%",
            once: true,
            onEnter: () => {
              if (cheatItems.length) {
                gsap.fromTo(
                  cheatItems,
                  { opacity: 0, y: 12 },
                  {
                    opacity: 1,
                    y: 0,
                    duration: 0.38,
                    stagger: 0.035,
                    ease: "power2.out",
                    clearProps: "transform,opacity",
                  }
                );
              }
            },
          },
        }
      );
      trackTrigger("material", tween.scrollTrigger);
    }

    const extraBlocks = gsap.utils.toArray(
      "#trapsWrap:not(.hidden), #materialPanel .cta-bar"
    );
    extraBlocks.forEach((blk) => {
      const tween = gsap.fromTo(
        blk,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: "power3.out",
          clearProps: "transform,opacity",
          scrollTrigger: {
            trigger: blk,
            start: "top 90%",
            once: true,
          },
        }
      );
      trackTrigger("material", tween.scrollTrigger);
    });

    refreshScroll();
  }

  /* ------------------------------------------------------------------------
     GSAP + ScrollTrigger: Results Panel & Score Count-Up
     ------------------------------------------------------------------------ */
  function animateResults(finalScore) {
    clearScope("results");
    if (reducedMotion || !hasGsap) return;
    const gsap = window.gsap;

    const scoreHero = document.querySelector("#resultPanel .score-hero-card");
    if (scoreHero) {
      gsap.fromTo(
        scoreHero,
        { opacity: 0, y: 18, scale: 0.985 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.52,
          ease: "power3.out",
          clearProps: "transform,opacity",
        }
      );
    }

    const scoreEl = document.getElementById("resultTotalScore");
    const numericScore = Number(finalScore);
    if (scoreEl && Number.isFinite(numericScore)) {
      const counter = { val: 0 };
      gsap.to(counter, {
        val: numericScore,
        duration: 0.9,
        ease: "power2.out",
        onUpdate: () => {
          scoreEl.textContent = String(Math.round(counter.val));
        },
        onComplete: () => {
          scoreEl.textContent = String(finalScore);
        },
      });
    }

    if (hasScrollTrigger) {
      const cards = gsap.utils.toArray("#resultPanel .res-card");
      if (cards.length) {
        gsap.set(cards, { opacity: 0, y: 18 });
        const triggers = window.ScrollTrigger.batch(cards, {
          start: "top 92%",
          once: true,
          onEnter: (batch) => {
            gsap.to(batch, {
              opacity: 1,
              y: 0,
              duration: 0.45,
              stagger: 0.05,
              ease: "power3.out",
              clearProps: "transform,opacity",
            });
          },
        });
        if (Array.isArray(triggers)) {
          triggers.forEach((st) => trackTrigger("results", st));
        }
      }
    }

    refreshScroll();
  }

  /* ------------------------------------------------------------------------
     GSAP + ScrollTrigger: All-Questions Quiz View
     ------------------------------------------------------------------------ */
  function animateAllQuestions() {
    clearScope("allQuestions");
    if (reducedMotion || !hasGsap || !hasScrollTrigger) return;
    const gsap = window.gsap;
    const cards = gsap.utils.toArray("#quizAllContainer .q-card");
    if (!cards.length) return;

    gsap.set(cards, { opacity: 0, y: 18 });
    const triggers = window.ScrollTrigger.batch(cards, {
      start: "top 92%",
      once: true,
      onEnter: (batch) => {
        gsap.to(batch, {
          opacity: 1,
          y: 0,
          duration: 0.42,
          stagger: 0.045,
          ease: "power3.out",
          clearProps: "transform,opacity",
        });
      },
    });
    if (Array.isArray(triggers)) {
      triggers.forEach((st) => trackTrigger("allQuestions", st));
    }
    refreshScroll();
  }

  /* ------------------------------------------------------------------------
     Motion (motion.dev): Spring Micro-Interactions (Question, Option, Sheet, Toast)
     ------------------------------------------------------------------------ */
  function animateQuestion(cardEl, answerEl, direction) {
    if (reducedMotion || !direction) return;
    const offset = direction === "prev" ? -16 : 16;
    const targets = [cardEl, answerEl].filter(Boolean);
    if (!targets.length) return;

    if (hasMotion) {
      targets.forEach((el, idx) => {
        window.Motion.animate(
          el,
          { opacity: [0, 1], x: [offset, 0] },
          {
            duration: 0.28,
            delay: idx * 0.03,
            easing: [0.16, 1, 0.3, 1],
          }
        );
      });
    } else if (hasGsap) {
      window.gsap.fromTo(
        targets,
        { opacity: 0, x: offset },
        {
          opacity: 1,
          x: 0,
          duration: 0.28,
          stagger: 0.03,
          ease: "power3.out",
          clearProps: "transform,opacity",
        }
      );
    }
  }

  function popOption(optionEl) {
    if (!optionEl || reducedMotion) return;
    if (hasMotion) {
      window.Motion.animate(
        optionEl,
        { scale: [0.985, 1.012, 1] },
        { duration: 0.26, easing: [0.22, 1, 0.36, 1] }
      );
    } else if (hasGsap) {
      window.gsap.fromTo(
        optionEl,
        { scale: 0.985 },
        { scale: 1, duration: 0.24, ease: "back.out(2)", clearProps: "transform" }
      );
    }
  }

  function animateThemeToggle(btnEl) {
    if (!btnEl || reducedMotion) return;
    const icon = btnEl.querySelector("svg:not([style*='display: none'])") || btnEl;
    if (hasMotion) {
      window.Motion.animate(
        icon,
        { rotate: [-24, 0], scale: [0.85, 1] },
        { duration: 0.34, easing: [0.34, 1.56, 0.64, 1] }
      );
    }
  }

  function openSheet(overlayEl) {
    if (!overlayEl) return;
    const backdrop = overlayEl.querySelector(".cbt-drawer-backdrop");
    const sheet = overlayEl.querySelector(".cbt-drawer-sheet");

    overlayEl.classList.remove("hidden");
    overlayEl.classList.add("is-open");
    lockScroll();

    if (reducedMotion) return;

    if (hasMotion) {
      if (backdrop) {
        window.Motion.animate(backdrop, { opacity: [0, 1] }, { duration: 0.22 });
      }
      if (sheet) {
        window.Motion.animate(
          sheet,
          { opacity: [0, 1], y: [32, 0], scale: [0.98, 1] },
          { duration: 0.34, easing: [0.16, 1, 0.3, 1] }
        );
      }
    }
  }

  function closeSheet(overlayEl, onDone) {
    if (!overlayEl || overlayEl.classList.contains("hidden")) return;
    const backdrop = overlayEl.querySelector(".cbt-drawer-backdrop");
    const sheet = overlayEl.querySelector(".cbt-drawer-sheet");

    const finish = () => {
      overlayEl.classList.remove("is-open");
      overlayEl.classList.add("hidden");
      if (typeof onDone === "function") onDone();
    };

    if (reducedMotion) {
      finish();
      return;
    }

    if (hasMotion && sheet) {
      if (backdrop) {
        window.Motion.animate(backdrop, { opacity: [1, 0] }, { duration: 0.2 });
      }
      const ctrl = window.Motion.animate(
        sheet,
        { opacity: [1, 0], y: [0, 26], scale: [1, 0.985] },
        { duration: 0.22, easing: [0.4, 0, 1, 1] }
      );
      if (ctrl && ctrl.finished && typeof ctrl.finished.then === "function") {
        ctrl.finished.then(finish).catch(finish);
      } else {
        setTimeout(finish, 230);
      }
    } else {
      overlayEl.classList.remove("is-open");
      setTimeout(finish, 260);
    }
  }

  function showToast(toastEl) {
    if (!toastEl) return;
    toastEl.classList.remove("hidden");
    toastEl.classList.add("is-visible");
    if (reducedMotion) return;

    if (hasMotion) {
      window.Motion.animate(
        toastEl,
        { opacity: [0, 1], y: [16, 0], scale: [0.95, 1] },
        { duration: 0.3, easing: [0.16, 1, 0.3, 1] }
      );
    }
  }

  function hideToast(toastEl, onDone) {
    if (!toastEl || toastEl.classList.contains("hidden")) return;
    const finish = () => {
      toastEl.classList.remove("is-visible");
      toastEl.classList.add("hidden");
      if (typeof onDone === "function") onDone();
    };
    if (reducedMotion) {
      finish();
      return;
    }
    if (hasMotion) {
      const ctrl = window.Motion.animate(
        toastEl,
        { opacity: [1, 0], y: [0, 10], scale: [1, 0.96] },
        { duration: 0.2, easing: [0.4, 0, 1, 1] }
      );
      if (ctrl && ctrl.finished && typeof ctrl.finished.then === "function") {
        ctrl.finished.then(finish).catch(finish);
      } else {
        setTimeout(finish, 210);
      }
    } else {
      toastEl.classList.remove("is-visible");
      setTimeout(finish, 240);
    }
  }

  // Mark HTML as motion-engine ready so CSS keyframe fallbacks don't double-animate
  if ((hasGsap || hasMotion) && !reducedMotion) {
    document.documentElement.classList.add("motion-ready");
  }

  initLenis();

  window.KisiMotion = {
    get lenis() {
      return lenis;
    },
    refreshScroll,
    scrollToTop,
    lockScroll,
    unlockScroll,
    animateHome,
    animatePanel,
    animateMaterial,
    animateResults,
    animateAllQuestions,
    animateQuestion,
    popOption,
    animateThemeToggle,
    openSheet,
    closeSheet,
    showToast,
    hideToast,
  };
})();
