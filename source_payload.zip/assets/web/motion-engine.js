/* ==========================================================================
   KisiKit Native-Grade GPU Motion Engine (Zero Scroll Jank on Android 60-120Hz)
   ========================================================================== */
(() => {
  const reducedMotion =
    window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const EASE_OUT = "cubic-bezier(0.22, 1, 0.36, 1)";
  const EASE_IN = "cubic-bezier(0.4, 0, 1, 1)";

  function runAnim(el, keyframes, opts) {
    if (!el || reducedMotion || typeof el.animate !== "function") return null;
    try {
      return el.animate(keyframes, { fill: "none", ...opts });
    } catch {
      return null;
    }
  }

  function refreshScroll() {
    // Native Android momentum scroll needs no JS resize hook
  }

  function scrollToTop(instant = false) {
    window.scrollTo({
      top: 0,
      behavior: instant || reducedMotion ? "auto" : "smooth",
    });
  }

  function lockScroll() {
    document.body.style.overflow = "hidden";
  }

  function unlockScroll() {
    document.body.style.overflow = "";
  }

  function animateHome() {
    const home = document.getElementById("homeView");
    runAnim(
      home,
      [
        { opacity: 0.4, transform: "translate3d(0, 8px, 0)" },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      { duration: 220, easing: EASE_OUT }
    );
  }

  function animatePanel(el) {
    runAnim(
      el,
      [
        { opacity: 0.35, transform: "translate3d(0, 8px, 0)" },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      { duration: 200, easing: EASE_OUT }
    );
  }

  function animateMaterial() {
    // Keep all cards immediately visible so scrolling is 100% 60/120fps native
    const panel = document.getElementById("materialPanel");
    runAnim(
      panel,
      [
        { opacity: 0.5, transform: "translate3d(0, 6px, 0)" },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      { duration: 200, easing: EASE_OUT }
    );
  }

  function animateResults(finalScore) {
    const scoreHero = document.querySelector("#resultPanel .score-hero-card");
    runAnim(
      scoreHero,
      [
        { opacity: 0, transform: "translate3d(0, 10px, 0) scale(0.985)" },
        { opacity: 1, transform: "translate3d(0, 0, 0) scale(1)" },
      ],
      { duration: 260, easing: EASE_OUT }
    );

    const scoreEl = document.getElementById("resultTotalScore");
    const target = Number(finalScore);
    if (scoreEl && Number.isFinite(target) && !reducedMotion) {
      const start = performance.now();
      const duration = 550;
      const tick = (now) => {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        scoreEl.textContent = String(Math.round(target * eased));
        if (p < 1) {
          requestAnimationFrame(tick);
        } else {
          scoreEl.textContent = String(finalScore);
        }
      };
      requestAnimationFrame(tick);
    }
  }

  function animateAllQuestions() {
    const wrap = document.getElementById("quizAllContainer");
    runAnim(
      wrap,
      [
        { opacity: 0.4, transform: "translate3d(0, 6px, 0)" },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      { duration: 180, easing: EASE_OUT }
    );
  }

  function animateQuestion(cardEl, answerEl, direction) {
    if (reducedMotion || !direction) return;
    const offset = direction === "prev" ? -14 : 14;
    [cardEl, answerEl].filter(Boolean).forEach((el) => {
      runAnim(
        el,
        [
          { opacity: 0.25, transform: `translate3d(${offset}px, 0, 0)` },
          { opacity: 1, transform: "translate3d(0, 0, 0)" },
        ],
        { duration: 180, easing: EASE_OUT }
      );
    });
  }

  function popOption(optionEl) {
    runAnim(
      optionEl,
      [
        { transform: "scale(0.975)" },
        { transform: "scale(1.01)" },
        { transform: "scale(1)" },
      ],
      { duration: 170, easing: EASE_OUT }
    );
  }

  function animateThemeToggle(btnEl) {
    if (!btnEl) return;
    runAnim(
      btnEl,
      [
        { transform: "scale(0.9) rotate(-18deg)" },
        { transform: "scale(1) rotate(0deg)" },
      ],
      { duration: 220, easing: EASE_OUT }
    );
  }

  function openSheet(overlayEl) {
    if (!overlayEl) return;
    const backdrop = overlayEl.querySelector(".cbt-drawer-backdrop");
    const sheet = overlayEl.querySelector(".cbt-drawer-sheet");

    overlayEl.classList.remove("hidden");
    overlayEl.classList.add("is-open");
    lockScroll();

    runAnim(backdrop, [{ opacity: 0 }, { opacity: 1 }], {
      duration: 180,
      easing: EASE_OUT,
    });
    runAnim(
      sheet,
      [
        { opacity: 0.5, transform: "translate3d(0, 28px, 0)" },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      { duration: 220, easing: EASE_OUT }
    );
  }

  function closeSheet(overlayEl, onDone) {
    if (!overlayEl || overlayEl.classList.contains("hidden")) return;
    const backdrop = overlayEl.querySelector(".cbt-drawer-backdrop");
    const sheet = overlayEl.querySelector(".cbt-drawer-sheet");

    const finish = () => {
      overlayEl.classList.remove("is-open");
      overlayEl.classList.add("hidden");
      if (typeof onDone === "function") onDone();
    };

    if (reducedMotion || !sheet || typeof sheet.animate !== "function") {
      finish();
      return;
    }

    runAnim(backdrop, [{ opacity: 1 }, { opacity: 0 }], {
      duration: 150,
      easing: EASE_IN,
    });
    const anim = runAnim(
      sheet,
      [
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
        { opacity: 0, transform: "translate3d(0, 24px, 0)" },
      ],
      { duration: 160, easing: EASE_IN }
    );
    if (anim && anim.finished) {
      anim.finished.then(finish).catch(finish);
    } else {
      setTimeout(finish, 165);
    }
  }

  function showToast(toastEl) {
    if (!toastEl) return;
    toastEl.classList.remove("hidden");
    toastEl.classList.add("is-visible");
    runAnim(
      toastEl,
      [
        { opacity: 0, transform: "translate3d(-50%, 12px, 0) scale(0.96)" },
        { opacity: 1, transform: "translate3d(-50%, 0, 0) scale(1)" },
      ],
      { duration: 190, easing: EASE_OUT }
    );
  }

  function hideToast(toastEl, onDone) {
    if (!toastEl || toastEl.classList.contains("hidden")) return;
    const finish = () => {
      toastEl.classList.remove("is-visible");
      toastEl.classList.add("hidden");
      if (typeof onDone === "function") onDone();
    };
    const anim = runAnim(
      toastEl,
      [
        { opacity: 1, transform: "translate3d(-50%, 0, 0) scale(1)" },
        { opacity: 0, transform: "translate3d(-50%, 8px, 0) scale(0.96)" },
      ],
      { duration: 150, easing: EASE_IN }
    );
    if (anim && anim.finished) {
      anim.finished.then(finish).catch(finish);
    } else {
      finish();
    }
  }

  document.documentElement.classList.add("motion-ready");

  window.KisiMotion = {
    get lenis() {
      return null;
    },
    refreshScroll,
    scrollToTop,
    lockScroll,
    unlockScroll,
    animateHome,
    animatePanel,
    animateMaterial,
    animateResults,
    animateAllQuestions,
    animateQuestion,
    popOption,
    animateThemeToggle,
    openSheet,
    closeSheet,
    showToast,
    hideToast,
  };
})();
