(() => {
  const HISTORY_KEY = "kisikit_history_v1";
  const THEME_KEY = "kisikit_theme";
  const REQUEST_TIMEOUT_MS = 70000;
  const DEFAULT_QUIZ_DURATION_SEC = 420; // 7 menit per sesi kuis

  const state = {
    style: "santai",
    selectedFile: null,
    session: null,
    activeTab: "material",
    mcqAnswers: {},
    essayAnswers: {},
    lastResult: null,
    quizMode: "cbt",
    currentQuestionIndex: 0,
    questions: [],
    timerInterval: null,
    quizExpiresAt: null,
    quizExpired: false,
    quizDurationSec: DEFAULT_QUIZ_DURATION_SEC,
    allQuestionsRendered: false,
  };

  // Views & Common Elements
  const homeView = document.getElementById("homeView");
  const loadingView = document.getElementById("loadingView");
  const sessionView = document.getElementById("sessionView");
  const loadingTitle = document.getElementById("loadingTitle");
  const loadingDesc = document.getElementById("loadingDesc");
  const loadingCancel = document.getElementById("loadingCancel");
  const errorBanner = document.getElementById("errorBanner");
  const errorText = document.getElementById("errorText");
  const errorCloseBtn = document.getElementById("errorCloseBtn");

  // Topbar
  const copyLinkBtn = document.getElementById("copyLinkBtn");
  const newSessionBtn = document.getElementById("newSessionBtn");
  const brandLink = document.getElementById("brandLink");
  const themeToggleBtn = document.getElementById("themeToggleBtn");
  const themeToggleLabel = document.getElementById("themeToggleLabel");

  // Home Form
  const createForm = document.getElementById("createForm");
  const topicInput = document.getElementById("topicInput");
  const fileInput = document.getElementById("fileInput");
  const uploadBox = document.getElementById("uploadBox");
  const uploadLabel = document.getElementById("uploadLabel");
  const clearFileBtn = document.getElementById("clearFileBtn");
  const generateBtn = document.getElementById("generateBtn");

  // History
  const historyEmpty = document.getElementById("historyEmpty");
  const historyList = document.getElementById("historyList");
  const clearHistoryBtn = document.getElementById("clearHistoryBtn");

  // Session Nav & Header
  const sessionMeta = document.getElementById("sessionMeta");
  const sessionTitle = document.getElementById("sessionTitle");
  const backHomeLink = document.getElementById("backHomeLink");
  const tabMaterial = document.getElementById("tabMaterial");
  const tabQuiz = document.getElementById("tabQuiz");
  const tabResult = document.getElementById("tabResult");

  // Panels
  const materialPanel = document.getElementById("materialPanel");
  const quizPanel = document.getElementById("quizPanel");
  const resultPanel = document.getElementById("resultPanel");

  // Material Elements
  const materialTldr = document.getElementById("materialTldr");
  const materialSections = document.getElementById("materialSections");
  const cheatSheetWrap = document.getElementById("cheatSheetWrap");
  const cheatSheetList = document.getElementById("cheatSheetList");
  const trapsWrap = document.getElementById("trapsWrap");
  const trapsList = document.getElementById("trapsList");
  const startQuizBtn = document.getElementById("startQuizBtn");

  // CBT Quiz Elements
  const quizTitleDisplay = document.getElementById("quizTitleDisplay");
  const quizAutoSaveText = document.getElementById("quizAutoSaveText");
  const quizProgressFill = document.getElementById("quizProgressFill");
  const quizMetaBar = document.getElementById("quizMetaBar");
  const quizCurrentNum = document.getElementById("quizCurrentNum");
  const quizTotalNum = document.getElementById("quizTotalNum");
  const quizTypeBadge = document.getElementById("quizTypeBadge");
  const quizTimerBox = document.getElementById("quizTimerBox");
  const quizLiveTimer = document.getElementById("quizLiveTimer");
  const quizExpiredState = document.getElementById("quizExpiredState");
  const regenerateQuizBtn = document.getElementById("regenerateQuizBtn");
  const expiredBackMaterialBtn = document.getElementById("expiredBackMaterialBtn");
  const quizEmptyState = document.getElementById("quizEmptyState");
  const emptyGenerateQuizBtn = document.getElementById("emptyGenerateQuizBtn");
  const quizForm = document.getElementById("quizForm");

  // CBT Single Question View
  const quizCbtSingleView = document.getElementById("quizCbtSingleView");
  const cbtCardQNum = document.getElementById("cbtCardQNum");
  const cbtCurrentQuestionText = document.getElementById("cbtCurrentQuestionText");
  const cbtMcqContainer = document.getElementById("cbtMcqContainer");
  const cbtEssayContainer = document.getElementById("cbtEssayContainer");
  const cbtEssayInput = document.getElementById("cbtEssayInput");
  const cbtEssayCharCount = document.getElementById("cbtEssayCharCount");

  // CBT All Questions View
  const quizAllContainer = document.getElementById("quizAllContainer");
  const mcqContainer = document.getElementById("mcqContainer");
  const essayContainer = document.getElementById("essayContainer");

  // CBT Bottom Dock
  const quizOpenDrawerBtn = document.getElementById("quizOpenDrawerBtn");
  const quizToggleViewModeBtn = document.getElementById("quizToggleViewModeBtn");
  const quizAnsweredCount = document.getElementById("quizAnsweredCount");
  const quizTotalQuestionsCount = document.getElementById("quizTotalQuestionsCount");
  const quizPrevBtn = document.getElementById("quizPrevBtn");
  const quizNextBtn = document.getElementById("quizNextBtn");
  const submitQuizBtn = document.getElementById("submitQuizBtn");

  // CBT Drawer
  const quizDrawerModal = document.getElementById("quizDrawerModal");
  const quizDrawerBackdrop = document.getElementById("quizDrawerBackdrop");
  const quizDrawerCloseBtn = document.getElementById("quizDrawerCloseBtn");
  const drawerAnsweredSummary = document.getElementById("drawerAnsweredSummary");
  const drawerMcqGrid = document.getElementById("drawerMcqGrid");
  const drawerEssayGrid = document.getElementById("drawerEssayGrid");
  const drawerQuickSubmitBtn = document.getElementById("drawerQuickSubmitBtn");

  // Results Elements
  const resultTotalScore = document.getElementById("resultTotalScore");
  const resultGradeLabel = document.getElementById("resultGradeLabel");
  const resultBreakdown = document.getElementById("resultBreakdown");
  const resultOverallFeedback = document.getElementById("resultOverallFeedback");
  const reviewFocusWrap = document.getElementById("reviewFocusWrap");
  const reviewFocusList = document.getElementById("reviewFocusList");
  const mcqResultList = document.getElementById("mcqResultList");
  const essayResultList = document.getElementById("essayResultList");
  const backToMaterialBtn = document.getElementById("backToMaterialBtn");
  const retakeQuizBtn = document.getElementById("retakeQuizBtn");

  // Floating Help & Modal
  const floatingHelpBtn = document.getElementById("floatingHelpBtn");
  const helpModal = document.getElementById("helpModal");
  const helpModalBackdrop = document.getElementById("helpModalBackdrop");
  const helpModalCloseBtn = document.getElementById("helpModalCloseBtn");

  // Toast & Timers
  const toastEl = document.getElementById("toast");
  let toastTimer = null;
  let loadingMsgInterval = null;
  let activeAbortController = null;
  let activePollCancelled = false;
  let loadingStartTime = 0;
  let saveFeedbackTimer = null;
  let draftSaveDebounceTimer = null;
  let historyCache = null;
  let isCreatingSession = false;
  let isGradingQuiz = false;

  /* ==========================================================================
     Safe JSON Parsing (Mencegah error "Unexpected token '<', <!DOCTYPE...")
     ========================================================================== */
  async function safeParseJson(resp) {
    const rawText = await resp.text();
    const trimmed = rawText.trim();
    if (!trimmed) {
      if (!resp.ok) {
        throw new Error(`Server mengembalikan respons kosong (HTTP ${resp.status}). Coba ulangi.`);
      }
      return {};
    }
    try {
      return JSON.parse(trimmed);
    } catch {
      if (trimmed.startsWith("<")) {
        throw new Error(
          `Server atau tunnel sedang sibuk (HTTP ${resp.status}). Tunggu sebentar lalu coba lagi.`
        );
      }
      throw new Error(`Respons server tidak valid (HTTP ${resp.status}). Silakan coba lagi.`);
    }
  }

  /* ==========================================================================
     Theme Management
     ========================================================================== */
  function applyTheme(theme) {
    const isDark = theme === "dark";
    document.documentElement.setAttribute("data-theme", isDark ? "dark" : "light");
    if (themeToggleBtn) {
      themeToggleBtn.setAttribute("aria-pressed", String(isDark));
      themeToggleBtn.setAttribute("aria-label", isDark ? "Aktifkan mode terang" : "Aktifkan mode gelap");
    }
    if (themeToggleLabel) {
      themeToggleLabel.textContent = isDark ? "Terang" : "Gelap";
    }
    if (window.FlutterThemeChannel && typeof window.FlutterThemeChannel.postMessage === "function") {
      try { window.FlutterThemeChannel.postMessage(isDark ? "dark" : "light"); } catch {}
    }
  }

  function initTheme() {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    applyTheme(current);
    if (themeToggleBtn) {
      themeToggleBtn.addEventListener("click", () => {
        const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
        applyTheme(next);
        try {
          localStorage.setItem(THEME_KEY, next);
        } catch {}
      });
    }
  }

  /* ==========================================================================
     Loading Indicator
     ========================================================================== */
  const LOADING_CONFIG = {
    generate: {
      steps: ["1. Materi", "2. 15 PG", "3. 5 Essay"],
      messages: [
        "Menyusun materi + 20 soal CBT secara paralel...",
        "Merangkum konsep inti, analogi & cheat sheet...",
        "Menyiapkan 15 pilihan ganda & 5 essay sekaligus...",
        "Hampir selesai! Materi & kuis langsung siap dipakai...",
      ],
    },
    quiz: {
      steps: ["1. Konsep", "2. 15 PG", "3. 5 Essay"],
      messages: [
        "Menyusun 15 pilihan ganda dan 5 essay secara paralel...",
        "Menyiapkan variasi pertanyaan baru dari materi...",
        "Merapikan opsi jawaban dan pembahasan...",
        "Hampir siap untuk sesi CBT 7 menit...",
      ],
    },
    grade: {
      steps: ["1. Cek PG", "2. Essay", "3. Skor"],
      messages: [
        "Memeriksa jawaban pilihan ganda...",
        "Mengevaluasi jawaban essay...",
        "Menyusun pembahasan dan rekomendasi belajar...",
      ],
    },
    open: {
      steps: ["1. Cari", "2. Ambil", "3. Siap"],
      messages: ["Membuka sesi belajar...", "Memuat catatan dan kuis..."],
    },
  };

  function startLoadingMessages(type) {
    const config = LOADING_CONFIG[type] || LOADING_CONFIG.generate;
    const messages = config.messages;
    const steps = config.steps;
    let msgIdx = 0;
    let stepIdx = 0;
    const totalSteps = steps.length;
    const stepEls = [
      document.getElementById("lstep0"),
      document.getElementById("lstep1"),
      document.getElementById("lstep2"),
    ];

    stepEls.forEach((el, i) => {
      if (el) {
        el.className = "lstep";
        el.textContent = steps[i] || `Langkah ${i + 1}`;
      }
    });
    if (stepEls[0]) stepEls[0].classList.add("active");

    clearInterval(loadingMsgInterval);
    loadingDesc.textContent = messages[0];

    loadingMsgInterval = setInterval(() => {
      msgIdx++;
      loadingDesc.textContent = messages[msgIdx % messages.length];

      const targetStep = Math.min(
        Math.floor((msgIdx / Math.max(1, messages.length - 1)) * totalSteps),
        totalSteps - 1
      );
      if (targetStep !== stepIdx) {
        if (stepEls[stepIdx]) {
          stepEls[stepIdx].classList.remove("active");
          stepEls[stepIdx].classList.add("done");
        }
        stepIdx = targetStep;
        if (stepEls[stepIdx]) {
          stepEls[stepIdx].classList.add("active");
        }
      }
    }, 2200);
  }

  function stopLoadingMessages() {
    clearInterval(loadingMsgInterval);
    loadingMsgInterval = null;
  }

  function fetchWithTimeout(url, options = {}, timeoutMs = REQUEST_TIMEOUT_MS) {
    const controller = new AbortController();
    activeAbortController = controller;
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    return fetch(url, { ...options, signal: controller.signal })
      .then((resp) => {
        clearTimeout(timer);
        activeAbortController = null;
        return resp;
      })
      .catch((err) => {
        clearTimeout(timer);
        activeAbortController = null;
        if (err.name === "AbortError") {
          throw new Error("Koneksi habis waktu atau dibatalkan. Silakan coba lagi.");
        }
        throw err;
      });
  }

  let toastHideTimer = null;

  function showToast(msg) {
    toastEl.textContent = msg;
    clearTimeout(toastTimer);
    clearTimeout(toastHideTimer);
    toastEl.classList.remove("hidden");
    requestAnimationFrame(() => {
      toastEl.classList.add("is-visible");
    });
    toastTimer = setTimeout(() => {
      toastEl.classList.remove("is-visible");
      toastHideTimer = setTimeout(() => {
        toastEl.classList.add("hidden");
      }, 200);
    }, 2600);
  }

  function showError(msg) {
    errorText.textContent = msg;
    errorBanner.classList.remove("hidden");
    window.scrollTo(0, 0);
  }

  function hideError() {
    errorBanner.classList.add("hidden");
  }

  function setView(name) {
    homeView.classList.toggle("hidden", name !== "home");
    loadingView.classList.toggle("hidden", name !== "loading");
    sessionView.classList.toggle("hidden", name !== "session");
    const inSession = name === "session";
    copyLinkBtn.classList.toggle("hidden", !inSession);
    newSessionBtn.classList.toggle("hidden", !inSession);
    if (name !== "loading") {
      stopLoadingMessages();
    }
    window.scrollTo(0, 0);
  }

  function showLoading(title, desc, type = "generate") {
    loadingStartTime = Date.now();
    loadingTitle.textContent = title;
    startLoadingMessages(type);
    setView("loading");
  }

  async function finishLoadingAndSwitch(targetViewName, beforeSwitchCallback, successText = "Siap.") {
    if (loadingDesc) {
      loadingDesc.textContent = successText;
    }
    if (typeof beforeSwitchCallback === "function") {
      beforeSwitchCallback();
    }
    setView(targetViewName);
  }

  function escapeHtml(str) {
    return String(str || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /* ==========================================================================
     History Storage
     ========================================================================== */
  function loadHistory() {
    if (Array.isArray(historyCache)) return historyCache;
    try {
      historyCache = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
      return historyCache;
    } catch {
      historyCache = [];
      return historyCache;
    }
  }

  function saveToHistory(session) {
    const items = loadHistory().filter((x) => x.id !== session.id);
    items.unshift({
      id: session.id,
      title: session.title,
      savedAt: Date.now(),
    });
    historyCache = items.slice(0, 15);
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(historyCache));
    } catch {}
    renderHistory();
  }

  function renderHistory() {
    const items = loadHistory();
    const hasItems = items.length > 0;
    historyEmpty.classList.toggle("hidden", hasItems);
    historyList.classList.toggle("hidden", !hasItems);
    clearHistoryBtn.classList.toggle("hidden", !hasItems);

    if (!hasItems) {
      historyList.innerHTML = "";
      return;
    }

    historyList.innerHTML = items
      .map((item) => {
        const d = new Date(item.savedAt);
        const dateStr = d.toLocaleDateString("id-ID", { day: "numeric", month: "short" });
        return `
          <a class="history-item" href="/s/${escapeHtml(item.id)}" data-session-id="${escapeHtml(item.id)}">
            <span class="history-item-title">${escapeHtml(item.title)}</span>
            <span class="history-item-meta">${dateStr}</span>
          </a>
        `;
      })
      .join("");
  }

  /* ==========================================================================
     Draft Answers & 7-Minute Timer Storage
     ========================================================================== */
  function draftKey(sessionId) {
    return `kisikit_draft_${sessionId}`;
  }

  function timerKey(sessionId) {
    return `kisikit_timer_${sessionId}`;
  }

  function getCurrentQuizId() {
    return (state.session && state.session.quiz && state.session.quiz.quiz_id) || "v1";
  }

  function saveQuizDraft(debounced = false) {
    if (!state.session || state.quizExpired) return;
    const write = () => {
      if (!state.session || state.quizExpired) return;
      try {
        localStorage.setItem(
          draftKey(state.session.id),
          JSON.stringify({
            quizId: getCurrentQuizId(),
            mcq: state.mcqAnswers,
            essay: state.essayAnswers,
          })
        );
      } catch {}
      triggerSaveNotice();
    };
    clearTimeout(draftSaveDebounceTimer);
    if (debounced) {
      draftSaveDebounceTimer = setTimeout(write, 350);
    } else {
      write();
    }
  }

  function triggerSaveNotice() {
    if (quizAutoSaveText) {
      quizAutoSaveText.textContent = "Menyimpan...";
      clearTimeout(saveFeedbackTimer);
      saveFeedbackTimer = setTimeout(() => {
        if (quizAutoSaveText) quizAutoSaveText.textContent = "Tersimpan";
      }, 400);
    }
  }

  function loadQuizDraft(sessionId, expectedQuizId) {
    try {
      const parsed = JSON.parse(localStorage.getItem(draftKey(sessionId)) || "null");
      if (parsed && (!expectedQuizId || !parsed.quizId || parsed.quizId === expectedQuizId)) {
        state.mcqAnswers = parsed.mcq || {};
        state.essayAnswers = parsed.essay || {};
        return;
      }
    } catch {}
    state.mcqAnswers = {};
    state.essayAnswers = {};
  }

  function loadTimerRecord(sessionId, quizId) {
    try {
      const parsed = JSON.parse(localStorage.getItem(timerKey(sessionId)) || "null");
      if (parsed && parsed.quizId === quizId) {
        return parsed;
      }
    } catch {}
    return null;
  }

  function saveTimerRecord(sessionId, quizId, expiresAt, expired) {
    try {
      localStorage.setItem(
        timerKey(sessionId),
        JSON.stringify({ quizId, expiresAt, expired })
      );
    } catch {}
  }

  function clearTimerRecord(sessionId) {
    try {
      localStorage.removeItem(timerKey(sessionId));
    } catch {}
  }

  /* ==========================================================================
     7-Minute Countdown Quiz Timer (Auto-Lock & Require Regenerate When Expired)
     ========================================================================== */
  function stopQuizTimer() {
    clearInterval(state.timerInterval);
    state.timerInterval = null;
  }

  function formatCountdown(seconds) {
    const safe = Math.max(0, Math.floor(seconds));
    const mins = Math.floor(safe / 60);
    const secs = safe % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }

  function applyTimerVisual(remainingSec) {
    if (!quizLiveTimer) return;
    quizLiveTimer.textContent = formatCountdown(remainingSec);
    if (quizTimerBox) {
      quizTimerBox.classList.toggle("timer-warn", remainingSec <= 120 && remainingSec > 60);
      quizTimerBox.classList.toggle("timer-danger", remainingSec <= 60);
    }
  }

  function showQuizExpiredLock() {
    state.quizExpired = true;
    stopQuizTimer();
    closeDrawer();
    applyTimerVisual(0);

    if (state.session) {
      saveTimerRecord(state.session.id, getCurrentQuizId(), state.quizExpiresAt || Date.now(), true);
    }

    quizForm.classList.add("hidden");
    quizEmptyState.classList.add("hidden");
    if (quizExpiredState) quizExpiredState.classList.remove("hidden");
    if (quizMetaBar) quizMetaBar.classList.remove("hidden");
  }

  function initOrResumeQuizTimer() {
    if (!state.session || !state.session.quiz) return;
    stopQuizTimer();

    const sessionId = state.session.id;
    const quizId = getCurrentQuizId();
    const durationSec = Number(state.session.quiz.duration_seconds) || DEFAULT_QUIZ_DURATION_SEC;
    state.quizDurationSec = durationSec;

    const saved = loadTimerRecord(sessionId, quizId);
    if (saved) {
      state.quizExpiresAt = saved.expiresAt;
      const remaining = Math.ceil((saved.expiresAt - Date.now()) / 1000);
      if (saved.expired || remaining <= 0) {
        showQuizExpiredLock();
        return;
      }
    } else {
      state.quizExpiresAt = Date.now() + durationSec * 1000;
      saveTimerRecord(sessionId, quizId, state.quizExpiresAt, false);
    }

    state.quizExpired = false;
    if (quizExpiredState) quizExpiredState.classList.add("hidden");
    quizForm.classList.remove("hidden");

    const tick = () => {
      if (!state.quizExpiresAt) return;
      const remaining = Math.ceil((state.quizExpiresAt - Date.now()) / 1000);
      if (remaining <= 0) {
        showQuizExpiredLock();
        showToast("Waktu 7 menit habis! Klik Generate Kuis Baru untuk soal berbeda.");
        return;
      }
      applyTimerVisual(remaining);
    };

    tick();
    state.timerInterval = setInterval(tick, 1000);
  }

  /* ==========================================================================
     Material Reading View
     ========================================================================== */
  function renderMaterial(session) {
    const mat = session.material || {};
    const mins = mat.estimated_minutes || 4;
    const styleLabel = session.style === "kilat" ? "Kilat H-1" : "Santai & Rinci";
    sessionMeta.innerHTML = `<span class="meta-badge">${styleLabel}</span><span>Perkiraan ${mins} menit baca</span>`;
    sessionTitle.textContent = session.title || "Materi Belajar";
    materialTldr.textContent = mat.tldr || "Ringkasan konsep inti belum tersedia.";

    const sections = Array.isArray(mat.sections) ? mat.sections : [];
    if (!sections.length) {
      materialSections.innerHTML = `
        <div class="empty-state card">
          <p class="empty-title">Belum ada bagian materi.</p>
          <p class="empty-desc">Coba buat sesi baru dengan kisi-kisi yang lebih terperinci.</p>
        </div>
      `;
    } else {
      materialSections.innerHTML = sections
        .map((sec, idx) => {
          const num = String(idx + 1).padStart(2, "0");
          const analogyHtml = sec.analogy
            ? `<div class="analogy-box"><span class="analogy-label">Analogi Praktis:</span> ${escapeHtml(sec.analogy)}</div>`
            : "";
          const points = Array.isArray(sec.key_points) ? sec.key_points : [];
          const pointsHtml = points.length
            ? `<ul class="key-points">${points.map((p) => `<li>${escapeHtml(p)}</li>`).join("")}</ul>`
            : "";
          return `
            <article class="topic-card">
              <div class="topic-num-badge" aria-hidden="true">${num}</div>
              <div class="topic-body">
                <h3>${escapeHtml(sec.heading)}</h3>
                <p>${escapeHtml(sec.explanation)}</p>
                ${analogyHtml}
                ${pointsHtml}
              </div>
            </article>
          `;
        })
        .join("");
    }

    const cheats = Array.isArray(mat.cheat_sheet) ? mat.cheat_sheet : [];
    if (cheats.length) {
      cheatSheetWrap.classList.remove("hidden");
      cheatSheetList.innerHTML = cheats
        .map(
          (item) => `
          <div class="cheat-item">
            <div class="cheat-term">${escapeHtml(item.term)}</div>
            <div class="cheat-meaning">${escapeHtml(item.meaning)}</div>
          </div>
        `
        )
        .join("");
    } else {
      cheatSheetWrap.classList.add("hidden");
    }

    const traps = Array.isArray(mat.exam_traps) ? mat.exam_traps : [];
    if (traps.length) {
      trapsWrap.classList.remove("hidden");
      trapsList.innerHTML = traps.map((t) => `<li>${escapeHtml(t)}</li>`).join("");
    } else {
      trapsWrap.classList.add("hidden");
    }


    const startQuizSpan = startQuizBtn.querySelector("span");
    if (startQuizSpan) {
      startQuizSpan.textContent = session.has_quiz ? "Kerjakan Kuis CBT (7 Menit)" : "Mulai Kuis CBT (7 Menit)";
    }
    if (!session.has_quiz && !session.quiz) {
      startSilentQuizPrefetch(session.id);
    }
  }

  let prefetchTimer = null;
  function stopSilentQuizPrefetch() {
    clearTimeout(prefetchTimer);
    prefetchTimer = null;
  }

  function startSilentQuizPrefetch(sessionId) {
    stopSilentQuizPrefetch();
    if (!sessionId) return;
    let attempts = 0;
    const maxAttempts = 20;

    async function poll() {
      if (!state.session || state.session.id !== sessionId || state.session.quiz) {
        return;
      }
      attempts++;
      try {
        const resp = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/quiz/status`);
        if (resp.ok) {
          const data = await safeParseJson(resp);
          if (data.status === "ready" && data.quiz) {
            state.session.quiz = data.quiz;
            state.session.has_quiz = true;
            const startQuizSpan = startQuizBtn.querySelector("span");
            if (startQuizSpan) startQuizSpan.textContent = "Kerjakan Kuis CBT (7 Menit)";
            return;
          }
          if (data.status === "error") {
            return;
          }
        }
      } catch {}
      if (attempts < maxAttempts && state.session && !state.session.quiz) {
        prefetchTimer = setTimeout(poll, 2500);
      }
    }

    prefetchTimer = setTimeout(poll, 2000);
  }

  /* ==========================================================================
     CBT QUIZ IMPLEMENTATION
     ========================================================================== */
  function buildQuestionsList(quiz) {
    const list = [];
    if (quiz && Array.isArray(quiz.mcq)) {
      quiz.mcq.forEach((q, idx) => {
        list.push({
          type: "mcq",
          id: String(q.id),
          data: q,
          displayNum: idx + 1,
          typeLabel: "Pilihan Ganda",
        });
      });
    }
    if (quiz && Array.isArray(quiz.essay)) {
      const mcqCount = list.length;
      quiz.essay.forEach((q, idx) => {
        list.push({
          type: "essay",
          id: String(q.id),
          data: q,
          displayNum: mcqCount + idx + 1,
          essayCode: `E${q.id}`,
          typeLabel: "Essay",
        });
      });
    }
    return list;
  }

  function renderQuiz(quiz) {
    const hasQuiz = quiz && (Array.isArray(quiz.mcq) || Array.isArray(quiz.essay));
    quizEmptyState.classList.toggle("hidden", Boolean(hasQuiz));
    if (!hasQuiz) {
      quizForm.classList.add("hidden");
      if (quizExpiredState) quizExpiredState.classList.add("hidden");
      return;
    }

    if (quizTitleDisplay && state.session) {
      quizTitleDisplay.textContent = state.session.title || "Kuis Ujian CBT";
    }

    state.questions = buildQuestionsList(quiz);
    const total = state.questions.length;
    quizTotalNum.textContent = String(total);
    quizTotalQuestionsCount.textContent = String(total);

    if (state.currentQuestionIndex >= total || state.currentQuestionIndex < 0) {
      state.currentQuestionIndex = 0;
    }

    state.allQuestionsRendered = false;
    mcqContainer.innerHTML = "";
    essayContainer.innerHTML = "";
    renderCbtSingleQuestion(state.currentQuestionIndex);
    if (state.quizMode === "all") {
      renderAllQuestionsView(quiz);
      state.allQuestionsRendered = true;
    }
    renderQuestionDrawerGrid();
    updateQuizProgress();
    initOrResumeQuizTimer();
  }

  function renderCbtSingleQuestion(index, direction = null) {
    if (!state.questions.length) return;
    const qObj = state.questions[index];
    if (!qObj) return;

    const prevIndex = state.currentQuestionIndex;
    const resolvedDir = direction || (index > prevIndex ? "next" : index < prevIndex ? "prev" : null);
    state.currentQuestionIndex = index;
    const total = state.questions.length;

    quizCurrentNum.textContent = String(qObj.displayNum);
    quizTypeBadge.textContent = qObj.typeLabel;
    cbtCardQNum.textContent = `Soal #${qObj.displayNum}`;
    cbtCurrentQuestionText.textContent = qObj.data.question;

    quizPrevBtn.disabled = index === 0;
    const isLast = index === total - 1;
    quizNextBtn.classList.toggle("hidden", isLast);
    submitQuizBtn.classList.toggle("hidden", !isLast);

    if (qObj.type === "mcq") {
      cbtMcqContainer.classList.remove("hidden");
      cbtEssayContainer.classList.add("hidden");

      const chosen = state.mcqAnswers[qObj.id] || "";
      const letters = ["A", "B", "C", "D"];
      cbtMcqContainer.innerHTML = letters
        .map((letter) => {
          const text = (qObj.data.options && qObj.data.options[letter]) || "";
          const isSelected = chosen === letter;
          return `
            <button type="button" class="cbt-option-item ${isSelected ? "selected" : ""}" data-letter="${letter}" aria-pressed="${isSelected}">
              <span class="cbt-radio-circle" aria-hidden="true">
                <span class="cbt-radio-dot"></span>
              </span>
              <span class="cbt-opt-letter">${letter}.</span>
              <span class="cbt-opt-text">${escapeHtml(text)}</span>
            </button>
          `;
        })
        .join("");


    } else {
      cbtMcqContainer.classList.add("hidden");
      cbtEssayContainer.classList.remove("hidden");

      const currentVal = state.essayAnswers[qObj.id] || "";
      cbtEssayInput.value = currentVal;
      cbtEssayCharCount.textContent = `${currentVal.length} karakter`;

      cbtEssayInput.oninput = (e) => {
        if (state.quizExpired) return;
        const val = e.target.value;
        state.essayAnswers[qObj.id] = val;
        cbtEssayCharCount.textContent = `${val.length} karakter`;

        const taInAll = essayContainer.querySelector(`[data-essay-id="${qObj.id}"]`);
        if (taInAll) taInAll.value = val;

        saveQuizDraft(true);
        updateQuizProgress();
      };
    }
    updateQuestionDrawerGrid();
  }

  function renderAllQuestionsView(quiz) {
    if (!quiz) return;

    mcqContainer.innerHTML = (quiz.mcq || [])
      .map((q) => {
        const chosen = state.mcqAnswers[String(q.id)] || "";
        const optsHtml = ["A", "B", "C", "D"]
          .map((letter) => {
            const text = (q.options && q.options[letter]) || "";
            const checked = chosen === letter;
            return `
              <label class="opt-label ${checked ? "selected" : ""}">
                <input type="radio" name="mcq_${q.id}" value="${letter}" ${checked ? "checked" : ""} data-qid="${q.id}" />
                <span class="opt-key">${letter}.</span>
                <span>${escapeHtml(text)}</span>
              </label>
            `;
          })
          .join("");

        return `
          <div class="q-card" data-mcq-card="${q.id}">
            <p class="q-text"><span class="q-num">${q.id}.</span>${escapeHtml(q.question)}</p>
            <div class="options-grid">${optsHtml}</div>
          </div>
        `;
      })
      .join("");

    essayContainer.innerHTML = (quiz.essay || [])
      .map((q) => {
        const val = state.essayAnswers[String(q.id)] || "";
        return `
          <div class="q-card" data-essay-card="${q.id}">
            <label class="q-text" for="essay_input_${q.id}" style="display:block">
              <span class="q-num">E${q.id}.</span>${escapeHtml(q.question)}
            </label>
            <textarea id="essay_input_${q.id}" rows="3" class="form-control" placeholder="Tulis jawaban essay..." data-essay-id="${q.id}">${escapeHtml(val)}</textarea>
          </div>
        `;
      })
      .join("");


  }

  function updateQuizProgress() {
    if (!state.session || !state.session.quiz || !state.questions.length) return;
    const total = state.questions.length;

    let answered = 0;
    for (const q of state.session.quiz.mcq || []) {
      if (state.mcqAnswers[String(q.id)]) answered++;
    }
    for (const q of state.session.quiz.essay || []) {
      if ((state.essayAnswers[String(q.id)] || "").trim().length > 0) answered++;
    }

    const pct = Math.round((answered / Math.max(1, total)) * 100);
    quizAnsweredCount.textContent = String(answered);
    if (drawerAnsweredSummary) {
      drawerAnsweredSummary.textContent = `${answered}/${total} Terjawab`;
    }
    if (quizProgressFill) {
      quizProgressFill.style.transform = `scaleX(${(pct / 100).toFixed(4)})`;
    }
  }

  /* ==========================================================================
     "Daftar Soal" Drawer
     ========================================================================== */
  function renderQuestionDrawerGrid() {
    if (!state.questions.length) return;

    const mcqQuestions = state.questions.filter((q) => q.type === "mcq");
    const essayQuestions = state.questions.filter((q) => q.type === "essay");

    drawerMcqGrid.innerHTML = mcqQuestions
      .map((q) => {
        const isAnswered = Boolean(state.mcqAnswers[q.id]);
        const isCurrent = state.currentQuestionIndex === q.displayNum - 1;
        let cls = "cbt-grid-tile";
        if (isAnswered) cls += " answered";
        if (isCurrent) cls += " current";
        return `<button type="button" class="${cls}" data-q-idx="${q.displayNum - 1}">${q.displayNum}</button>`;
      })
      .join("");

    drawerEssayGrid.innerHTML = essayQuestions
      .map((q) => {
        const isAnswered = Boolean((state.essayAnswers[q.id] || "").trim());
        const isCurrent = state.currentQuestionIndex === q.displayNum - 1;
        let cls = "cbt-grid-tile";
        if (isAnswered) cls += " answered";
        if (isCurrent) cls += " current";
        return `<button type="button" class="${cls}" data-q-idx="${q.displayNum - 1}">${q.essayCode}</button>`;
      })
      .join("");


  }

  function updateQuestionDrawerGrid() {
    if (!quizDrawerModal || quizDrawerModal.classList.contains("hidden")) return;
    quizDrawerModal.querySelectorAll(".cbt-grid-tile").forEach((btn) => {
      const idx = parseInt(btn.dataset.qIdx, 10);
      if (isNaN(idx)) return;
      const q = state.questions[idx];
      if (!q) return;

      const isAnswered =
        q.type === "mcq"
          ? Boolean(state.mcqAnswers[q.id])
          : Boolean((state.essayAnswers[q.id] || "").trim());
      const isCurrent = state.currentQuestionIndex === idx;

      btn.classList.toggle("answered", isAnswered);
      btn.classList.toggle("current", isCurrent);
    });
  }

  let drawerCloseTimer = null;

  function openDrawer() {
    if (state.quizExpired) return;
    clearTimeout(drawerCloseTimer);
    quizDrawerModal.classList.remove("hidden");
    updateQuestionDrawerGrid();
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => {
      quizDrawerModal.classList.add("is-open");
    });
  }

  function closeDrawer() {
    if (quizDrawerModal.classList.contains("hidden")) return;
    quizDrawerModal.classList.remove("is-open");
    clearTimeout(drawerCloseTimer);
    drawerCloseTimer = setTimeout(() => {
      quizDrawerModal.classList.add("hidden");
      if (
        (!helpModal || helpModal.classList.contains("hidden")) &&
        (!apiKeyModal || apiKeyModal.classList.contains("hidden"))
      ) {
        document.body.style.overflow = "";
      }
    }, 180);
  }

  quizOpenDrawerBtn.addEventListener("click", openDrawer);
  quizDrawerBackdrop.addEventListener("click", closeDrawer);
  quizDrawerCloseBtn.addEventListener("click", closeDrawer);

  function toggleViewMode(forcedMode) {
    state.quizMode = forcedMode || (state.quizMode === "cbt" ? "all" : "cbt");
    const isCbt = state.quizMode === "cbt";
    quizCbtSingleView.classList.toggle("hidden", !isCbt);
    quizAllContainer.classList.toggle("hidden", isCbt);
    quizToggleViewModeBtn.textContent = isCbt ? "Mode Semua Soal" : "Mode Per Soal (CBT)";
    if (isCbt) {
      renderCbtSingleQuestion(state.currentQuestionIndex);
    } else if (!state.allQuestionsRendered && state.session && state.session.quiz) {
      renderAllQuestionsView(state.session.quiz);
      state.allQuestionsRendered = true;
    }
  }

  quizToggleViewModeBtn.addEventListener("click", () => toggleViewMode());

  quizPrevBtn.addEventListener("click", () => {
    if (state.currentQuestionIndex > 0) {
      renderCbtSingleQuestion(state.currentQuestionIndex - 1);
    }
  });

  quizNextBtn.addEventListener("click", () => {
    if (state.currentQuestionIndex < state.questions.length - 1) {
      renderCbtSingleQuestion(state.currentQuestionIndex + 1);
    }
  });

  if (drawerQuickSubmitBtn) {
    drawerQuickSubmitBtn.addEventListener("click", () => {
      closeDrawer();
      submitQuizBtn.click();
    });
  }

  document.addEventListener("keydown", (e) => {
    if (state.activeTab !== "quiz" || sessionView.classList.contains("hidden") || state.quizExpired) return;
    if (e.target.tagName === "TEXTAREA" || e.target.tagName === "INPUT") return;

    if (e.key === "ArrowLeft") {
      e.preventDefault();
      if (state.currentQuestionIndex > 0) {
        renderCbtSingleQuestion(state.currentQuestionIndex - 1);
      }
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      if (state.currentQuestionIndex < state.questions.length - 1) {
        renderCbtSingleQuestion(state.currentQuestionIndex + 1);
      }
    } else if (["a", "b", "c", "d", "1", "2", "3", "4"].includes(e.key.toLowerCase())) {
      const q = state.questions[state.currentQuestionIndex];
      if (q && q.type === "mcq") {
        const keyMap = { "1": "A", "2": "B", "3": "C", "4": "D", a: "A", b: "B", c: "C", d: "D" };
        const chosenLetter = keyMap[e.key.toLowerCase()];
        if (chosenLetter) {
          const optEl = cbtMcqContainer.querySelector(`[data-letter="${chosenLetter}"]`);
          if (optEl) optEl.click();
        }
      }
    }
  });

  /* ==========================================================================
     Results & Scoring
     ========================================================================== */
  function renderResult(res) {
    state.lastResult = res;
    stopQuizTimer();
    resultTotalScore.textContent = res.total_score;
    resultGradeLabel.textContent = res.grade_label;
    resultBreakdown.textContent = `Pilihan Ganda: ${res.mcq_correct}/${res.mcq_total} Benar | Nilai Essay: ${res.essay_score}/100`;
    resultOverallFeedback.textContent =
      res.overall_feedback || "Kerja bagus! Terus latih pemahamanmu dengan mengulas kembali materi.";

    const focus = Array.isArray(res.review_focus) ? res.review_focus : [];
    if (focus.length) {
      reviewFocusWrap.classList.remove("hidden");
      reviewFocusList.innerHTML = focus.map((f) => `<li>${escapeHtml(f)}</li>`).join("");
    } else {
      reviewFocusWrap.classList.add("hidden");
    }

    mcqResultList.innerHTML = (res.mcq_results || [])
      .map((item) => {
        const isOk = item.is_correct;
        const tagText = isOk ? "Benar" : "Salah";
        const userOptText = (item.options && item.options[item.user_answer]) || "";
        const correctOptText = (item.options && item.options[item.correct_option]) || "";
        return `
          <div class="res-card ${isOk ? "correct" : "wrong"}">
            <div class="res-head">
              <p class="q-text" style="margin:0"><span class="q-num">${item.id}.</span>${escapeHtml(item.question)}</p>
              <span class="res-tag ${isOk ? "ok" : "bad"}">${tagText}</span>
            </div>
            <div class="res-meta">
              Jawaban kamu: <strong>${escapeHtml(item.user_answer || "-")}</strong>${userOptText ? ` (${escapeHtml(userOptText)})` : ""}
              ${
                isOk
                  ? ""
                  : `<br/>Kunci jawaban: <strong style="color:var(--accent)">${escapeHtml(item.correct_option)}</strong> (${escapeHtml(correctOptText)})`
              }
            </div>
            <div class="res-exp">
              <strong>Pembahasan:</strong> ${escapeHtml(item.explanation)}
            </div>
          </div>
        `;
      })
      .join("");

    essayResultList.innerHTML = (res.essay_results || [])
      .map((item) => {
        const isOk = item.score >= 70;
        return `
          <div class="res-card ${isOk ? "correct" : "wrong"}">
            <div class="res-head">
              <p class="q-text" style="margin:0"><span class="q-num">E${item.id}.</span>${escapeHtml(item.question)}</p>
              <span class="res-tag ${isOk ? "ok" : "bad"}">Nilai ${item.score}/100</span>
            </div>
            <div class="res-meta"><strong>Jawaban kamu:</strong> ${escapeHtml(item.user_answer || "(Tidak dijawab)")}</div>
            <div class="res-exp">
              <strong>Evaluasi:</strong> ${escapeHtml(item.feedback)}<br/>
              <strong style="display:inline-block; margin-top:6px; color:var(--accent)">Jawaban Ideal:</strong> ${escapeHtml(item.model_answer)}
            </div>
          </div>
        `;
      })
      .join("");


  }

  /* ==========================================================================
     Tab Switching & Async Quiz Polling (Anti-Timeout Cloudflare)
     ========================================================================== */
  function switchTab(tabName) {
    state.activeTab = tabName;
    const isQuiz = tabName === "quiz";
    document.body.classList.toggle("quiz-active", isQuiz);
    if (floatingHelpBtn) {
      floatingHelpBtn.classList.toggle("hidden", isQuiz);
    }
    const tabs = [
      { el: tabMaterial, name: "material", panel: materialPanel },
      { el: tabQuiz, name: "quiz", panel: quizPanel },
      { el: tabResult, name: "result", panel: resultPanel },
    ];
    tabs.forEach(({ el, name, panel }) => {
      const active = tabName === name;
      el.classList.toggle("active", active);
      el.setAttribute("aria-selected", String(active));
      panel.classList.toggle("hidden", !active);
    });

    if (isQuiz && state.session && state.session.quiz) {
      initOrResumeQuizTimer();
    } else {
      stopQuizTimer();
    }

    window.scrollTo(0, 0);
  }

  async function pollQuizUntilReady(sessionId, maxWaitMs = 95000) {
    const start = Date.now();
    activePollCancelled = false;

    while (Date.now() - start < maxWaitMs) {
      if (activePollCancelled) {
        throw new Error("Pembuatan kuis dibatalkan.");
      }
      await new Promise((resolve) => setTimeout(resolve, 1500));
      if (activePollCancelled) {
        throw new Error("Pembuatan kuis dibatalkan.");
      }

      const resp = await fetchWithTimeout(
        `/api/sessions/${encodeURIComponent(sessionId)}/quiz/status`,
        {},
        20000
      );
      const data = await safeParseJson(resp);

      if (data.status === "ready" && data.quiz) {
        return data.quiz;
      }
      if (data.status === "error") {
        throw new Error(data.error || "Gagal membuat kuis. Silakan coba lagi.");
      }
      if (!resp.ok && data.error) {
        throw new Error(data.error);
      }
    }

    throw new Error("Pembuatan kuis memakan waktu terlalu lama. Silakan coba klik lagi.");
  }

  async function requestQuizGeneration(regenerate = false) {
    if (!state.session) return;
    hideError();
    stopSilentQuizPrefetch();
    stopQuizTimer();

    const loadingHeading = regenerate
      ? "Membuat paket soal baru yang berbeda..."
      : "Menyusun paket kuis CBT...";
    showLoading(loadingHeading, "", "quiz");

    try {
      const resp = await fetchWithTimeout(
        `/api/sessions/${encodeURIComponent(state.session.id)}/quiz`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ regenerate }),
        },
        30000
      );
      const data = await safeParseJson(resp);
      if (!resp.ok && resp.status !== 202) {
        throw new Error(data.error || "Gagal membuat kuis.");
      }

      let quiz = null;
      if (data.status === "ready" && data.quiz) {
        quiz = data.quiz;
      } else {
        quiz = await pollQuizUntilReady(state.session.id);
      }

      state.session.quiz = quiz;
      state.session.has_quiz = true;

      if (regenerate) {
        state.mcqAnswers = {};
        state.essayAnswers = {};
        state.currentQuestionIndex = 0;
        state.quizExpired = false;
        state.lastResult = null;
        try {
          localStorage.removeItem(draftKey(state.session.id));
        } catch {}
        clearTimerRecord(state.session.id);
        tabResult.classList.add("hidden");
      } else {
        loadQuizDraft(state.session.id, quiz.quiz_id);
      }

      const startQuizSpan = startQuizBtn.querySelector("span");
      if (startQuizSpan) startQuizSpan.textContent = "Kerjakan Kuis CBT (7 Menit)";

      await finishLoadingAndSwitch(
        "session",
        () => {
          renderQuiz(quiz);
          switchTab("quiz");
          if (regenerate) {
            showToast("Paket soal baru siap! Waktu 7 menit dimulai.");
          }
        },
        "Kuis siap dikerjakan."
      );
    } catch (err) {
      setView("session");
      switchTab("material");
      showError(err.message);
    }
  }

  async function openSession(sessionId, pushUrl = true) {
    hideError();
    showLoading("Membuka sesi belajar...", "", "open");
    try {
      const resp = await fetchWithTimeout(`/api/sessions/${encodeURIComponent(sessionId)}`);
      const data = await safeParseJson(resp);
      if (!resp.ok) {
        throw new Error(data.error || "Sesi tidak ditemukan.");
      }
      state.session = data;
      state.lastResult = null;
      state.quizExpired = false;
      state.currentQuestionIndex = 0;
      loadQuizDraft(data.id, data.quiz ? data.quiz.quiz_id : null);
      saveToHistory(data);

      await finishLoadingAndSwitch(
        "session",
        () => {
          renderMaterial(data);
          tabResult.classList.add("hidden");
          if (pushUrl) {
            window.history.pushState({ sessionId: data.id }, "", `/s/${data.id}`);
          }
          document.title = `${data.title} | KisiKit`;
          switchTab("material");
        },
        "Materi siap."
      );
    } catch (err) {
      setView("home");
      showError(err.message);
    }
  }

  async function ensureQuizAndOpen() {
    if (!state.session) return;
    hideError();

    if (state.session.quiz) {
      renderQuiz(state.session.quiz);
      switchTab("quiz");
      return;
    }

    await requestQuizGeneration(false);
  }

  /* ==========================================================================
     Form Submissions & Event Listeners
     ========================================================================== */
  errorCloseBtn.addEventListener("click", hideError);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (!errorBanner.classList.contains("hidden")) hideError();
      if (!quizDrawerModal.classList.contains("hidden")) closeDrawer();
      if (helpModal && !helpModal.classList.contains("hidden")) closeHelpModal();
      if (apiKeyModal && !apiKeyModal.classList.contains("hidden")) closeApiKeyModal();
    }
  });

  document.querySelectorAll(".toggle-opt").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".toggle-opt").forEach((b) => {
        b.classList.remove("active");
        b.setAttribute("aria-pressed", "false");
      });
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
      state.style = btn.dataset.style;
    });
  });

  function setSelectedFile(file) {
    state.selectedFile = file || null;
    if (file) {
      uploadLabel.textContent = file.name;
      uploadBox.classList.add("has-file");
      clearFileBtn.classList.remove("hidden");
    } else {
      fileInput.value = "";
      uploadLabel.textContent = "Klik untuk unggah atau seret file kisi-kisi ke sini";
      uploadBox.classList.remove("has-file");
      clearFileBtn.classList.add("hidden");
    }
  }

  fileInput.addEventListener("change", () => {
    setSelectedFile(fileInput.files[0]);
  });

  clearFileBtn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedFile(null);
  });

  uploadBox.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadBox.classList.add("drag-over");
  });
  uploadBox.addEventListener("dragleave", () => uploadBox.classList.remove("drag-over"));
  uploadBox.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadBox.classList.remove("drag-over");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
    }
  });

  if (loadingCancel) {
    loadingCancel.addEventListener("click", () => {
      activePollCancelled = true;
      if (activeAbortController) {
        activeAbortController.abort();
        activeAbortController = null;
      }
      if (state.session) {
        setView("session");
        switchTab("material");
      } else {
        setView("home");
      }
      generateBtn.disabled = false;
      showError("Proses dibatalkan.");
    });
  }

  createForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (isCreatingSession) return;
    hideError();
    const text = topicInput.value.trim();
    if (!text && !state.selectedFile) {
      showError("Ketik topik ujian atau unggah file kisi-kisi terlebih dahulu.");
      topicInput.focus();
      return;
    }
    if (loadedApiKeyCount === 0) {
      await refreshApiKeyStatus();
      if (loadedApiKeyCount === 0) {
        showToast("Atur API Key Google AI Studio terlebih dahulu.");
        openApiKeyModal();
        return;
      }
    }

    const fd = new FormData();
    fd.append("text", text);
    fd.append("style", state.style);
    if (state.selectedFile) {
      fd.append("file", state.selectedFile);
    }

    isCreatingSession = true;
    generateBtn.disabled = true;
    showLoading("Menyusun catatan & kuis...", "", "generate");

    try {
      const resp = await fetchWithTimeout("/api/sessions", {
        method: "POST",
        body: fd,
      });
      const data = await safeParseJson(resp);
      if (!resp.ok) {
        throw new Error(data.error || "Gagal menyusun materi.");
      }

      topicInput.value = "";
      setSelectedFile(null);

      state.session = data;
      state.mcqAnswers = {};
      state.essayAnswers = {};
      state.lastResult = null;
      state.quizExpired = false;
      state.currentQuestionIndex = 0;
      saveToHistory(data);

      await finishLoadingAndSwitch(
        "session",
        () => {
          renderMaterial(data);
          tabResult.classList.add("hidden");
          window.history.pushState({ sessionId: data.id }, "", `/s/${data.id}`);
          document.title = `${data.title} | KisiKit`;
          switchTab("material");
        },
        "Rangkuman selesai!"
      );
    } catch (err) {
      setView("home");
      showError(err.message);
    } finally {
      isCreatingSession = false;
      generateBtn.disabled = false;
    }
  });

  startQuizBtn.addEventListener("click", ensureQuizAndOpen);
  tabMaterial.addEventListener("click", () => switchTab("material"));
  tabQuiz.addEventListener("click", ensureQuizAndOpen);
  tabResult.addEventListener("click", () => {
    if (state.lastResult) switchTab("result");
  });

  if (regenerateQuizBtn) {
    regenerateQuizBtn.addEventListener("click", () => requestQuizGeneration(true));
  }
  if (emptyGenerateQuizBtn) {
    emptyGenerateQuizBtn.addEventListener("click", () => requestQuizGeneration(true));
  }
  if (expiredBackMaterialBtn) {
    expiredBackMaterialBtn.addEventListener("click", () => switchTab("material"));
  }

  quizForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (isGradingQuiz || !state.session || !state.session.quiz || state.quizExpired) return;
    hideError();

    let unansweredCount = 0;
    for (const q of state.session.quiz.mcq || []) {
      if (!state.mcqAnswers[String(q.id)]) unansweredCount++;
    }
    for (const q of state.session.quiz.essay || []) {
      if (!(state.essayAnswers[String(q.id)] || "").trim()) unansweredCount++;
    }

    if (unansweredCount > 0) {
      const confirmSubmit = confirm(
        `Masih ada ${unansweredCount} soal yang belum kamu jawab. Tetap ingin mengumpulkan jawaban dan melihat nilai?`
      );
      if (!confirmSubmit) {
        openDrawer();
        return;
      }
    }

    isGradingQuiz = true;
    submitQuizBtn.disabled = true;
    stopQuizTimer();
    showLoading("Menilai jawaban kuis...", "", "grade");

    try {
      const resp = await fetchWithTimeout(
        `/api/sessions/${encodeURIComponent(state.session.id)}/grade`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            mcq_answers: state.mcqAnswers,
            essay_answers: state.essayAnswers,
          }),
        }
      );
      const data = await safeParseJson(resp);
      if (!resp.ok) {
        throw new Error(data.error || "Gagal mengevaluasi kuis.");
      }

      await finishLoadingAndSwitch(
        "session",
        () => {
          renderResult(data);
          tabResult.classList.remove("hidden");
          switchTab("result");
        },
        "Penilaian selesai."
      );
    } catch (err) {
      setView("session");
      switchTab("quiz");
      showError(err.message);
    } finally {
      isGradingQuiz = false;
      submitQuizBtn.disabled = false;
    }
  });

  backToMaterialBtn.addEventListener("click", () => switchTab("material"));
  retakeQuizBtn.addEventListener("click", () => {
    if (!state.session) return;
    requestQuizGeneration(true);
  });

  copyLinkBtn.addEventListener("click", async () => {
    if (!state.session) return;
    const shareUrl = `${window.location.origin}/s/${state.session.id}`;
    if (window.FlutterClipboardChannel && typeof window.FlutterClipboardChannel.postMessage === "function") {
      try {
        window.FlutterClipboardChannel.postMessage(shareUrl);
        showToast("Link sesi berhasil disalin!");
        return;
      } catch {}
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast("Link sesi berhasil disalin!");
    } catch {
      const tmp = document.createElement("input");
      tmp.value = shareUrl;
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand("copy");
      document.body.removeChild(tmp);
      showToast("Link sesi berhasil disalin!");
    }
  });

  function goHome(pushUrl = true) {
    hideError();
    stopSilentQuizPrefetch();
    stopQuizTimer();
    state.session = null;
    if (pushUrl) {
      window.history.pushState({}, "", "/");
    }
    document.title = "KisiKit - Belajar Cepat & Kuis CBT Sebelum Ujian";
    renderHistory();
    setView("home");
  }

  newSessionBtn.addEventListener("click", () => goHome(true));
  brandLink.addEventListener("click", (e) => {
    e.preventDefault();
    goHome(true);
  });
  if (backHomeLink) {
    backHomeLink.addEventListener("click", (e) => {
      e.preventDefault();
      goHome(true);
    });
  }

  historyList.addEventListener("click", (e) => {
    const link = e.target.closest(".history-item");
    if (!link) return;
    e.preventDefault();
    openSession(link.dataset.sessionId, true);
  });

  clearHistoryBtn.addEventListener("click", () => {
    historyCache = [];
    localStorage.removeItem(HISTORY_KEY);
    renderHistory();
  });

  /* ==========================================================================
     Floating Help Modal
     ========================================================================== */
  let helpCloseTimer = null;

  function openHelpModal() {
    if (!helpModal) return;
    clearTimeout(helpCloseTimer);
    helpModal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => {
      helpModal.classList.add("is-open");
    });
  }

  function closeHelpModal() {
    if (!helpModal || helpModal.classList.contains("hidden")) return;
    helpModal.classList.remove("is-open");
    clearTimeout(helpCloseTimer);
    helpCloseTimer = setTimeout(() => {
      helpModal.classList.add("hidden");
      if (
        (!quizDrawerModal || quizDrawerModal.classList.contains("hidden")) &&
        (!apiKeyModal || apiKeyModal.classList.contains("hidden"))
      ) {
        document.body.style.overflow = "";
      }
    }, 180);
  }

  if (floatingHelpBtn) floatingHelpBtn.addEventListener("click", openHelpModal);
  if (helpModalBackdrop) helpModalBackdrop.addEventListener("click", closeHelpModal);
  if (helpModalCloseBtn) helpModalCloseBtn.addEventListener("click", closeHelpModal);

  window.addEventListener("popstate", () => {
    const match = window.location.pathname.match(/^\/s\/([a-zA-Z0-9_-]+)$/);
    if (match) {
      openSession(match[1], false);
    } else {
      goHome(false);
    }
  });

  /* ==========================================================================
     API Key Manager (On-Device Rust Engine) & Native Android Back Handler
     ========================================================================== */
  const apiKeyBtn = document.getElementById("apiKeyBtn");
  const apiKeyDot = document.getElementById("apiKeyDot");
  const apiKeyModal = document.getElementById("apiKeyModal");
  const apiKeyModalBackdrop = document.getElementById("apiKeyModalBackdrop");
  const apiKeyModalCloseBtn = document.getElementById("apiKeyModalCloseBtn");
  const apiKeyStatusBadge = document.getElementById("apiKeyStatusBadge");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const apiKeyMaskedList = document.getElementById("apiKeyMaskedList");
  const saveApiKeyBtn = document.getElementById("saveApiKeyBtn");
  let loadedApiKeyCount = 0;

  async function refreshApiKeyStatus() {
    try {
      const resp = await fetch("/api/keys");
      if (!resp.ok) return;
      const data = await safeParseJson(resp);
      loadedApiKeyCount = Number(data.count || 0);
      if (apiKeyDot) {
        apiKeyDot.classList.toggle("is-ready", loadedApiKeyCount > 0);
      }
      if (apiKeyStatusBadge) {
        apiKeyStatusBadge.textContent =
          loadedApiKeyCount > 0 ? `${loadedApiKeyCount} Key Aktif` : "Belum diatur";
      }
      if (apiKeyMaskedList) {
        const masked = Array.isArray(data.masked) ? data.masked : [];
        if (masked.length > 0) {
          apiKeyMaskedList.classList.remove("hidden");
          apiKeyMaskedList.innerHTML = masked
            .map((k) => `<span class="api-key-chip">${escapeHtml(k)}</span>`)
            .join("");
        } else {
          apiKeyMaskedList.classList.add("hidden");
          apiKeyMaskedList.innerHTML = "";
        }
      }
    } catch {}
  }

  // Register lightweight native haptic feedback ONCE (fixed memory leak)
  if (window.FlutterHapticChannel && typeof window.FlutterHapticChannel.postMessage === "function") {
    document.addEventListener("pointerdown", (e) => {
      const target = e.target.closest("button, .cbt-option-item, .tab-pill, .toggle-opt, .history-item, .cbt-grid-tile");
      if (!target || target.disabled) return;
      try {
        window.FlutterHapticChannel.postMessage(target.classList.contains("btn-primary") ? "impact" : "click");
      } catch {}
    }, { passive: true });
  }

  let apiKeyCloseTimer = null;

  function openApiKeyModal() {
    if (!apiKeyModal) return;
    clearTimeout(apiKeyCloseTimer);
    refreshApiKeyStatus();
    apiKeyModal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => {
      apiKeyModal.classList.add("is-open");
    });
  }

  function closeApiKeyModal() {
    if (!apiKeyModal || apiKeyModal.classList.contains("hidden")) return;
    apiKeyModal.classList.remove("is-open");
    clearTimeout(apiKeyCloseTimer);
    apiKeyCloseTimer = setTimeout(() => {
      apiKeyModal.classList.add("hidden");
      if (
        (!helpModal || helpModal.classList.contains("hidden")) &&
        (!quizDrawerModal || quizDrawerModal.classList.contains("hidden"))
      ) {
        document.body.style.overflow = "";
      }
    }, 180);
  }

  if (apiKeyBtn) apiKeyBtn.addEventListener("click", openApiKeyModal);
  if (apiKeyModalBackdrop) apiKeyModalBackdrop.addEventListener("click", closeApiKeyModal);
  if (apiKeyModalCloseBtn) apiKeyModalCloseBtn.addEventListener("click", closeApiKeyModal);

  if (saveApiKeyBtn) {
    saveApiKeyBtn.addEventListener("click", async () => {
      const raw = (apiKeyInput ? apiKeyInput.value : "").trim();
      if (!raw) {
        showToast("Masukkan minimal 1 API Key Gemini terlebih dahulu.");
        return;
      }
      saveApiKeyBtn.disabled = true;
      try {
        const resp = await fetch("/api/keys", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ keys: raw }),
        });
        const data = await safeParseJson(resp);
        if (!resp.ok) {
          throw new Error(data.error || "Gagal menyimpan API Key.");
        }
        if (apiKeyInput) apiKeyInput.value = "";
        await refreshApiKeyStatus();
        closeApiKeyModal();
        showToast(`Berhasil menyimpan ${data.count || 0} API Key aktif!`);
      } catch (err) {
        showToast(err.message || "Gagal menyimpan API Key.");
      } finally {
        saveApiKeyBtn.disabled = false;
      }
    });
  }

  // Native Android back button bridge
  window.__kisikitHandleBack = function () {
    if (apiKeyModal && !apiKeyModal.classList.contains("hidden")) {
      closeApiKeyModal();
      return true;
    }
    if (helpModal && !helpModal.classList.contains("hidden")) {
      closeHelpModal();
      return true;
    }
    if (quizDrawerModal && !quizDrawerModal.classList.contains("hidden")) {
      closeDrawer();
      return true;
    }
    if (!sessionView.classList.contains("hidden")) {
      if (state.activeTab !== "material") {
        switchTab("material");
        return true;
      }
      goHome(true);
      return true;
    }
    return false;
  };

  refreshApiKeyStatus();

  // Single delegated event listeners (zero per-render closure allocations)
  cbtMcqContainer.addEventListener("click", (e) => {
    const item = e.target.closest(".cbt-option-item");
    if (!item || state.quizExpired) return;
    const qObj = state.questions[state.currentQuestionIndex];
    if (!qObj || qObj.type !== "mcq") return;
    const letter = item.dataset.letter;
    state.mcqAnswers[qObj.id] = letter;

    const prevSelected = cbtMcqContainer.querySelector(".cbt-option-item.selected");
    if (prevSelected && prevSelected !== item) {
      prevSelected.classList.remove("selected");
      prevSelected.setAttribute("aria-pressed", "false");
    }
    item.classList.add("selected");
    item.setAttribute("aria-pressed", "true");

    if (state.allQuestionsRendered) {
      const radioInAll = mcqContainer.querySelector(`input[name="mcq_${qObj.id}"][value="${letter}"]`);
      if (radioInAll) {
        radioInAll.checked = true;
        const parentLabel = radioInAll.closest(".opt-label");
        if (parentLabel) {
          radioInAll.closest(".options-grid").querySelectorAll(".opt-label.selected").forEach((lbl) => lbl.classList.remove("selected"));
          parentLabel.classList.add("selected");
        }
      }
    }

    saveQuizDraft(true);
    updateQuizProgress();
  });

  mcqContainer.addEventListener("change", (e) => {
    const input = e.target;
    if (!input || input.type !== "radio" || state.quizExpired) return;
    const qid = input.dataset.qid;
    state.mcqAnswers[String(qid)] = input.value;
    const card = input.closest("[data-mcq-card]");
    if (card) {
      card.querySelectorAll(".opt-label.selected").forEach((lbl) => lbl.classList.remove("selected"));
      const lbl = input.closest(".opt-label");
      if (lbl) lbl.classList.add("selected");
    }
    const curQ = state.questions[state.currentQuestionIndex];
    if (curQ && curQ.type === "mcq" && curQ.id === String(qid)) {
      renderCbtSingleQuestion(state.currentQuestionIndex);
    }
    saveQuizDraft(true);
    updateQuizProgress();
  });

  essayContainer.addEventListener("input", (e) => {
    const ta = e.target;
    if (!ta || ta.tagName !== "TEXTAREA" || state.quizExpired) return;
    const qid = ta.dataset.essayId;
    if (!qid) return;
    state.essayAnswers[String(qid)] = ta.value;
    const curQ = state.questions[state.currentQuestionIndex];
    if (curQ && curQ.type === "essay" && curQ.id === String(qid)) {
      cbtEssayInput.value = ta.value;
      cbtEssayCharCount.textContent = `${ta.value.length} karakter`;
    }
    saveQuizDraft(true);
    updateQuizProgress();
  });

  quizDrawerModal.addEventListener("click", (e) => {
    const btn = e.target.closest(".cbt-grid-tile");
    if (!btn) return;
    const idx = parseInt(btn.dataset.qIdx, 10);
    if (!isNaN(idx)) {
      if (state.quizMode !== "cbt") {
        toggleViewMode("cbt");
      }
      renderCbtSingleQuestion(idx);
      closeDrawer();
      window.scrollTo(0, 0);
    }
  });

  // Pause timers when app goes to background & resync accurately on return
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      stopQuizTimer();
    } else if (state.activeTab === "quiz" && state.session && state.session.quiz && !state.quizExpired) {
      initOrResumeQuizTimer();
    }
  });

  /* ==========================================================================
     Initialization
     ========================================================================== */
  initTheme();
  renderHistory();
  const initialId = document.body.dataset.initialSession;
  if (initialId) {
    openSession(initialId, false).then(() => {
      const hash = window.location.hash;
      const tabParam = new URLSearchParams(window.location.search).get("tab");
      if (hash.includes("quiz") || tabParam === "quiz") {
        ensureQuizAndOpen().then(() => {
          if (hash.includes("drawer")) {
            setTimeout(openDrawer, 300);
          }
        });
      }
    });
  } else {
    setView("home");
  }
})();
