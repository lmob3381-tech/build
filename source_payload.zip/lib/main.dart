import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'core/gemini_client.dart';
import 'core/local_server.dart';
import 'core/storage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KisiKitApp());
}

class KisiKitApp extends StatelessWidget {
  const KisiKitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KisiKit',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
      ),
      home: const KisiKitHomePage(),
    );
  }
}

class KisiKitHomePage extends StatefulWidget {
  const KisiKitHomePage({super.key});

  @override
  State<KisiKitHomePage> createState() => _KisiKitHomePageState();
}

class _KisiKitHomePageState extends State<KisiKitHomePage> {
  LocalServer? _server;
  GeminiClient? _gemini;
  WebViewController? _controller;
  bool _ready = false;
  bool _isDark = false;
  String? _bootError;
  DateTime? _lastBackPress;

  @override
  void initState() {
    super.initState();
    _applySystemUi(false);
    _boot();
  }

  void _applySystemUi(bool isDark) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: isDark ? const Color(0xFF0B0F19) : Colors.white,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarColor:
            isDark ? const Color(0xFF0B0F19) : Colors.white,
        systemNavigationBarIconBrightness:
            isDark ? Brightness.light : Brightness.dark,
      ),
    );
  }

  Future<void> _boot() async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final storage = LocalStorage(docsDir);
      final gemini = GeminiClient(storage);
      final server = LocalServer(storage: storage, gemini: gemini);
      final port = await server.start();

      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFFF8FAFC))
        ..addJavaScriptChannel(
          'FlutterThemeChannel',
          onMessageReceived: (JavaScriptMessage msg) {
            final dark = msg.message == 'dark';
            if (mounted && dark != _isDark) {
              setState(() => _isDark = dark);
            }
            _applySystemUi(dark);
            _controller?.setBackgroundColor(
              dark ? const Color(0xFF0B0F19) : const Color(0xFFF8FAFC),
            );
          },
        )
        ..addJavaScriptChannel(
          'FlutterClipboardChannel',
          onMessageReceived: (JavaScriptMessage msg) {
            Clipboard.setData(ClipboardData(text: msg.message));
          },
        )
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (NavigationRequest req) {
              final uri = Uri.tryParse(req.url);
              if (uri == null) return NavigationDecision.navigate;
              if (uri.host == '127.0.0.1' || uri.host == 'localhost') {
                return NavigationDecision.navigate;
              }
              launchUrl(uri, mode: LaunchMode.externalApplication);
              return NavigationDecision.prevent;
            },
          ),
        );

      final platform = controller.platform;
      if (platform is AndroidWebViewController) {
        await platform.setOnShowFileSelector(_pickFileForWebView);
      }

      await controller.loadRequest(Uri.parse('http://127.0.0.1:$port/'));

      if (!mounted) {
        await server.stop();
        gemini.dispose();
        return;
      }

      setState(() {
        _gemini = gemini;
        _server = server;
        _controller = controller;
        _ready = true;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _bootError = 'Gagal memulai KisiKit: $e';
        });
      }
    }
  }

  Future<List<String>> _pickFileForWebView(FileSelectorParams params) async {
    try {
      final file = await FilePicker.pickFile(
        type: FileType.any,
      );
      final path = file?.path;
      if (path != null && path.isNotEmpty) {
        return <String>[Uri.file(path).toString()];
      }
    } catch (_) {}
    return <String>[];
  }

  Future<void> _handleBackPress() async {
    final controller = _controller;
    if (controller != null) {
      try {
        final handled = await controller.runJavaScriptReturningResult(
          '(function(){ return window.__kisikitHandleBack ? window.__kisikitHandleBack() : false; })();',
        );
        if (handled == true || handled == 'true') {
          return;
        }
      } catch (_) {}

      if (await controller.canGoBack()) {
        await controller.goBack();
        return;
      }
    }

    final now = DateTime.now();
    if (_lastBackPress != null &&
        now.difference(_lastBackPress!) < const Duration(seconds: 2)) {
      await SystemNavigator.pop();
      return;
    }
    _lastBackPress = now;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tekan kembali sekali lagi untuk keluar'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  void dispose() {
    _server?.stop();
    _gemini?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bgColor =
        _isDark ? const Color(0xFF0B0F19) : const Color(0xFFF8FAFC);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          _handleBackPress();
        }
      },
      child: Scaffold(
        backgroundColor: bgColor,
        body: SafeArea(
          child: _bootError != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _bootError!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15),
                    ),
                  ),
                )
              : (!_ready || _controller == null)
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(
                            color: Color(0xFF2563EB),
                          ),
                          SizedBox(height: 16),
                          Text(
                            'Memuat KisiKit...',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF334155),
                            ),
                          ),
                        ],
                      ),
                    )
                  : WebViewWidget(controller: _controller!),
        ),
      ),
    );
  }
}
