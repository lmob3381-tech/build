import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'core/gemini_client.dart';
import 'core/local_server.dart';
import 'core/storage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KisiKitApp());
}

class KisiKitApp extends StatelessWidget {
  const KisiKitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KisiKit',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        scaffoldBackgroundColor: const Color(0xFF090F2A),
      ),
      home: const KisiKitHomePage(),
    );
  }
}

class KisiKitHomePage extends StatefulWidget {
  const KisiKitHomePage({super.key});

  @override
  State<KisiKitHomePage> createState() => _KisiKitHomePageState();
}

class _KisiKitHomePageState extends State<KisiKitHomePage> {
  static const MethodChannel _notifChannel =
      MethodChannel('com.kisikit/notifications');

  LocalServer? _server;
  GeminiClient? _gemini;
  WebViewController? _controller;
  bool _webReady = false;
  bool _showSplash = true;
  bool _isDark = false;
  String? _bootError;
  DateTime? _lastBackPress;
  DateTime _splashStartedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _splashStartedAt = DateTime.now();
    _applySplashSystemUi();
    _ensureStudyReminders();
    _boot();
  }

  void _applySplashSystemUi() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Color(0xFF090F2A),
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Color(0xFF090F2A),
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    );
  }

  void _applySystemUi(bool isDark) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: isDark ? const Color(0xFF0B0F19) : Colors.white,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        systemNavigationBarColor:
            isDark ? const Color(0xFF0B0F19) : Colors.white,
        systemNavigationBarIconBrightness:
            isDark ? Brightness.light : Brightness.dark,
      ),
    );
  }

  Future<void> _ensureStudyReminders() async {
    try {
      await _notifChannel.invokeMethod<int>('ensureScheduled');
    } catch (_) {
      // Aman diabaikan di platform non-Android
    }
  }

  Future<void> _dismissSplashSmoothly() async {
    if (!mounted || !_showSplash) return;
    final elapsed = DateTime.now().difference(_splashStartedAt);
    const minSplash = Duration(milliseconds: 900);
    if (elapsed < minSplash) {
      await Future<void>.delayed(minSplash - elapsed);
    }
    if (!mounted) return;
    setState(() => _showSplash = false);
    _applySystemUi(_isDark);
  }

  Future<void> _boot() async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final storage = LocalStorage(docsDir);
      final gemini = GeminiClient(storage);
      final server = LocalServer(storage: storage, gemini: gemini);
      final port = await server.start();

      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFFF8FAFC))
        ..addJavaScriptChannel(
          'FlutterThemeChannel',
          onMessageReceived: (JavaScriptMessage msg) {
            final dark = msg.message == 'dark';
            if (mounted && dark != _isDark) {
              setState(() => _isDark = dark);
            }
            if (!_showSplash) {
              _applySystemUi(dark);
            }
            _controller?.setBackgroundColor(
              dark ? const Color(0xFF0B0F19) : const Color(0xFFF8FAFC),
            );
          },
        )
        ..addJavaScriptChannel(
          'FlutterClipboardChannel',
          onMessageReceived: (JavaScriptMessage msg) {
            Clipboard.setData(ClipboardData(text: msg.message));
          },
        )
        ..addJavaScriptChannel(
          'FlutterHapticChannel',
          onMessageReceived: (JavaScriptMessage msg) {
            if (msg.message == 'impact') {
              HapticFeedback.lightImpact();
            } else {
              HapticFeedback.selectionClick();
            }
          },
        )
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageFinished: (_) {
              _dismissSplashSmoothly();
            },
            onNavigationRequest: (NavigationRequest req) {
              final uri = Uri.tryParse(req.url);
              if (uri == null) return NavigationDecision.navigate;
              if (uri.host == '127.0.0.1' || uri.host == 'localhost') {
                return NavigationDecision.navigate;
              }
              launchUrl(uri, mode: LaunchMode.externalApplication);
              return NavigationDecision.prevent;
            },
          ),
        );

      final platform = controller.platform;
      if (platform is AndroidWebViewController) {
        await platform.setOnShowFileSelector(_pickFileForWebView);
      }

      await controller.loadRequest(Uri.parse('http://127.0.0.1:$port/'));

      if (!mounted) {
        await server.stop();
        gemini.dispose();
        return;
      }

      setState(() {
        _gemini = gemini;
        _server = server;
        _controller = controller;
        _webReady = true;
      });

      // Fallback agar splash tidak pernah macet
      Future<void>.delayed(const Duration(seconds: 3), () {
        _dismissSplashSmoothly();
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _bootError = 'Gagal memulai KisiKit: $e';
          _showSplash = false;
        });
      }
    }
  }

  Future<List<String>> _pickFileForWebView(FileSelectorParams params) async {
    try {
      final file = await FilePicker.pickFile(
        type: FileType.any,
      );
      final path = file?.path;
      if (path != null && path.isNotEmpty) {
        return <String>[Uri.file(path).toString()];
      }
    } catch (_) {}
    return <String>[];
  }

  Future<void> _handleBackPress() async {
    final controller = _controller;
    if (controller != null) {
      try {
        final handled = await controller.runJavaScriptReturningResult(
          '(function(){ return window.__kisikitHandleBack ? window.__kisikitHandleBack() : false; })();',
        );
        if (handled == true || handled == 'true') {
          return;
        }
      } catch (_) {}

      if (await controller.canGoBack()) {
        await controller.goBack();
        return;
      }
    }

    final now = DateTime.now();
    if (_lastBackPress != null &&
        now.difference(_lastBackPress!) < const Duration(seconds: 2)) {
      await SystemNavigator.pop();
      return;
    }
    _lastBackPress = now;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tekan kembali sekali lagi untuk keluar'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  void dispose() {
    _server?.stop();
    _gemini?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _showSplash
        ? const Color(0xFF090F2A)
        : (_isDark ? const Color(0xFF0B0F19) : const Color(0xFFF8FAFC));

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          _handleBackPress();
        }
      },
      child: Scaffold(
        backgroundColor: bgColor,
        body: SafeArea(
          child: _bootError != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _bootError!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15),
                    ),
                  ),
                )
              : Stack(
                  fit: StackFit.expand,
                  children: [
                    if (_webReady && _controller != null)
                      WebViewWidget(controller: _controller!),
                    IgnorePointer(
                      ignoring: !_showSplash,
                      child: AnimatedOpacity(
                        opacity: _showSplash ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOut,
                        child: const _KisiKitSplashView(),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _KisiKitSplashView extends StatelessWidget {
  const _KisiKitSplashView();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF090F2A),
            Color(0xFF111C4A),
            Color(0xFF0C1230),
          ],
        ),
      ),
      child: Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.92, end: 1.0),
          duration: const Duration(milliseconds: 420),
          curve: Curves.easeOutCubic,
          builder: (BuildContext context, double scale, Widget? child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 108,
                height: 108,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x553B82F6),
                      blurRadius: 28,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(26),
                  child: Image.asset(
                    'assets/branding/kisikit_logo.png',
                    width: 108,
                    height: 108,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'KisiKit',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: const Color(0x2260A5FA),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0x4460A5FA)),
                ),
                child: const Text(
                  'buatan Ilmi',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.4,
                    color: Color(0xFFBFDBFE),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              const SizedBox(
                width: 112,
                child: ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(999)),
                  child: LinearProgressIndicator(
                    minHeight: 3.5,
                    backgroundColor: Color(0x26FFFFFF),
                    valueColor:
                        AlwaysStoppedAnimation<Color>(Color(0xFF60A5FA)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
