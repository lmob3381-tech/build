import 'dart:convert';
import 'dart:io';
import 'dart:math';

class LocalStorage {
  LocalStorage(this.baseDir) {
    sessionsDir = Directory('${baseDir.path}/sessions');
    keysFile = File('${baseDir.path}/api_keys.txt');
    if (!sessionsDir.existsSync()) {
      sessionsDir.createSync(recursive: true);
    }
  }

  final Directory baseDir;
  late final Directory sessionsDir;
  late final File keysFile;

  static const String _alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
  static final Random _rng = Random.secure();

  static String generateSessionId() {
    final buf = StringBuffer();
    for (int i = 0; i < 10; i++) {
      buf.write(_alphabet[_rng.nextInt(_alphabet.length)]);
    }
    return buf.toString();
  }

  static String generateHexId(int bytes) {
    final buf = StringBuffer();
    for (int i = 0; i < bytes; i++) {
      buf.write(_rng.nextInt(256).toRadixString(16).padLeft(2, '0'));
    }
    return buf.toString();
  }

  File _sessionFile(String sessionId) {
    final safeId = sessionId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '');
    return File('${sessionsDir.path}/$safeId.json');
  }

  int _nowSec() => DateTime.now().millisecondsSinceEpoch ~/ 1000;

  Future<Map<String, dynamic>> createSession({
    required String title,
    required String style,
    required String sourceSummary,
    required String rawContext,
    required Map<String, dynamic> material,
  }) async {
    final sessionId = generateSessionId();
    final now = _nowSec();
    final record = <String, dynamic>{
      'id': sessionId,
      'created_at': now,
      'updated_at': now,
      'title': title,
      'source_summary': sourceSummary,
      'raw_context': rawContext,
      'style': style,
      'material': material,
      'quiz': null,
      'attempt_count': 0,
      'previous_questions': <String>[],
    };

    final file = _sessionFile(sessionId);
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsString(const JsonEncoder.withIndent('  ').convert(record));
    await tmp.rename(file.path);
    return record;
  }

  Future<Map<String, dynamic>?> getSession(String sessionId) async {
    if (sessionId.isEmpty) return null;
    final file = _sessionFile(sessionId);
    if (!await file.exists()) return null;
    try {
      final raw = await file.readAsString();
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        return decoded;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, dynamic>?> updateSession(
    String sessionId,
    Map<String, dynamic> updates,
  ) async {
    final existing = await getSession(sessionId);
    if (existing == null) return null;
    existing.addAll(updates);
    existing['updated_at'] = _nowSec();
    final file = _sessionFile(sessionId);
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsString(const JsonEncoder.withIndent('  ').convert(existing));
    await tmp.rename(file.path);
    return existing;
  }

  List<String> readApiKeys() {
    if (!keysFile.existsSync()) return <String>[];
    try {
      final raw = keysFile.readAsStringSync();
      return parseKeysStr(raw);
    } catch (_) {
      return <String>[];
    }
  }

  Future<List<String>> saveApiKeys(String rawInput) async {
    final keys = parseKeysStr(rawInput);
    final tmp = File('${keysFile.path}.tmp');
    await tmp.writeAsString(keys.join('\n'));
    await tmp.rename(keysFile.path);
    return keys;
  }

  static List<String> parseKeysStr(String raw) {
    return raw
        .split(RegExp(r'[,;\r\n]+'))
        .map((s) => s.trim().replaceAll('"', '').replaceAll("'", ''))
        .where((s) => s.isNotEmpty)
        .toList();
  }
}
