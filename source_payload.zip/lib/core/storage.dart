import 'dart:convert';
import 'dart:io';
import 'dart:math';

class LocalStorage {
  LocalStorage(this.baseDir) {
    sessionsDir = Directory('${baseDir.path}/sessions');
    keysFile = File('${baseDir.path}/api_keys.txt');
  }

  final Directory baseDir;
  late final Directory sessionsDir;
  late final File keysFile;

  List<String> _cachedApiKeys = const <String>[];
  bool _initialized = false;

  static const String _alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
  static final Random _rng = Random.secure();

  /// Async initialization to avoid blocking the Flutter UI isolate on startup.
  Future<void> init() async {
    if (_initialized) return;
    if (!await sessionsDir.exists()) {
      await sessionsDir.create(recursive: true);
    }
    if (await keysFile.exists()) {
      try {
        final raw = await keysFile.readAsString();
        _cachedApiKeys = List<String>.unmodifiable(parseKeysStr(raw));
      } catch (_) {
        _cachedApiKeys = const <String>[];
      }
    }
    _initialized = true;
  }

  static String generateSessionId() {
    final buf = StringBuffer();
    for (int i = 0; i < 10; i++) {
      buf.write(_alphabet[_rng.nextInt(_alphabet.length)]);
    }
    return buf.toString();
  }

  static String generateHexId(int bytes) {
    final buf = StringBuffer();
    for (int i = 0; i < bytes; i++) {
      buf.write(_rng.nextInt(256).toRadixString(16).padLeft(2, '0'));
    }
    return buf.toString();
  }

  File _sessionFile(String sessionId) {
    final safeId = sessionId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '');
    return File('${sessionsDir.path}/$safeId.json');
  }

  int _nowSec() => DateTime.now().millisecondsSinceEpoch ~/ 1000;

  Future<Map<String, dynamic>> createSession({
    required String title,
    required String style,
    required String sourceSummary,
    required String rawContext,
    required Map<String, dynamic> material,
  }) async {
    await init();
    final sessionId = generateSessionId();
    final now = _nowSec();
    final record = <String, dynamic>{
      'id': sessionId,
      'created_at': now,
      'updated_at': now,
      'title': title,
      'source_summary': sourceSummary,
      'raw_context': rawContext,
      'style': style,
      'material': material,
      'quiz': null,
      'attempt_count': 0,
      'previous_questions': <String>[],
    };

    final file = _sessionFile(sessionId);
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsString(jsonEncode(record));
    await tmp.rename(file.path);
    return record;
  }

  Future<Map<String, dynamic>?> getSession(String sessionId) async {
    if (sessionId.isEmpty) return null;
    await init();
    final file = _sessionFile(sessionId);
    if (!await file.exists()) return null;
    try {
      final raw = await file.readAsString();
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        return decoded;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, dynamic>?> updateSession(
    String sessionId,
    Map<String, dynamic> updates,
  ) async {
    final existing = await getSession(sessionId);
    if (existing == null) return null;
    existing.addAll(updates);
    existing['updated_at'] = _nowSec();
    final file = _sessionFile(sessionId);
    final tmp = File('${file.path}.tmp');
    await tmp.writeAsString(jsonEncode(existing));
    await tmp.rename(file.path);
    return existing;
  }

  /// Returns cached API keys in O(1) without synchronous disk I/O on the UI isolate.
  List<String> readApiKeys() => _cachedApiKeys;

  Future<List<String>> saveApiKeys(String rawInput) async {
    await init();
    final keys = parseKeysStr(rawInput);
    final tmp = File('${keysFile.path}.tmp');
    await tmp.writeAsString(keys.join('\n'));
    await tmp.rename(keysFile.path);
    _cachedApiKeys = List<String>.unmodifiable(keys);
    return _cachedApiKeys;
  }

  static List<String> parseKeysStr(String raw) {
    return raw
        .split(RegExp(r'[,;\r\n]+'))
        .map((s) => s.trim().replaceAll('"', '').replaceAll("'", ''))
        .where((s) => s.isNotEmpty)
        .toList();
  }
}
