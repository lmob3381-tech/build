import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:xml/xml.dart';

class ImageAttachment {
  const ImageAttachment({
    required this.mimeType,
    required this.dataB64,
  });

  final String mimeType;
  final String dataB64;
}

class ParsedUpload {
  const ParsedUpload({
    required this.filename,
    required this.text,
    this.image,
  });

  final String filename;
  final String text;
  final ImageAttachment? image;
}

class FileParser {
  static const int maxTextChars = 45000;
  static const int maxImageBytes = 8 * 1024 * 1024; // 8 MB

  static const Map<String, String> _imageMimeTypes = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
  };

  static const Set<String> _textExtensions = {
    '.txt',
    '.md',
    '.csv',
    '.json',
    '.log',
    '',
  };

  static String _extensionOf(String filename) {
    final dot = filename.lastIndexOf('.');
    if (dot < 0 || dot == filename.length - 1) return '';
    return filename.substring(dot).toLowerCase();
  }

  static String _truncate(String s, int maxLen) {
    if (s.length <= maxLen) return s;
    return s.substring(0, maxLen);
  }

  static String _extractDocx(Uint8List rawBytes) {
    final Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(rawBytes);
    } catch (_) {
      throw const FormatException('File .docx tidak valid atau rusak.');
    }

    ArchiveFile? docXml;
    for (final file in archive.files) {
      if (file.name == 'word/document.xml') {
        docXml = file;
        break;
      }
    }
    if (docXml == null) {
      throw const FormatException(
        'File .docx tidak valid (word/document.xml tidak ditemukan).',
      );
    }

    final xmlStr = utf8.decode(
      docXml.content as List<int>,
      allowMalformed: true,
    );
    final document = XmlDocument.parse(xmlStr);
    final paragraphs = <String>[];
    for (final para in document.findAllElements('p', namespace: '*')) {
      final line = para
          .findAllElements('t', namespace: '*')
          .map((node) => node.innerText)
          .join();
      if (line.trim().isNotEmpty) {
        paragraphs.add(line.trim());
      }
    }
    return paragraphs.join('\n').trim();
  }

  static String _extractPdf(Uint8List rawBytes) {
    PdfDocument? document;
    try {
      document = PdfDocument(inputBytes: rawBytes);
      final extractor = PdfTextExtractor(document);
      final pageCount = document.pages.count;
      final pages = <String>[];
      for (int i = 0; i < pageCount; i++) {
        final text = extractor
            .extractText(startPageIndex: i, endPageIndex: i)
            .trim();
        if (text.isNotEmpty) {
          pages.add('[Halaman ${i + 1}]\n$text');
        }
      }
      return pages.join('\n\n').trim();
    } catch (_) {
      throw const FormatException(
        'File PDF tidak dapat dibaca atau terenkripsi.',
      );
    } finally {
      document?.dispose();
    }
  }

  static ParsedUpload parse(String filename, Uint8List rawBytes) {
    final ext = _extensionOf(filename);

    final imgMime = _imageMimeTypes[ext];
    if (imgMime != null) {
      if (rawBytes.length > maxImageBytes) {
        throw const FormatException('Ukuran gambar terlalu besar (maksimal 8 MB).');
      }
      return ParsedUpload(
        filename: filename,
        text: '',
        image: ImageAttachment(
          mimeType: imgMime,
          dataB64: base64Encode(rawBytes),
        ),
      );
    }

    if (ext == '.pdf') {
      final text = _extractPdf(rawBytes);
      if (text.isEmpty) {
        throw const FormatException(
          'PDF ini sepertinya hasil scan/gambar tanpa teks. Coba screenshot halamannya lalu upload sebagai gambar (.jpg/.png).',
        );
      }
      return ParsedUpload(
        filename: filename,
        text: _truncate(text, maxTextChars),
      );
    }

    if (ext == '.docx') {
      final text = _extractDocx(rawBytes);
      if (text.isEmpty) {
        throw const FormatException(
          'File .docx kosong atau tidak memiliki teks yang bisa dibaca.',
        );
      }
      return ParsedUpload(
        filename: filename,
        text: _truncate(text, maxTextChars),
      );
    }

    if (_textExtensions.contains(ext)) {
      String text;
      try {
        text = utf8.decode(rawBytes);
      } catch (_) {
        text = latin1.decode(rawBytes, allowInvalid: true);
      }
      text = text.trim();
      if (text.isEmpty) {
        throw const FormatException('File teks kosong.');
      }
      return ParsedUpload(
        filename: filename,
        text: _truncate(text, maxTextChars),
      );
    }

    throw FormatException(
      "Format file '$ext' belum didukung. Gunakan .pdf, .docx, .txt, .md, atau foto (.jpg, .png, .webp).",
    );
  }
}
