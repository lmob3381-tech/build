import 'dart:async';
import 'dart:convert';
import 'dart:isolate';

import 'package:http/http.dart' as http;

import 'file_parser.dart';
import 'storage.dart';

class GeminiClientException implements Exception {
  const GeminiClientException(this.message);
  final String message;

  @override
  String toString() => message;
}

class _ModelConfig {
  const _ModelConfig(this.model, this.thinkingLevel);
  final String model;
  final String thinkingLevel;
}

class SessionBundleResult {
  const SessionBundleResult({
    required this.material,
    this.quiz,
  });

  final Map<String, dynamic> material;
  final Map<String, dynamic>? quiz;
}

class GeminiClient {
  GeminiClient(this.storage);

  final LocalStorage storage;
  final http.Client _http = http.Client();
  int _keyIndex = 0;
  int _preferredModelIndex = 0;

  static const List<_ModelConfig> _modelConfigs = [
    _ModelConfig('gemini-3.5-flash-lite', 'minimal'),
    _ModelConfig('gemini-3.6-flash', 'minimal'),
    _ModelConfig('gemini-3.1-flash-lite', 'minimal'),
    _ModelConfig('gemini-3.8-flash', 'low'),
    _ModelConfig('gemini-4-hydrogen', 'low'),
  ];

  int keyCount() => storage.readApiKeys().length;

  List<String> _getOrderedKeys() {
    final keys = storage.readApiKeys();
    if (keys.isEmpty) {
      throw const GeminiClientException(
        'API Key Google AI Studio belum diatur. Ketuk ikon kunci di pojok kanan atas untuk memasukkan API Key.',
      );
    }
    final start = _keyIndex % keys.length;
    _keyIndex = (_keyIndex + 1) % keys.length;
    return <String>[
      ...keys.sublist(start),
      ...keys.sublist(0, start),
    ];
  }

  List<int> _getOrderedModelIndices() {
    final n = _modelConfigs.length;
    final start = _preferredModelIndex % n;
    return <int>[
      for (int i = 0; i < n; i++) (start + i) % n,
    ];
  }

  static String _stripMarkdownFences(String text) {
    var cleaned = text.trim();
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replaceFirst(RegExp(r'^```(?:json|JSON)?\s*'), '');
      cleaned = cleaned.replaceFirst(RegExp(r'\s*```$'), '');
    }
    return cleaned.trim();
  }

  static String _stripTrailingCommas(String input) {
    final buf = StringBuffer();
    bool inString = false;
    bool escaped = false;
    final len = input.length;

    for (int i = 0; i < len; i++) {
      final ch = input[i];
      if (inString) {
        buf.write(ch);
        if (escaped) {
          escaped = false;
        } else if (ch == r'\') {
          escaped = true;
        } else if (ch == '"') {
          inString = false;
        }
        continue;
      }

      if (ch == '"') {
        inString = true;
        buf.write(ch);
        continue;
      }

      if (ch == ',') {
        int j = i + 1;
        while (j < len &&
            (input[j] == ' ' ||
                input[j] == '\t' ||
                input[j] == '\n' ||
                input[j] == '\r')) {
          j++;
        }
        if (j < len && (input[j] == ']' || input[j] == '}')) {
          continue;
        }
      }

      buf.write(ch);
    }
    return buf.toString();
  }

  static Map<String, dynamic> _extractJsonBlock(String text) {
    final cleaned = _stripMarkdownFences(text);

    Map<String, dynamic>? tryDecode(String candidate) {
      try {
        final decoded = jsonDecode(candidate);
        if (decoded is Map<String, dynamic>) return decoded;
      } catch (_) {}
      return null;
    }

    final first = tryDecode(cleaned) ?? tryDecode(_stripTrailingCommas(cleaned));
    if (first != null) return first;

    final start = cleaned.indexOf('{');
    final end = cleaned.lastIndexOf('}');
    if (start != -1 && end > start) {
      final sub = cleaned.substring(start, end + 1);
      final parsed = tryDecode(sub) ?? tryDecode(_stripTrailingCommas(sub));
      if (parsed != null) return parsed;
    }

    throw const GeminiClientException(
      'AI tidak mengembalikan format JSON yang valid. Coba ulangi.',
    );
  }

  static Map<String, dynamic> _parseGeminiHttpBody(String rawBody) {
    final decoded = jsonDecode(rawBody);
    if (decoded is! Map<String, dynamic>) {
      throw const GeminiClientException('Respons HTTP 200 bukan objek JSON.');
    }
    final textOut = _extractTextFromCandidates(decoded);
    if (textOut.isEmpty) {
      throw const GeminiClientException('Respons teks dari AI kosong.');
    }
    return _extractJsonBlock(textOut);
  }

  static String _extractTextFromCandidates(Map<String, dynamic> data) {
    final candidates = data['candidates'];
    if (candidates is! List || candidates.isEmpty) return '';
    final first = candidates.first;
    if (first is! Map) return '';
    final content = first['content'];
    if (content is! Map) return '';
    final parts = content['parts'];
    if (parts is! List) return '';

    final buf = StringBuffer();
    for (final part in parts) {
      if (part is Map) {
        final isThought = part['thought'] == true;
        final text = part['text'];
        if (!isThought && text is String && text.isNotEmpty) {
          buf.write(text);
        }
      }
    }
    return buf.toString().trim();
  }

  Future<Map<String, dynamic>> generateJson({
    required String prompt,
    ImageAttachment? imageData,
    double readTimeoutSec = 24.0,
    double deadlineSec = 55.0,
    int? maxOutputTokens,
  }) async {
    final keys = _getOrderedKeys();
    final modelIndices = _getOrderedModelIndices();

    final parts = <Map<String, dynamic>>[];
    if (imageData != null) {
      parts.add({
        'inlineData': {
          'mimeType': imageData.mimeType,
          'data': imageData.dataB64,
        },
      });
    }
    parts.add({'text': prompt});

    var lastError = 'Gagal menghubungi Google AI Studio.';
    final stopwatch = Stopwatch()..start();

    for (final mIdx in modelIndices) {
      final cfg = _modelConfigs[mIdx];
      if (stopwatch.elapsedMilliseconds / 1000.0 >= deadlineSec) {
        lastError =
            'Permintaan ke AI melebihi batas waktu. Coba lagi sebentar lagi.';
        break;
      }

      final genConfig = <String, dynamic>{
        'responseMimeType': 'application/json',
        'thinkingConfig': {
          'thinkingLevel': cfg.thinkingLevel,
        },
      };
      if (maxOutputTokens != null) {
        genConfig['maxOutputTokens'] = maxOutputTokens;
      }

      final payloadMap = {
        'contents': [
          {'role': 'user', 'parts': parts},
        ],
        'generationConfig': genConfig,
      };
      final bodyJson = (imageData != null || prompt.length > 8000)
          ? await Isolate.run(() => jsonEncode(payloadMap))
          : jsonEncode(payloadMap);

      for (int idx = 0; idx < keys.length; idx++) {
        final key = keys[idx];
        final keyNum = idx + 1;
        final remaining =
            deadlineSec - (stopwatch.elapsedMilliseconds / 1000.0);
        if (remaining <= 3.0) {
          lastError =
              'Permintaan ke AI melebihi batas waktu. Coba lagi sebentar lagi.';
          break;
        }

        final reqTimeoutSec = readTimeoutSec < remaining
            ? readTimeoutSec
            : (remaining < 8.0 ? 8.0 : remaining);
        final uri = Uri.https(
          'generativelanguage.googleapis.com',
          '/v1beta/models/${cfg.model}:generateContent',
          {'key': key},
        );

        final reqWatch = Stopwatch()..start();
        http.Response resp;
        try {
          resp = await _http
              .post(
                uri,
                headers: const {
                  'Content-Type': 'application/json',
                  'Accept-Encoding': 'gzip',
                },
                body: bodyJson,
              )
              .timeout(Duration(milliseconds: (reqTimeoutSec * 1000).round()));
        } on TimeoutException {
          final dt = (reqWatch.elapsedMilliseconds / 1000.0).toStringAsFixed(1);
          lastError =
              '[${cfg.model} | key#$keyNum | ${dt}s] Respons model terlalu lama.';
          break;
        } catch (e) {
          final dt = (reqWatch.elapsedMilliseconds / 1000.0).toStringAsFixed(1);
          lastError =
              '[${cfg.model} | key#$keyNum | ${dt}s] Koneksi gagal: $e';
          break;
        }

        if (resp.statusCode == 200) {
          try {
            final rawBody = resp.body;
            final parsed = rawBody.length > 4096
                ? await Isolate.run(() => _parseGeminiHttpBody(rawBody))
                : _parseGeminiHttpBody(rawBody);
            _preferredModelIndex = mIdx;
            return parsed;
          } on GeminiClientException catch (e) {
            lastError = '[${cfg.model}] ${e.message}';
            continue;
          } catch (e) {
            lastError = '[${cfg.model}] Respons HTTP 200 bukan JSON valid: $e';
            continue;
          }
        }

        String errMsg;
        try {
          final decoded = jsonDecode(resp.body);
          if (decoded is Map &&
              decoded['error'] is Map &&
              decoded['error']['message'] is String) {
            errMsg = decoded['error']['message'] as String;
          } else {
            errMsg = resp.body.length > 200
                ? resp.body.substring(0, 200)
                : resp.body;
          }
        } catch (_) {
          errMsg = resp.body.length > 200
              ? resp.body.substring(0, 200)
              : resp.body;
        }

        lastError = '[${cfg.model} | HTTP ${resp.statusCode}] $errMsg';

        if (resp.statusCode == 404 ||
            resp.statusCode == 500 ||
            resp.statusCode == 503) {
          break;
        }
        if (resp.statusCode == 400) {
          final lower = errMsg.toLowerCase();
          if (lower.contains('api key') || lower.contains('key not valid')) {
            continue;
          }
          break;
        }
        if (resp.statusCode == 429 || resp.statusCode == 403) {
          if (keys.length == 1) {
            await Future<void>.delayed(const Duration(milliseconds: 500));
          }
          continue;
        }
      }
    }

    throw GeminiClientException(lastError);
  }

  /// Menyusun Materi + 15 Pilihan Ganda + 5 Essay SECARA PARALEL BERSAMAAN
  Future<SessionBundleResult> buildSessionBundle({
    required String topicText,
    ImageAttachment? imageData,
    String style = 'santai',
  }) async {
    final trimmedTopic = topicText.trim();
    final sourceBlock = trimmedTopic.isNotEmpty
        ? (trimmedTopic.length > 14000
            ? trimmedTopic.substring(0, 14000)
            : trimmedTopic)
        : '(Lihat gambar kisi-kisi yang dilampirkan)';
    final seed = LocalStorage.generateHexId(4);

    final materialFuture = buildStudyMaterial(
      topicText: sourceBlock,
      imageData: imageData,
      style: style,
    );

    final mcqFuture = _buildMcqBatch(
      sourceBlock,
      '',
      seed,
      imageData: imageData,
    ).then<List<Map<String, dynamic>>?>((v) => v).catchError((_) => null);

    final essayFuture = _buildEssayBatch(
      sourceBlock,
      '',
      seed,
      imageData: imageData,
    ).then<List<Map<String, dynamic>>?>((v) => v).catchError((_) => null);

    final results = await Future.wait<dynamic>([
      materialFuture,
      mcqFuture,
      essayFuture,
    ]);

    final material = results[0] as Map<String, dynamic>;
    final mcq = results[1] as List<Map<String, dynamic>>?;
    final essay = results[2] as List<Map<String, dynamic>>?;

    Map<String, dynamic>? readyQuiz;
    if (mcq != null && mcq.isNotEmpty && essay != null && essay.isNotEmpty) {
      readyQuiz = {
        'quiz_id': LocalStorage.generateHexId(4),
        'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
        'duration_seconds': 420,
        'mcq': mcq,
        'essay': essay,
      };
    }

    return SessionBundleResult(material: material, quiz: readyQuiz);
  }

  Future<Map<String, dynamic>> buildStudyMaterial({
    required String topicText,
    ImageAttachment? imageData,
    String style = 'santai',
  }) async {
    final isSantai = style == 'santai';
    final styleNote = isSantai
        ? 'Gaya bahasa santai tapi jelas & rinci seperti tutor privat: jelaskan konsep inti, cara kerja/rumus, contoh nyata, dan analogi sehari-hari.'
        : 'Gaya PADAT untuk belajar kilat H-1 ujian: langsung ke inti konsep, rumus, dan poin paling sering keluar.';

    final depthRules = isSantai
        ? 'Buat 4-6 sections mencakup seluruh kisi-kisi, tiap explanation 3-5 kalimat padat, 3-5 key_points substantif, 6-10 item cheat_sheet, dan 3-5 item exam_traps.'
        : 'Buat 3-5 sections mencakup poin penting, tiap explanation 2-3 kalimat padat, 3 key_points tajam, 5-7 item cheat_sheet, dan 3 item exam_traps.';

    final estMin = isSantai ? 6 : 4;
    final sourceBlock = topicText.trim().isNotEmpty
        ? topicText.trim()
        : '(Lihat gambar kisi-kisi yang dilampirkan)';

    final prompt = '''Kamu tutor belajar ahli. Susun catatan belajar siap ujian dalam Bahasa Indonesia natural.
ATURAN:
1. $styleNote
2. Cakup SEMUA topik/indikator dari kisi-kisi tanpa mengarang angka/rumus keliru.
3. $depthRules
4. Kembalikan HANYA JSON valid:
{
  "title": "Judul materi jelas (maks 10 kata)",
  "estimated_minutes": $estMin,
  "tldr": "Ringkasan 2-4 kalimat inti seluruh materi.",
  "sections": [
    {
      "heading": "Judul sub-topik",
      "explanation": "Penjelasan jelas lengkap dengan mekanisme/rumus/contoh.",
      "analogy": "Analogi konkret sehari-hari (kosongkan jika tidak cocok).",
      "key_points": ["Poin penting 1", "Poin penting 2", "Poin penting 3"]
    }
  ],
  "cheat_sheet": [
    {"term": "Istilah/Rumus", "meaning": "Arti jelas atau cara ingat"}
  ],
  "exam_traps": ["Jebakan soal umum dan cara menghindarinya"]
}

MATERI / KISI-KISI:
$sourceBlock''';

    final result = await generateJson(
      prompt: prompt,
      imageData: imageData,
      readTimeoutSec: 28.0,
      deadlineSec: 55.0,
      maxOutputTokens: 4096,
    );
    final sections = result['sections'];
    if (sections is! List || sections.isEmpty) {
      throw const GeminiClientException(
        'AI gagal menyusun bagian materi. Silakan coba lagi.',
      );
    }
    return result;
  }

  static String _compactMaterialContext(
    String title,
    Map<String, dynamic> material,
    String rawContext,
  ) {
    final sectionsBrief = <String>[];
    final sections = material['sections'];
    if (sections is List) {
      for (final sec in sections.take(8)) {
        if (sec is Map) {
          final kps = (sec['key_points'] is List)
              ? (sec['key_points'] as List).take(5).map((e) => '$e').join('; ')
              : '';
          sectionsBrief.add(
            '- ${sec['heading'] ?? ''}: ${sec['explanation'] ?? ''} Poin: $kps',
          );
        }
      }
    }

    final cheatsBrief = <String>[];
    final cheats = material['cheat_sheet'];
    if (cheats is List) {
      for (final c in cheats.take(10)) {
        if (c is Map) {
          cheatsBrief.add('${c['term'] ?? ''}=${c['meaning'] ?? ''}');
        }
      }
    }

    final trapsBrief = <String>[];
    final traps = material['exam_traps'];
    if (traps is List) {
      for (final t in traps.take(5)) {
        trapsBrief.add('$t');
      }
    }

    final extra =
        rawContext.length > 5000 ? rawContext.substring(0, 5000) : rawContext;

    return 'JUDUL: $title\n'
        'INTI: ${material['tldr'] ?? ''}\n'
        'BAGIAN:\n${sectionsBrief.join('\n')}\n'
        'ISTILAH: ${cheatsBrief.join('; ')}\n'
        'JEBAKAN: ${trapsBrief.join('; ')}\n'
        'KONTEKS:\n$extra';
  }

  Future<List<Map<String, dynamic>>> _buildMcqBatch(
    String contextText,
    String avoidBlock,
    String variationSeed, {
    ImageAttachment? imageData,
  }) async {
    final prompt = '''Buat TEPAT 15 soal PILIHAN GANDA Bahasa Indonesia dari materi/kisi-kisi ini.
Variasi: $variationSeed
$avoidBlock
ATURAN:
1. "mcq" berisi TEPAT 15 soal (id 1-15), campur konsep, penerapan, & jebakan ujian.
2. Tiap soal punya 4 opsi singkat ("A","B","C","D"), "correct_option" (A/B/C/D), "explanation" 1 kalimat singkat.
3. HANYA JSON valid:
{"mcq":[{"id":1,"question":"...","options":{"A":"...","B":"...","C":"...","D":"..."},"correct_option":"A","explanation":"..."}]}

MATERI:
$contextText''';

    final result = await generateJson(
      prompt: prompt,
      imageData: imageData,
      readTimeoutSec: 26.0,
      deadlineSec: 50.0,
      maxOutputTokens: 3500,
    );
    final mcq = result['mcq'];
    if (mcq is! List || mcq.length < 10) {
      throw const GeminiClientException(
        'Jumlah soal pilihan ganda dari AI kurang lengkap. Coba lagi.',
      );
    }

    final cleaned = <Map<String, dynamic>>[];
    int i = 1;
    for (final q in mcq.take(15)) {
      if (q is! Map) continue;
      final opts = q['options'] is Map ? q['options'] as Map : const {};
      final rawCorrect = '${q['correct_option'] ?? 'A'}'.trim().toUpperCase();
      final correct = rawCorrect.isNotEmpty ? rawCorrect[0] : 'A';
      cleaned.add({
        'id': i++,
        'question': '${q['question'] ?? ''}'.trim(),
        'options': {
          'A': '${opts['A'] ?? ''}'.trim(),
          'B': '${opts['B'] ?? ''}'.trim(),
          'C': '${opts['C'] ?? ''}'.trim(),
          'D': '${opts['D'] ?? ''}'.trim(),
        },
        'correct_option': correct,
        'explanation': '${q['explanation'] ?? ''}'.trim(),
      });
    }
    return cleaned;
  }

  Future<List<Map<String, dynamic>>> _buildEssayBatch(
    String contextText,
    String avoidBlock,
    String variationSeed, {
    ImageAttachment? imageData,
  }) async {
    final prompt = '''Buat TEPAT 5 soal ESSAY Bahasa Indonesia dari materi/kisi-kisi ini.
Variasi: $variationSeed
$avoidBlock
ATURAN:
1. "essay" berisi TEPAT 5 soal (id 1-5) yang menguji pemahaman & analisis.
2. Tiap soal punya "question", "key_points" (2-3 poin kunci), "model_answer" (2 kalimat padat).
3. HANYA JSON valid:
{"essay":[{"id":1,"question":"...","key_points":["Poin 1","Poin 2"],"model_answer":"..."}]}

MATERI:
$contextText''';

    final result = await generateJson(
      prompt: prompt,
      imageData: imageData,
      readTimeoutSec: 22.0,
      deadlineSec: 45.0,
      maxOutputTokens: 1800,
    );
    final essay = result['essay'];
    if (essay is! List || essay.length < 3) {
      throw const GeminiClientException(
        'Jumlah soal essay dari AI kurang lengkap. Coba lagi.',
      );
    }

    final cleaned = <Map<String, dynamic>>[];
    int i = 1;
    for (final q in essay.take(5)) {
      if (q is! Map) continue;
      final kps = q['key_points'] is List
          ? (q['key_points'] as List)
              .map((k) => '$k'.trim())
              .where((s) => s.isNotEmpty)
              .toList()
          : <String>[];
      cleaned.add({
        'id': i++,
        'question': '${q['question'] ?? ''}'.trim(),
        'key_points': kps,
        'model_answer': '${q['model_answer'] ?? ''}'.trim(),
      });
    }
    return cleaned;
  }

  Future<Map<String, dynamic>> buildQuiz({
    required String title,
    required Map<String, dynamic> material,
    required String rawContext,
    List<String>? avoidQuestions,
    String? variationSeed,
  }) async {
    final contextText = _compactMaterialContext(title, material, rawContext);
    final seed = variationSeed ?? LocalStorage.generateHexId(4);

    var avoidBlock = '';
    if (avoidQuestions != null && avoidQuestions.isNotEmpty) {
      final samples = avoidQuestions
          .map((q) => q.trim())
          .where((q) => q.isNotEmpty)
          .take(20)
          .map((q) => '- ${q.length > 120 ? q.substring(0, 120) : q}')
          .toList();
      if (samples.isNotEmpty) {
        avoidBlock =
            'PENTING (SOAL HARUS BERBEDA): Jangan mengulang soal sebelumnya di bawah ini:\n${samples.join('\n')}\n';
      }
    }

    final results = await Future.wait<List<Map<String, dynamic>>>([
      _buildMcqBatch(contextText, avoidBlock, seed),
      _buildEssayBatch(contextText, avoidBlock, seed),
    ]);

    return {
      'quiz_id': LocalStorage.generateHexId(4),
      'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'duration_seconds': 420,
      'mcq': results[0],
      'essay': results[1],
    };
  }

  Future<Map<String, dynamic>> gradeQuiz({
    required Map<String, dynamic> quiz,
    required Map<String, dynamic> mcqAnswers,
    required Map<String, dynamic> essayAnswers,
  }) async {
    final mcqList = (quiz['mcq'] is List) ? quiz['mcq'] as List : const [];
    final essayList =
        (quiz['essay'] is List) ? quiz['essay'] as List : const [];

    final mcqResults = <Map<String, dynamic>>[];
    int mcqCorrectCount = 0;
    final wrongTopics = <String>[];

    for (final q in mcqList) {
      if (q is! Map) continue;
      final qid = '${q['id']}';
      final userAns = '${mcqAnswers[qid] ?? ''}'.trim().toUpperCase();
      final correct = '${q['correct_option'] ?? ''}'.trim().toUpperCase();
      final isCorrect = userAns.isNotEmpty && userAns == correct;
      final question = '${q['question'] ?? ''}';
      if (isCorrect) {
        mcqCorrectCount++;
      } else {
        wrongTopics.add(
          question.length > 120 ? question.substring(0, 120) : question,
        );
      }
      mcqResults.add({
        'id': q['id'],
        'question': question,
        'options': q['options'] ?? const {},
        'user_answer': userAns.isEmpty ? '-' : userAns,
        'correct_option': correct,
        'is_correct': isCorrect,
        'explanation': '${q['explanation'] ?? ''}',
      });
    }

    final essayPayload = <Map<String, dynamic>>[];
    for (final q in essayList) {
      if (q is! Map) continue;
      final qid = '${q['id']}';
      essayPayload.add({
        'id': q['id'],
        'question': '${q['question'] ?? ''}',
        'key_points': q['key_points'] ?? const [],
        'model_answer': '${q['model_answer'] ?? ''}',
        'user_answer': '${essayAnswers[qid] ?? ''}'.trim(),
      });
    }

    final prompt = '''Kamu penilai ujian adil & suportif. Nilai jawaban essay (0-100; jika kosong/asal-asalan beri 0-15) dan beri saran belajar dari soal PG yang salah.
HANYA JSON valid:
{
  "essay_grades": [{"id": 1, "score": 85, "feedback": "Koreksi singkat 1-2 kalimat."}],
  "overall_feedback": "Evaluasi menyeluruh 2 kalimat santai & membangun.",
  "review_focus": ["Topik spesifik 1", "Topik spesifik 2"]
}

DATA ESSAY:
${jsonEncode(essayPayload)}

PG SALAH (${wrongTopics.length}/${mcqList.length}):
${jsonEncode(wrongTopics)}''';

    final aiEval = await generateJson(
      prompt: prompt,
      readTimeoutSec: 24.0,
      deadlineSec: 50.0,
      maxOutputTokens: 1800,
    );
    final gradeMap = <int, Map<String, dynamic>>{};
    final rawGrades = aiEval['essay_grades'];
    if (rawGrades is List) {
      for (final item in rawGrades) {
        if (item is Map && item['id'] != null) {
          final id = int.tryParse('${item['id']}');
          if (id != null) {
            gradeMap[id] = Map<String, dynamic>.from(item);
          }
        }
      }
    }

    final essayResults = <Map<String, dynamic>>[];
    int essayScoreSum = 0;

    for (final q in essayList) {
      if (q is! Map) continue;
      final qid = int.tryParse('${q['id']}') ?? 0;
      final g = gradeMap[qid];
      final rawScore = g?['score'];
      int score = 0;
      if (rawScore is num) {
        score = rawScore.round().clamp(0, 100);
      } else if (rawScore != null) {
        score = (double.tryParse('$rawScore') ?? 0).round().clamp(0, 100);
      }

      final userText = '${essayAnswers['$qid'] ?? ''}'.trim();
      if (userText.isEmpty) score = 0;
      essayScoreSum += score;

      essayResults.add({
        'id': qid,
        'question': '${q['question'] ?? ''}',
        'user_answer': userText.isEmpty ? '(Tidak dijawab)' : userText,
        'score': score,
        'feedback': '${g?['feedback'] ?? 'Jawaban sudah dinilai.'}',
        'model_answer': '${q['model_answer'] ?? ''}',
      });
    }

    final mcqTotal = mcqList.isEmpty ? 1 : mcqList.length;
    final essayTotal = essayList.isEmpty ? 1 : essayList.length;
    final mcqScorePct = ((mcqCorrectCount / mcqTotal) * 100).round();
    final essayScorePct = (essayScoreSum / essayTotal).round();
    final totalScore = (mcqScorePct * 0.6 + essayScorePct * 0.4).round();

    final String gradeLabel;
    if (totalScore >= 85) {
      gradeLabel = 'Siap Ujian';
    } else if (totalScore >= 70) {
      gradeLabel = 'Cukup Paham';
    } else if (totalScore >= 50) {
      gradeLabel = 'Perlu Review Lagi';
    } else {
      gradeLabel = 'Baca Ulang Materi Dulu';
    }

    return {
      'total_score': totalScore,
      'grade_label': gradeLabel,
      'mcq_correct': mcqCorrectCount,
      'mcq_total': mcqList.length,
      'mcq_score': mcqScorePct,
      'essay_score': essayScorePct,
      'overall_feedback':
          '${aiEval['overall_feedback'] ?? 'Hasil kuis kamu sudah selesai dinilai.'}',
      'review_focus': aiEval['review_focus'] is List
          ? aiEval['review_focus']
          : const <String>[],
      'mcq_results': mcqResults,
      'essay_results': essayResults,
    };
  }

  void dispose() {
    _http.close();
  }
}
