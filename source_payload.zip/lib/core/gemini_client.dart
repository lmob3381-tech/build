import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'file_parser.dart';
import 'storage.dart';

class GeminiClientException implements Exception {
  const GeminiClientException(this.message);
  final String message;

  @override
  String toString() => message;
}

class _ModelConfig {
  const _ModelConfig(this.model, this.thinkingLevel);
  final String model;
  final String thinkingLevel;
}

class GeminiClient {
  GeminiClient(this.storage);

  final LocalStorage storage;
  final http.Client _http = http.Client();
  int _keyIndex = 0;

  static const List<_ModelConfig> _modelConfigs = [
    _ModelConfig('gemini-3.5-flash-lite', 'MINIMAL'),
    _ModelConfig('gemini-3.8-flash', 'LOW'),
    _ModelConfig('gemini-3.7-flash', 'LOW'),
    _ModelConfig('gemini-3.5-flash', 'LOW'),
    _ModelConfig('gemini-3.1-flash-lite', 'MINIMAL'),
    _ModelConfig('gemini-4-hydrogen', 'LOW'),
    _ModelConfig('gemini-2.5-flash-lite', 'MINIMAL'),
    _ModelConfig('gemini-2.5-flash', 'LOW'),
  ];

  int keyCount() => storage.readApiKeys().length;

  List<String> _getOrderedKeys() {
    final keys = storage.readApiKeys();
    if (keys.isEmpty) {
      throw const GeminiClientException(
        'API Key Google AI Studio belum diatur. Ketuk ikon kunci di pojok kanan atas untuk memasukkan API Key.',
      );
    }
    final start = _keyIndex % keys.length;
    _keyIndex = (_keyIndex + 1) % keys.length;
    return <String>[
      ...keys.sublist(start),
      ...keys.sublist(0, start),
    ];
  }

  static String _stripMarkdownFences(String text) {
    var cleaned = text.trim();
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replaceFirst(RegExp(r'^```(?:json|JSON)?\s*'), '');
      cleaned = cleaned.replaceFirst(RegExp(r'\s*```$'), '');
    }
    return cleaned.trim();
  }

  static String _stripTrailingCommas(String input) {
    final buf = StringBuffer();
    bool inString = false;
    bool escaped = false;
    final len = input.length;

    for (int i = 0; i < len; i++) {
      final ch = input[i];
      if (inString) {
        buf.write(ch);
        if (escaped) {
          escaped = false;
        } else if (ch == r'\') {
          escaped = true;
        } else if (ch == '"') {
          inString = false;
        }
        continue;
      }

      if (ch == '"') {
        inString = true;
        buf.write(ch);
        continue;
      }

      if (ch == ',') {
        int j = i + 1;
        while (j < len &&
            (input[j] == ' ' ||
                input[j] == '\t' ||
                input[j] == '\n' ||
                input[j] == '\r')) {
          j++;
        }
        if (j < len && (input[j] == ']' || input[j] == '}')) {
          continue;
        }
      }

      buf.write(ch);
    }
    return buf.toString();
  }

  static Map<String, dynamic> _extractJsonBlock(String text) {
    final cleaned = _stripMarkdownFences(text);

    Map<String, dynamic>? tryDecode(String candidate) {
      try {
        final decoded = jsonDecode(candidate);
        if (decoded is Map<String, dynamic>) return decoded;
      } catch (_) {}
      return null;
    }

    final first = tryDecode(cleaned) ?? tryDecode(_stripTrailingCommas(cleaned));
    if (first != null) return first;

    final start = cleaned.indexOf('{');
    final end = cleaned.lastIndexOf('}');
    if (start != -1 && end > start) {
      final sub = cleaned.substring(start, end + 1);
      final parsed = tryDecode(sub) ?? tryDecode(_stripTrailingCommas(sub));
      if (parsed != null) return parsed;
    }

    throw const GeminiClientException(
      'AI tidak mengembalikan format JSON yang valid. Coba ulangi.',
    );
  }

  static String _extractTextFromCandidates(Map<String, dynamic> data) {
    final candidates = data['candidates'];
    if (candidates is! List || candidates.isEmpty) return '';
    final first = candidates.first;
    if (first is! Map) return '';
    final content = first['content'];
    if (content is! Map) return '';
    final parts = content['parts'];
    if (parts is! List) return '';

    final buf = StringBuffer();
    for (final part in parts) {
      if (part is Map) {
        final isThought = part['thought'] == true;
        final text = part['text'];
        if (!isThought && text is String && text.isNotEmpty) {
          buf.write(text);
        }
      }
    }
    return buf.toString().trim();
  }

  Future<Map<String, dynamic>> generateJson({
    required String prompt,
    ImageAttachment? imageData,
    double readTimeoutSec = 28.0,
    double deadlineSec = 65.0,
  }) async {
    final keys = _getOrderedKeys();

    final parts = <Map<String, dynamic>>[];
    if (imageData != null) {
      parts.add({
        'inlineData': {
          'mimeType': imageData.mimeType,
          'data': imageData.dataB64,
        },
      });
    }
    parts.add({'text': prompt});

    var lastError = 'Gagal menghubungi Google AI Studio.';
    final stopwatch = Stopwatch()..start();

    for (final cfg in _modelConfigs) {
      if (stopwatch.elapsedMilliseconds / 1000.0 >= deadlineSec) {
        lastError =
            'Permintaan ke AI melebihi batas waktu. Coba lagi sebentar lagi.';
        break;
      }

      final bodyJson = jsonEncode({
        'contents': [
          {'role': 'user', 'parts': parts},
        ],
        'generationConfig': {
          'responseMimeType': 'application/json',
          'thinkingConfig': {
            'thinkingLevel': cfg.thinkingLevel,
          },
        },
      });

      for (int idx = 0; idx < keys.length; idx++) {
        final key = keys[idx];
        final keyNum = idx + 1;
        final remaining =
            deadlineSec - (stopwatch.elapsedMilliseconds / 1000.0);
        if (remaining <= 3.0) {
          lastError =
              'Permintaan ke AI melebihi batas waktu. Coba lagi sebentar lagi.';
          break;
        }

        final reqTimeoutSec =
            readTimeoutSec < remaining ? readTimeoutSec : (remaining < 8.0 ? 8.0 : remaining);
        final uri = Uri.https(
          'generativelanguage.googleapis.com',
          '/v1beta/models/${cfg.model}:generateContent',
          {'key': key},
        );

        final reqWatch = Stopwatch()..start();
        http.Response resp;
        try {
          resp = await _http
              .post(
                uri,
                headers: const {'Content-Type': 'application/json'},
                body: bodyJson,
              )
              .timeout(Duration(milliseconds: (reqTimeoutSec * 1000).round()));
        } on TimeoutException {
          final dt = (reqWatch.elapsedMilliseconds / 1000.0).toStringAsFixed(1);
          lastError =
              '[${cfg.model} | key#$keyNum | ${dt}s] Respons model terlalu lama.';
          break;
        } catch (e) {
          final dt = (reqWatch.elapsedMilliseconds / 1000.0).toStringAsFixed(1);
          lastError =
              '[${cfg.model} | key#$keyNum | ${dt}s] Koneksi gagal: $e';
          break;
        }

        if (resp.statusCode == 200) {
          Map<String, dynamic> payload;
          try {
            final decoded = jsonDecode(resp.body);
            if (decoded is! Map<String, dynamic>) {
              lastError = '[${cfg.model}] Respons HTTP 200 bukan objek JSON.';
              continue;
            }
            payload = decoded;
          } catch (e) {
            lastError = '[${cfg.model}] Respons HTTP 200 bukan JSON valid: $e';
            continue;
          }

          final textOut = _extractTextFromCandidates(payload);
          if (textOut.isEmpty) {
            lastError = '[${cfg.model}] Respons teks dari AI kosong.';
            continue;
          }

          try {
            return _extractJsonBlock(textOut);
          } on GeminiClientException catch (e) {
            lastError = '[${cfg.model}] ${e.message}';
            continue;
          }
        }

        String errMsg;
        try {
          final decoded = jsonDecode(resp.body);
          if (decoded is Map &&
              decoded['error'] is Map &&
              decoded['error']['message'] is String) {
            errMsg = decoded['error']['message'] as String;
          } else {
            errMsg = resp.body.length > 200
                ? resp.body.substring(0, 200)
                : resp.body;
          }
        } catch (_) {
          errMsg = resp.body.length > 200
              ? resp.body.substring(0, 200)
              : resp.body;
        }

        lastError = '[${cfg.model} | HTTP ${resp.statusCode}] $errMsg';

        if (resp.statusCode == 404 ||
            resp.statusCode == 500 ||
            resp.statusCode == 503) {
          break;
        }
        if (resp.statusCode == 400) {
          final lower = errMsg.toLowerCase();
          if (lower.contains('api key') || lower.contains('key not valid')) {
            continue;
          }
          break;
        }
        if (resp.statusCode == 429 || resp.statusCode == 403) {
          continue;
        }
      }
    }

    throw GeminiClientException(lastError);
  }

  Future<Map<String, dynamic>> buildStudyMaterial({
    required String topicText,
    ImageAttachment? imageData,
    String style = 'santai',
  }) async {
    final isSantai = style == 'santai';
    final styleNote = isSantai
        ? 'Gunakan gaya bahasa santai namun RINCI dan MENDALAM seperti tutor privat yang menjelaskan sampai benar-benar paham sebelum ujian. Jelaskan konsep inti, cara kerja/proses/rumus, hubungan sebab-akibat, serta contoh penerapan nyata di tiap bagian. Sertakan analogi kehidupan sehari-hari yang konkret agar konsep langsung menempel.'
        : 'Gunakan gaya PADAT untuk belajar kilat H-1 ujian: langsung ke inti konsep, rumus, dan poin yang paling sering keluar di soal, tetapi tetap lengkap dan jelas sehingga pembaca tidak bingung.';

    final depthRules = isSantai
        ? 'Pastikan materi CUKUP LENGKAP DAN MENDALAM (jangan terlalu singkat/dangkal): buat 5 sampai 8 sections yang mencakup SELURUH topik/indikator pada kisi-kisi tanpa ada yang terlewat, setiap explanation berisi 4 sampai 7 kalimat yang jelas dan informatif, setiap section memiliki 4 sampai 6 key_points yang substantif (lengkap dengan detail/rumus/aturan penting, bukan hanya 2-3 kata), 8 sampai 12 item di cheat_sheet, dan 4 sampai 6 item di exam_traps lengkap dengan cara menghindarinya.'
        : 'Buat 4 sampai 6 sections yang mencakup semua poin penting pada kisi-kisi, setiap explanation berisi 3 sampai 4 kalimat yang padat dan berisi, setiap section memiliki 3 sampai 4 key_points tajam siap hafal, 6 sampai 8 item di cheat_sheet, dan 3 sampai 4 item di exam_traps.';

    final tldrGuide = isSantai
        ? 'Ringkasan menyeluruh dalam 3-5 kalimat yang menangkap seluruh gambaran besar materi dan benang merah antar topik.'
        : 'Ringkasan padat dalam 2-3 kalimat yang langsung merangkum inti seluruh materi.';

    final estMin = isSantai ? 7 : 4;
    final sourceBlock = topicText.trim().isNotEmpty
        ? topicText.trim()
        : '(Lihat gambar kisi-kisi yang dilampirkan)';

    final prompt = '''Kamu adalah tutor belajar ahli yang menyusun modul catatan belajar siap ujian yang lengkap, terstruktur, dan mudah dipahami.

ATURAN PENTING:
1. Tulis seluruh hasil dalam Bahasa Indonesia yang jernih, natural, dan enak dibaca. Jangan kaku seperti salinan mentah, tetapi JANGAN memangkas detail penting.
2. $styleNote
3. Cakup SEMUA pokok bahasan, sub-bab, atau indikator dari kisi-kisi pengguna. Jika kisi-kisi hanya berupa daftar judul/topik singkat, uraikan penjelasan konseptual, mekanisme, rumus/aturan, dan contoh penerapannya secara utuh agar pengguna bisa langsung belajar dari catatan ini tanpa perlu membuka buku lain.
4. Jangan mengarang fakta keliru untuk angka, rumus, atau definisi spesifik.
5. $depthRules
6. Kembalikan HANYA JSON valid dengan struktur persis seperti berikut:

{
  "title": "Judul materi yang jelas & informatif (maks 10 kata)",
  "estimated_minutes": $estMin,
  "tldr": "$tldrGuide",
  "sections": [
    {
      "heading": "Judul sub-topik yang jelas",
      "explanation": "Penjelasan lengkap, mengalir, dan mudah dipahami (sertakan mekanisme, langkah, rumus, atau contoh kasus nyata bila relevan).",
      "analogy": "Analogi konkret dari kehidupan sehari-hari agar konsep langsung menempel (kosongkan string hanya jika memang tidak cocok).",
      "key_points": [
        "Poin hafalan / konsep penting 1 beserta penjelasan singkat atau rumusnya",
        "Poin hafalan / konsep penting 2 beserta penjelasan singkat atau rumusnya",
        "Poin hafalan / konsep penting 3 beserta penjelasan singkat atau rumusnya",
        "Poin hafalan / konsep penting 4 beserta penjelasan singkat atau rumusnya"
      ]
    }
  ],
  "cheat_sheet": [
    {
      "term": "Istilah / Rumus / Singkatan / Komponen",
      "meaning": "Arti jelas, fungsi, atau cara cepat mengingatnya"
    }
  ],
  "exam_traps": [
    "Kesalahan umum atau jebakan soal yang sering mengecoh beserta cara menghindarinya"
  ],
  "context_for_quiz": "Rangkuman padat namun komprehensif seluruh materi/kisi-kisi (300-500 kata) yang mencakup semua konsep, istilah, rumus, dan detail penting agar nanti bisa dipakai membuat 15 soal pilihan ganda dan 5 soal essay yang akurat."
}

MATERI / KISI-KISI DARI PENGGUNA:
$sourceBlock''';

    final result = await generateJson(
      prompt: prompt,
      imageData: imageData,
      readTimeoutSec: 40.0,
      deadlineSec: 75.0,
    );
    final sections = result['sections'];
    if (sections is! List || sections.isEmpty) {
      throw const GeminiClientException(
        'AI gagal menyusun bagian materi. Silakan coba lagi.',
      );
    }
    return result;
  }

  static String _compactMaterialContext(
    String title,
    Map<String, dynamic> material,
    String rawContext,
  ) {
    final sectionsBrief = <String>[];
    final sections = material['sections'];
    if (sections is List) {
      for (final sec in sections.take(10)) {
        if (sec is Map) {
          final kps = (sec['key_points'] is List)
              ? (sec['key_points'] as List).take(6).map((e) => '$e').join('; ')
              : '';
          sectionsBrief.add(
            '- ${sec['heading'] ?? ''}: ${sec['explanation'] ?? ''} Poin: $kps',
          );
        }
      }
    }

    final cheatsBrief = <String>[];
    final cheats = material['cheat_sheet'];
    if (cheats is List) {
      for (final c in cheats.take(12)) {
        if (c is Map) {
          cheatsBrief.add('${c['term'] ?? ''}=${c['meaning'] ?? ''}');
        }
      }
    }

    final trapsBrief = <String>[];
    final traps = material['exam_traps'];
    if (traps is List) {
      for (final t in traps.take(6)) {
        trapsBrief.add('$t');
      }
    }

    final extra =
        rawContext.length > 6000 ? rawContext.substring(0, 6000) : rawContext;

    return 'JUDUL: $title\n'
        'INTI: ${material['tldr'] ?? ''}\n'
        'BAGIAN:\n${sectionsBrief.join('\n')}\n'
        'ISTILAH: ${cheatsBrief.join('; ')}\n'
        'JEBAKAN: ${trapsBrief.join('; ')}\n'
        'KONTEKS TAMBAHAN:\n$extra';
  }

  Future<List<Map<String, dynamic>>> _buildMcqBatch(
    String contextText,
    String avoidBlock,
    String variationSeed,
  ) async {
    final prompt = '''Kamu adalah pembuat soal ujian profesional. Buat TEPAT 15 soal PILIHAN GANDA dalam Bahasa Indonesia berdasarkan materi berikut.
Kode variasi paket: $variationSeed
$avoidBlock
ATURAN WAJIB:
1. "mcq" HARUS berisi TEPAT 15 soal (id 1 sampai 15).
2. Campurkan konsep dasar, penerapan kasus, dan jebakan ujian. Semua bersumber dari materi.
3. Tiap soal punya 4 opsi singkat-padat ("A", "B", "C", "D"), "correct_option" (1 huruf A/B/C/D), dan "explanation" 1 kalimat singkat.
4. Kembalikan HANYA JSON valid:
{
  "mcq": [
    {
      "id": 1,
      "question": "Pertanyaan singkat dan jelas...",
      "options": {"A": "...", "B": "...", "C": "...", "D": "..."},
      "correct_option": "A",
      "explanation": "Alasan singkat."
    }
  ]
}

MATERI:
$contextText''';

    final result = await generateJson(
      prompt: prompt,
      readTimeoutSec: 30.0,
      deadlineSec: 55.0,
    );
    final mcq = result['mcq'];
    if (mcq is! List || mcq.length < 10) {
      throw const GeminiClientException(
        'Jumlah soal pilihan ganda dari AI kurang lengkap. Coba lagi.',
      );
    }

    final cleaned = <Map<String, dynamic>>[];
    int i = 1;
    for (final q in mcq.take(15)) {
      if (q is! Map) continue;
      final opts = q['options'] is Map ? q['options'] as Map : const {};
      final rawCorrect = '${q['correct_option'] ?? 'A'}'.trim().toUpperCase();
      final correct = rawCorrect.isNotEmpty ? rawCorrect[0] : 'A';
      cleaned.add({
        'id': i++,
        'question': '${q['question'] ?? ''}'.trim(),
        'options': {
          'A': '${opts['A'] ?? ''}'.trim(),
          'B': '${opts['B'] ?? ''}'.trim(),
          'C': '${opts['C'] ?? ''}'.trim(),
          'D': '${opts['D'] ?? ''}'.trim(),
        },
        'correct_option': correct,
        'explanation': '${q['explanation'] ?? ''}'.trim(),
      });
    }
    return cleaned;
  }

  Future<List<Map<String, dynamic>>> _buildEssayBatch(
    String contextText,
    String avoidBlock,
    String variationSeed,
  ) async {
    final prompt = '''Kamu adalah pembuat soal ujian profesional. Buat TEPAT 5 soal ESSAY dalam Bahasa Indonesia berdasarkan materi berikut.
Kode variasi paket: $variationSeed
$avoidBlock
ATURAN WAJIB:
1. "essay" HARUS berisi TEPAT 5 soal (id 1 sampai 5) yang menguji pemahaman dan analisis.
2. Tiap soal punya "question", "key_points" (2-3 poin kunci), dan "model_answer" (2-3 kalimat padat).
3. Kembalikan HANYA JSON valid:
{
  "essay": [
    {
      "id": 1,
      "question": "Pertanyaan essay...",
      "key_points": ["Poin 1", "Poin 2"],
      "model_answer": "Contoh jawaban ideal singkat."
    }
  ]
}

MATERI:
$contextText''';

    final result = await generateJson(
      prompt: prompt,
      readTimeoutSec: 25.0,
      deadlineSec: 50.0,
    );
    final essay = result['essay'];
    if (essay is! List || essay.length < 3) {
      throw const GeminiClientException(
        'Jumlah soal essay dari AI kurang lengkap. Coba lagi.',
      );
    }

    final cleaned = <Map<String, dynamic>>[];
    int i = 1;
    for (final q in essay.take(5)) {
      if (q is! Map) continue;
      final kps = q['key_points'] is List
          ? (q['key_points'] as List)
              .map((k) => '$k'.trim())
              .where((s) => s.isNotEmpty)
              .toList()
          : <String>[];
      cleaned.add({
        'id': i++,
        'question': '${q['question'] ?? ''}'.trim(),
        'key_points': kps,
        'model_answer': '${q['model_answer'] ?? ''}'.trim(),
      });
    }
    return cleaned;
  }

  Future<Map<String, dynamic>> buildQuiz({
    required String title,
    required Map<String, dynamic> material,
    required String rawContext,
    List<String>? avoidQuestions,
    String? variationSeed,
  }) async {
    final contextText = _compactMaterialContext(title, material, rawContext);
    final seed = variationSeed ?? LocalStorage.generateHexId(4);

    var avoidBlock = '';
    if (avoidQuestions != null && avoidQuestions.isNotEmpty) {
      final samples = avoidQuestions
          .map((q) => q.trim())
          .where((q) => q.isNotEmpty)
          .take(20)
          .map((q) => '- ${q.length > 120 ? q.substring(0, 120) : q}')
          .toList();
      if (samples.isNotEmpty) {
        avoidBlock =
            'PENTING (SOAL HARUS BERBEDA): Jangan mengulang pertanyaan atau skenario yang sama dengan paket kuis sebelumnya di bawah ini. Ganti sudut pandang, contoh kasus, dan redaksi soal:\n${samples.join('\n')}\n';
      }
    }

    final results = await Future.wait<List<Map<String, dynamic>>>([
      _buildMcqBatch(contextText, avoidBlock, seed),
      _buildEssayBatch(contextText, avoidBlock, seed),
    ]);

    return {
      'quiz_id': LocalStorage.generateHexId(4),
      'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'duration_seconds': 420,
      'mcq': results[0],
      'essay': results[1],
    };
  }

  Future<Map<String, dynamic>> gradeQuiz({
    required Map<String, dynamic> quiz,
    required Map<String, dynamic> mcqAnswers,
    required Map<String, dynamic> essayAnswers,
  }) async {
    final mcqList = (quiz['mcq'] is List) ? quiz['mcq'] as List : const [];
    final essayList =
        (quiz['essay'] is List) ? quiz['essay'] as List : const [];

    final mcqResults = <Map<String, dynamic>>[];
    int mcqCorrectCount = 0;
    final wrongTopics = <String>[];

    for (final q in mcqList) {
      if (q is! Map) continue;
      final qid = '${q['id']}';
      final userAns = '${mcqAnswers[qid] ?? ''}'.trim().toUpperCase();
      final correct = '${q['correct_option'] ?? ''}'.trim().toUpperCase();
      final isCorrect = userAns.isNotEmpty && userAns == correct;
      final question = '${q['question'] ?? ''}';
      if (isCorrect) {
        mcqCorrectCount++;
      } else {
        wrongTopics.add(
          question.length > 120 ? question.substring(0, 120) : question,
        );
      }
      mcqResults.add({
        'id': q['id'],
        'question': question,
        'options': q['options'] ?? const {},
        'user_answer': userAns.isEmpty ? '-' : userAns,
        'correct_option': correct,
        'is_correct': isCorrect,
        'explanation': '${q['explanation'] ?? ''}',
      });
    }

    final essayPayload = <Map<String, dynamic>>[];
    for (final q in essayList) {
      if (q is! Map) continue;
      final qid = '${q['id']}';
      essayPayload.add({
        'id': q['id'],
        'question': '${q['question'] ?? ''}',
        'key_points': q['key_points'] ?? const [],
        'model_answer': '${q['model_answer'] ?? ''}',
        'user_answer': '${essayAnswers[qid] ?? ''}'.trim(),
      });
    }

    final prompt = '''Kamu adalah guru/dosen penilai ujian yang adil, suportif, dan jelas.
Nilailah jawaban essay siswa berikut ini. Jika jawaban kosong atau asal-asalan (seperti "tidak tahu", "asdf", atau cuma 1 kata tak relevan), beri skor 0 sampai 15. Jika sebagian benar, beri skor proporsional (0 sampai 100).

Selain itu, lihat juga daftar pertanyaan pilihan ganda yang dijawab salah oleh siswa agar kamu bisa memberi saran singkat bagian mana yang perlu dibaca ulang sebelum ujian.

Kembalikan HANYA JSON valid dengan struktur persis berikut:
{
  "essay_grades": [
    {
      "id": 1,
      "score": 85,
      "feedback": "Koreksi singkat 1-2 kalimat yang jujur: apa yang sudah benar dan apa yang masih kurang."
    }
  ],
  "overall_feedback": "Evaluasi menyeluruh dalam 2 kalimat santai tapi membangun tentang kesiapan ujian siswa.",
  "review_focus": [
    "Topik atau konsep spesifik 1 yang perlu dibaca ulang",
    "Topik atau konsep spesifik 2 yang perlu dibaca ulang"
  ]
}

DATA ESSAY SISWA:
${jsonEncode(essayPayload)}

SOAL PILIHAN GANDA YANG SALAH (${wrongTopics.length} dari ${mcqList.length}):
${jsonEncode(wrongTopics)}''';

    final aiEval = await generateJson(prompt: prompt, readTimeoutSec: 28.0);
    final gradeMap = <int, Map<String, dynamic>>{};
    final rawGrades = aiEval['essay_grades'];
    if (rawGrades is List) {
      for (final item in rawGrades) {
        if (item is Map && item['id'] != null) {
          final id = int.tryParse('${item['id']}');
          if (id != null) {
            gradeMap[id] = Map<String, dynamic>.from(item);
          }
        }
      }
    }

    final essayResults = <Map<String, dynamic>>[];
    int essayScoreSum = 0;

    for (final q in essayList) {
      if (q is! Map) continue;
      final qid = int.tryParse('${q['id']}') ?? 0;
      final g = gradeMap[qid];
      final rawScore = g?['score'];
      int score = 0;
      if (rawScore is num) {
        score = rawScore.round().clamp(0, 100);
      } else if (rawScore != null) {
        score = (double.tryParse('$rawScore') ?? 0).round().clamp(0, 100);
      }

      final userText = '${essayAnswers['$qid'] ?? ''}'.trim();
      if (userText.isEmpty) score = 0;
      essayScoreSum += score;

      essayResults.add({
        'id': qid,
        'question': '${q['question'] ?? ''}',
        'user_answer': userText.isEmpty ? '(Tidak dijawab)' : userText,
        'score': score,
        'feedback': '${g?['feedback'] ?? 'Jawaban sudah dinilai.'}',
        'model_answer': '${q['model_answer'] ?? ''}',
      });
    }

    final mcqTotal = mcqList.isEmpty ? 1 : mcqList.length;
    final essayTotal = essayList.isEmpty ? 1 : essayList.length;
    final mcqScorePct = ((mcqCorrectCount / mcqTotal) * 100).round();
    final essayScorePct = (essayScoreSum / essayTotal).round();
    final totalScore = (mcqScorePct * 0.6 + essayScorePct * 0.4).round();

    final String gradeLabel;
    if (totalScore >= 85) {
      gradeLabel = 'Siap Ujian';
    } else if (totalScore >= 70) {
      gradeLabel = 'Cukup Paham';
    } else if (totalScore >= 50) {
      gradeLabel = 'Perlu Review Lagi';
    } else {
      gradeLabel = 'Baca Ulang Materi Dulu';
    }

    return {
      'total_score': totalScore,
      'grade_label': gradeLabel,
      'mcq_correct': mcqCorrectCount,
      'mcq_total': mcqList.length,
      'mcq_score': mcqScorePct,
      'essay_score': essayScorePct,
      'overall_feedback':
          '${aiEval['overall_feedback'] ?? 'Hasil kuis kamu sudah selesai dinilai.'}',
      'review_focus': aiEval['review_focus'] is List
          ? aiEval['review_focus']
          : const <String>[],
      'mcq_results': mcqResults,
      'essay_results': essayResults,
    };
  }

  void dispose() {
    _http.close();
  }
}
