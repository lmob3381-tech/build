import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:mime/mime.dart';

import 'file_parser.dart';
import 'gemini_client.dart';
import 'storage.dart';

class _QuizJob {
  _QuizJob({
    required this.jobId,
    required this.status,
    required this.startedAtMs,
    this.error,
  });

  final String jobId;
  String status; // building | ready | error
  String? error;
  final int startedAtMs;
}

class LocalServer {
  LocalServer({
    required this.storage,
    required this.gemini,
  });

  final LocalStorage storage;
  final GeminiClient gemini;

  HttpServer? _server;
  int get port => _server?.port ?? 0;

  late String _indexHtml;
  late String _styleCss;
  late String _appJs;
  late String _motionJs;

  final Map<String, _QuizJob> _quizJobs = <String, _QuizJob>{};

  Future<int> start() async {
    if (_server != null) return _server!.port;

    _indexHtml = await rootBundle.loadString('assets/web/index.html');
    _styleCss = await rootBundle.loadString('assets/web/style.css');
    _appJs = await rootBundle.loadString('assets/web/app.js');
    _motionJs = await rootBundle.loadString('assets/web/motion-engine.js');

    _server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    _server!.listen(_handleRequest);
    return _server!.port;
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
  }

  static List<String> _collectQuestionStems(Map<String, dynamic>? quiz) {
    if (quiz == null) return <String>[];
    final stems = <String>[];
    for (final key in const ['mcq', 'essay']) {
      final list = quiz[key];
      if (list is List) {
        for (final item in list) {
          if (item is Map && item['question'] is String) {
            final q = (item['question'] as String).trim();
            if (q.isNotEmpty) stems.add(q);
          }
        }
      }
    }
    return stems;
  }

  static Map<String, dynamic>? _publicQuiz(dynamic rawQuiz) {
    if (rawQuiz is! Map) return null;
    final mcq = <Map<String, dynamic>>[];
    if (rawQuiz['mcq'] is List) {
      for (final q in rawQuiz['mcq'] as List) {
        if (q is Map) {
          mcq.add({
            'id': q['id'],
            'question': q['question'],
            'options': q['options'],
          });
        }
      }
    }
    final essay = <Map<String, dynamic>>[];
    if (rawQuiz['essay'] is List) {
      for (final q in rawQuiz['essay'] as List) {
        if (q is Map) {
          essay.add({
            'id': q['id'],
            'question': q['question'],
          });
        }
      }
    }
    return {
      'quiz_id': '${rawQuiz['quiz_id'] ?? rawQuiz['created_at'] ?? 'v1'}',
      'duration_seconds': rawQuiz['duration_seconds'] ?? 420,
      'mcq': mcq,
      'essay': essay,
    };
  }

  static Map<String, dynamic> _publicSession(Map<String, dynamic> record) {
    return {
      'id': record['id'],
      'created_at': record['created_at'],
      'title': record['title'],
      'style': record['style'] ?? 'santai',
      'source_summary': record['source_summary'] ?? '',
      'material': record['material'],
      'has_quiz': record['quiz'] != null,
      'quiz': _publicQuiz(record['quiz']),
      'attempt_count': record['attempt_count'] ?? 0,
    };
  }

  static String _maskKey(String key) {
    if (key.length <= 8) return '****';
    return '${key.substring(0, 4)}••••${key.substring(key.length - 4)}';
  }

  void _triggerBackgroundQuiz({
    required String sessionId,
    required String title,
    required Map<String, dynamic> material,
    required String rawContext,
    bool force = false,
    List<String>? avoidQuestions,
  }) {
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final existing = _quizJobs[sessionId];
    if (existing != null &&
        existing.status == 'building' &&
        !force &&
        (nowMs - existing.startedAtMs) < 90000) {
      return;
    }

    final jobId = LocalStorage.generateHexId(4);
    final job = _QuizJob(
      jobId: jobId,
      status: 'building',
      startedAtMs: nowMs,
    );
    _quizJobs[sessionId] = job;

    Future<void>(() async {
      try {
        final quiz = await gemini.buildQuiz(
          title: title,
          material: material,
          rawContext: rawContext,
          avoidQuestions: avoidQuestions,
          variationSeed: jobId,
        );
        final rec = await storage.getSession(sessionId);
        final prev = <String>[
          if (rec != null && rec['previous_questions'] is List)
            ...(rec['previous_questions'] as List).map((e) => '$e'),
          ..._collectQuestionStems(quiz),
        ];
        final trimmedPrev =
            prev.length > 30 ? prev.sublist(prev.length - 30) : prev;

        await storage.updateSession(sessionId, {
          'quiz': quiz,
          'previous_questions': trimmedPrev,
        });

        final cur = _quizJobs[sessionId];
        if (cur != null && cur.jobId == jobId) {
          cur.status = 'ready';
          cur.error = null;
        }
      } catch (e) {
        final cur = _quizJobs[sessionId];
        if (cur != null && cur.jobId == jobId) {
          cur.status = 'error';
          cur.error = e.toString().isNotEmpty
              ? e.toString()
              : 'Gagal menyusun kuis. Silakan coba lagi.';
        }
      }
    });
  }

  Future<void> _sendJson(
    HttpResponse response,
    int statusCode,
    Map<String, dynamic> body,
  ) async {
    response.statusCode = statusCode;
    response.headers.contentType = ContentType.json;
    response.write(jsonEncode(body));
    await response.close();
  }

  Future<void> _sendText(
    HttpResponse response,
    String mime,
    String content,
  ) async {
    response.statusCode = HttpStatus.ok;
    response.headers.set(HttpHeaders.contentTypeHeader, '$mime; charset=utf-8');
    response.headers.set(HttpHeaders.cacheControlHeader, 'public, max-age=3600');
    response.write(content);
    await response.close();
  }

  Future<void> _handleRequest(HttpRequest req) async {
    final path = req.uri.path;
    final method = req.method.toUpperCase();

    try {
      // Static & HTML routes
      if (method == 'GET' && path == '/') {
        await _sendText(
          req.response,
          'text/html',
          _indexHtml.replaceAll('{{ initial_session_id }}', ''),
        );
        return;
      }

      if (method == 'GET' && path.startsWith('/s/')) {
        final rawId = path.substring(3);
        final safeId = rawId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '');
        await _sendText(
          req.response,
          'text/html',
          _indexHtml.replaceAll('{{ initial_session_id }}', safeId),
        );
        return;
      }

      if (method == 'GET' && path == '/static/style.css') {
        await _sendText(req.response, 'text/css', _styleCss);
        return;
      }
      if (method == 'GET' && path == '/static/app.js') {
        await _sendText(req.response, 'application/javascript', _appJs);
        return;
      }
      if (method == 'GET' && path == '/static/motion-engine.js') {
        await _sendText(req.response, 'application/javascript', _motionJs);
        return;
      }

      // API: health
      if (method == 'GET' && path == '/api/health') {
        await _sendJson(req.response, HttpStatus.ok, {
          'ok': true,
          'api_keys_loaded': gemini.keyCount(),
          'engine': 'flutter-native',
        });
        return;
      }

      // API: keys
      if (path == '/api/keys') {
        if (method == 'GET') {
          final keys = storage.readApiKeys();
          await _sendJson(req.response, HttpStatus.ok, {
            'count': keys.length,
            'masked': keys.map(_maskKey).toList(),
          });
          return;
        }
        if (method == 'POST') {
          final body = await utf8.decoder.bind(req).join();
          final decoded = jsonDecode(body);
          final raw = (decoded is Map ? '${decoded['keys'] ?? ''}' : '');
          final saved = await storage.saveApiKeys(raw);
          await _sendJson(req.response, HttpStatus.ok, {
            'ok': true,
            'count': saved.length,
            'masked': saved.map(_maskKey).toList(),
          });
          return;
        }
      }

      // API: create session
      if (method == 'POST' && path == '/api/sessions') {
        await _handleCreateSession(req);
        return;
      }

      // API: session sub-routes
      final sessionMatch =
          RegExp(r'^/api/sessions/([^/]+)(?:/(quiz|grade)(?:/(status))?)?$')
              .firstMatch(path);
      if (sessionMatch != null) {
        final sessionId = Uri.decodeComponent(sessionMatch.group(1)!);
        final sub = sessionMatch.group(2);
        final sub2 = sessionMatch.group(3);

        if (method == 'GET' && sub == null) {
          final rec = await storage.getSession(sessionId);
          if (rec == null) {
            await _sendJson(req.response, HttpStatus.notFound, {
              'error': 'Sesi belajar tidak ditemukan atau link tidak valid.',
            });
            return;
          }
          await _sendJson(req.response, HttpStatus.ok, _publicSession(rec));
          return;
        }

        if (method == 'POST' && sub == 'quiz' && sub2 == null) {
          await _handleGenerateQuiz(req, sessionId);
          return;
        }

        if (method == 'GET' && sub == 'quiz' && sub2 == 'status') {
          await _handleQuizStatus(req, sessionId);
          return;
        }

        if (method == 'POST' && sub == 'grade' && sub2 == null) {
          await _handleGradeQuiz(req, sessionId);
          return;
        }
      }

      await _sendJson(req.response, HttpStatus.notFound, {
        'error': 'Endpoint tidak ditemukan.',
      });
    } catch (e) {
      await _sendJson(req.response, HttpStatus.internalServerError, {
        'error': 'Terjadi kesalahan internal: $e',
      });
    }
  }

  Future<void> _handleCreateSession(HttpRequest req) async {
    var topicText = '';
    var style = 'santai';
    ImageAttachment? imageData;
    final sourceParts = <String>[];

    final ct = req.headers.contentType;
    if (ct != null && ct.mimeType == 'multipart/form-data') {
      final boundary = ct.parameters['boundary'];
      if (boundary == null || boundary.isEmpty) {
        await _sendJson(req.response, HttpStatus.badRequest, {
          'error': 'Header multipart tidak valid.',
        });
        return;
      }

      final transformer = MimeMultipartTransformer(boundary);
      final parts = transformer.bind(req);

      await for (final part in parts) {
        final disp = part.headers['content-disposition'] ?? '';
        final nameMatch = RegExp(r'name="([^"]+)"').firstMatch(disp);
        final fieldName = nameMatch?.group(1) ?? '';
        final fileMatch = RegExp(r'filename="([^"]*)"').firstMatch(disp);
        final filename = fileMatch?.group(1) ?? '';

        final bytes = await part.fold<BytesBuilder>(
          BytesBuilder(copy: false),
          (b, chunk) => b..add(chunk),
        );
        final rawBytes = bytes.takeBytes();

        if (fieldName == 'text') {
          topicText = utf8.decode(rawBytes, allowMalformed: true).trim();
        } else if (fieldName == 'style') {
          style = utf8.decode(rawBytes, allowMalformed: true).trim();
        } else if (fieldName == 'file' &&
            filename.isNotEmpty &&
            rawBytes.isNotEmpty) {
          try {
            final parsed = FileParser.parse(filename, rawBytes);
            sourceParts.add('File: ${parsed.filename}');
            if (parsed.text.isNotEmpty) {
              topicText = topicText.isEmpty
                  ? parsed.text
                  : '$topicText\n\n--- ISI FILE (${parsed.filename}) ---\n${parsed.text}';
            }
            if (parsed.image != null) {
              imageData = parsed.image;
            }
          } on FormatException catch (e) {
            await _sendJson(req.response, HttpStatus.badRequest, {
              'error': e.message,
            });
            return;
          }
        }
      }
    } else {
      final raw = await utf8.decoder.bind(req).join();
      if (raw.trim().isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          topicText = '${decoded['text'] ?? ''}'.trim();
          style = '${decoded['style'] ?? 'santai'}'.trim();
        }
      }
    }

    if (topicText.isEmpty && imageData == null) {
      await _sendJson(req.response, HttpStatus.badRequest, {
        'error':
            'Ketik materi/topik ujian atau upload file kisi-kisi terlebih dahulu.',
      });
      return;
    }

    if (style != 'santai' && style != 'kilat') {
      style = 'santai';
    }

    Map<String, dynamic> material;
    try {
      material = await gemini.buildStudyMaterial(
        topicText: topicText,
        imageData: imageData,
        style: style,
      );
    } on GeminiClientException catch (e) {
      await _sendJson(req.response, HttpStatus.badGateway, {
        'error': e.message,
      });
      return;
    }

    final title = '${material['title'] ?? ''}'.trim().isNotEmpty
        ? '${material['title']}'.trim()
        : 'Materi Belajar';
    final rawQuizCtx = material.remove('context_for_quiz');
    final quizContext = (rawQuizCtx is String && rawQuizCtx.trim().isNotEmpty)
        ? rawQuizCtx.trim()
        : (topicText.length > 12000 ? topicText.substring(0, 12000) : topicText);
    final sourceSummary =
        sourceParts.isEmpty ? 'Input teks' : sourceParts.join(', ');

    final record = await storage.createSession(
      title: title,
      style: style,
      sourceSummary: sourceSummary,
      rawContext: quizContext,
      material: material,
    );

    _triggerBackgroundQuiz(
      sessionId: '${record['id']}',
      title: title,
      material: material,
      rawContext: quizContext,
      force: false,
    );

    await _sendJson(req.response, HttpStatus.created, _publicSession(record));
  }

  Future<void> _handleGenerateQuiz(HttpRequest req, String sessionId) async {
    final record = await storage.getSession(sessionId);
    if (record == null) {
      await _sendJson(req.response, HttpStatus.notFound, {
        'error': 'Sesi belajar tidak ditemukan.',
      });
      return;
    }

    var force = false;
    final rawBody = await utf8.decoder.bind(req).join();
    if (rawBody.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(rawBody);
        if (decoded is Map) {
          force = decoded['regenerate'] == true;
        }
      } catch (_) {}
    }

    if (record['quiz'] != null && !force) {
      await _sendJson(req.response, HttpStatus.ok, {
        'status': 'ready',
        'quiz': _publicQuiz(record['quiz']),
      });
      return;
    }

    final avoid = <String>[
      if (record['previous_questions'] is List)
        ...(record['previous_questions'] as List).map((e) => '$e'),
    ];
    if (record['quiz'] is Map) {
      avoid.addAll(
        _collectQuestionStems(Map<String, dynamic>.from(record['quiz'] as Map)),
      );
    }

    if (force) {
      await storage.updateSession(sessionId, {'quiz': null});
    }

    _triggerBackgroundQuiz(
      sessionId: sessionId,
      title: '${record['title'] ?? 'Materi Belajar'}',
      material: Map<String, dynamic>.from(
        (record['material'] as Map?) ?? const {},
      ),
      rawContext: '${record['raw_context'] ?? ''}',
      force: force,
      avoidQuestions: force ? avoid : null,
    );

    await _sendJson(req.response, HttpStatus.accepted, {'status': 'building'});
  }

  Future<void> _handleQuizStatus(HttpRequest req, String sessionId) async {
    final record = await storage.getSession(sessionId);
    if (record == null) {
      await _sendJson(req.response, HttpStatus.notFound, {
        'error': 'Sesi belajar tidak ditemukan.',
      });
      return;
    }

    final job = _quizJobs[sessionId];
    if (job != null && job.status == 'building') {
      if (record['quiz'] != null) {
        await _sendJson(req.response, HttpStatus.ok, {
          'status': 'ready',
          'quiz': _publicQuiz(record['quiz']),
        });
        return;
      }
      await _sendJson(req.response, HttpStatus.ok, {'status': 'building'});
      return;
    }

    if (job != null && job.status == 'error') {
      await _sendJson(req.response, HttpStatus.badGateway, {
        'status': 'error',
        'error': job.error ?? 'Gagal membuat kuis.',
      });
      return;
    }

    if (record['quiz'] != null) {
      await _sendJson(req.response, HttpStatus.ok, {
        'status': 'ready',
        'quiz': _publicQuiz(record['quiz']),
      });
      return;
    }

    await _sendJson(req.response, HttpStatus.ok, {'status': 'idle'});
  }

  Future<void> _handleGradeQuiz(HttpRequest req, String sessionId) async {
    final record = await storage.getSession(sessionId);
    if (record == null) {
      await _sendJson(req.response, HttpStatus.notFound, {
        'error': 'Sesi belajar tidak ditemukan.',
      });
      return;
    }

    final quiz = record['quiz'];
    if (quiz is! Map) {
      await _sendJson(req.response, HttpStatus.badRequest, {
        'error': 'Kuis belum dibuat untuk sesi ini.',
      });
      return;
    }

    final rawBody = await utf8.decoder.bind(req).join();
    Map<String, dynamic> payload = const {};
    if (rawBody.trim().isNotEmpty) {
      final decoded = jsonDecode(rawBody);
      if (decoded is Map<String, dynamic>) payload = decoded;
    }

    final mcqAnswers = payload['mcq_answers'] is Map
        ? Map<String, dynamic>.from(payload['mcq_answers'] as Map)
        : <String, dynamic>{};
    final essayAnswers = payload['essay_answers'] is Map
        ? Map<String, dynamic>.from(payload['essay_answers'] as Map)
        : <String, dynamic>{};

    try {
      final result = await gemini.gradeQuiz(
        quiz: Map<String, dynamic>.from(quiz),
        mcqAnswers: mcqAnswers,
        essayAnswers: essayAnswers,
      );
      final attempts = (record['attempt_count'] is int)
          ? (record['attempt_count'] as int) + 1
          : 1;
      await storage.updateSession(sessionId, {'attempt_count': attempts});
      await _sendJson(req.response, HttpStatus.ok, result);
    } on GeminiClientException catch (e) {
      await _sendJson(req.response, HttpStatus.badGateway, {
        'error': e.message,
      });
    }
  }
}
