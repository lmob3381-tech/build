# Preserve JNI bridge for libkisikit_core.so
-keep class com.kisikit.app.NativeBridge {
    *;
}

# Preserve WebView JavaScript interface
-keepclassmembers class com.kisikit.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
