package com.streamtube.app.engine

import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.TimeUnit

object NewPipeResolver {

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

    val sharedOkHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    @Volatile
    private var initialized = false

    private class OkHttpDownloader(private val client: OkHttpClient) : Downloader() {
        override fun execute(request: Request): Response {
            val httpMethod = request.httpMethod()
            val url = request.url()
            val headers = request.headers()
            val dataToSend = request.dataToSend()

            val requestBody = dataToSend?.toRequestBody(null)
            val builder = okhttp3.Request.Builder()
                .method(httpMethod, requestBody)
                .url(url)
                .addHeader("User-Agent", USER_AGENT)

            headers.forEach { (name, values) ->
                builder.removeHeader(name)
                values.forEach { value ->
                    builder.addHeader(name, value)
                }
            }

            client.newCall(builder.build()).execute().use { resp ->
                if (resp.code == 429) {
                    throw ReCaptchaException("reCaptcha Challenge requested", url)
                }
                val bodyStr = resp.body?.string()
                val latestUrl = resp.request.url.toString()
                return Response(
                    resp.code,
                    resp.message,
                    resp.headers.toMultimap(),
                    bodyStr,
                    latestUrl
                )
            }
        }
    }

    private fun verifyPlayable(url: String): Boolean {
        return runCatching {
            val req = okhttp3.Request.Builder()
                .url(url)
                .get()
                .addHeader("User-Agent", USER_AGENT)
                .addHeader("Range", "bytes=0-1023")
                .build()
            sharedOkHttpClient.newCall(req).execute().use { resp ->
                resp.code in 200..299 || resp.code == 206
            }
        }.getOrDefault(false)
    }

    fun ensureInit() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            NewPipe.init(
                OkHttpDownloader(sharedOkHttpClient),
                Localization("id", "ID"),
                ContentCountry("ID")
            )
            initialized = true
        }
    }

    fun resolveYouTubeStream(video: VideoItem): ResolvedStream? {
        ensureInit()
        val videoId = FastYouTubeClient.extractVideoId(video.webpageUrl)
            ?: FastYouTubeClient.extractVideoId(video.id)
            ?: return null
        val targetUrl = "https://www.youtube.com/watch?v=$videoId"

        val info = StreamInfo.getInfo(ServiceList.YouTube, targetUrl)
        val qualities = mutableListOf<StreamQualityOption>()

        // 1. HLS URL (jika tersedia — sangat stabil untuk live & iOS/mobile stream)
        val hls = info.hlsUrl
        if (!hls.isNullOrBlank() && hls.startsWith("http")) {
            qualities.add(
                StreamQualityOption(
                    id = "np_hls",
                    label = "Otomatis (Adaptif HD)",
                    height = 720,
                    fps = 30,
                    videoUrl = hls,
                    audioUrl = null,
                    isAudioOnly = false,
                    isMuxed = true,
                    ext = "hls",
                    fileSizeText = "Adaptif",
                    userAgent = USER_AGENT
                )
            )
        }

        // 2. Cari audio terbaik (prioritaskan M4A / AAC untuk kompatibilitas 100% di 32-bit)
        val bestAudio = info.audioStreams
            .filter { it.isUrl && it.content.startsWith("http") }
            .maxByOrNull { a ->
                val suffix = a.format?.suffix?.lowercase() ?: ""
                val bonus = if (suffix == "m4a" || suffix == "mp4") 10_000 else 0
                a.averageBitrate + bonus
            }
        val bestAudioUrl = bestAudio?.content
        val bestAudioExt = bestAudio?.format?.suffix ?: "m4a"

        // 3. Kumpulkan muxed streams (video + audio dalam 1 URL — PALING CEPAT & PASTI PLAY!)
        val seenHeights = HashSet<Int>()
        val muxedStreams = info.videoStreams
            .filter { it.isUrl && it.content.startsWith("http") && it.height > 0 }
            .sortedByDescending { it.height }

        muxedStreams.forEach { vs ->
            if (seenHeights.add(vs.height)) {
                val fpsSuffix = if (vs.fps >= 50) " ${vs.fps}fps" else ""
                qualities.add(
                    StreamQualityOption(
                        id = "np_mux_${vs.height}",
                        label = "${vs.height}p$fpsSuffix",
                        height = vs.height,
                        fps = vs.fps.takeIf { it > 0 },
                        videoUrl = vs.content,
                        audioUrl = null,
                        isAudioOnly = false,
                        isMuxed = true,
                        ext = vs.format?.suffix ?: "mp4",
                        fileSizeText = "Langsung",
                        userAgent = USER_AGENT
                    )
                )
            }
        }

        // 4. Kumpulkan video-only DASH HD (480p, 720p, 1080p, 1440p) dipasangkan dengan bestAudioUrl
        if (!bestAudioUrl.isNullOrBlank()) {
            val dashByHeight = info.videoOnlyStreams
                .filter { it.isUrl && it.content.startsWith("http") && it.height > 0 }
                .groupBy { it.height }

            dashByHeight.keys.sortedDescending().forEach { h ->
                if (seenHeights.contains(h)) return@forEach
                val group = dashByHeight[h].orEmpty()
                val best = group.maxByOrNull { vs ->
                    val ext = vs.format?.suffix?.lowercase() ?: ""
                    var score = 0
                    if (ext == "mp4") score += 100 // H.264 paling lancar di hardware decoder 32-bit
                    if (vs.fps >= 50) score += 20
                    score
                } ?: return@forEach

                seenHeights.add(h)
                val fpsSuffix = if (best.fps >= 50) " ${best.fps}fps" else ""
                qualities.add(
                    StreamQualityOption(
                        id = "np_dash_${h}",
                        label = "${h}p$fpsSuffix",
                        height = h,
                        fps = best.fps.takeIf { it > 0 },
                        videoUrl = best.content,
                        audioUrl = bestAudioUrl,
                        isAudioOnly = false,
                        isMuxed = false,
                        ext = best.format?.suffix ?: "mp4",
                        fileSizeText = "DASH HD",
                        userAgent = USER_AGENT
                    )
                )
            }
        }

        // Urutkan resolusi dari tinggi ke rendah (HLS tetap paling atas jika ada)
        val sortedQualities = qualities.sortedWith(
            compareByDescending<StreamQualityOption> { it.ext == "hls" }
                .thenByDescending { it.height }
        ).toMutableList()

        // 5. Tambahkan opsi Audio Saja
        if (!bestAudioUrl.isNullOrBlank()) {
            sortedQualities.add(
                StreamQualityOption(
                    id = "np_audio_only",
                    label = "Audio Saja (Hemat Kuota)",
                    height = 0,
                    fps = null,
                    videoUrl = null,
                    audioUrl = bestAudioUrl,
                    isAudioOnly = true,
                    isMuxed = true,
                    ext = bestAudioExt,
                    fileSizeText = "${bestAudio?.averageBitrate ?: 128} kbps",
                    userAgent = USER_AGENT
                )
            )
        }

        if (sortedQualities.isEmpty()) return null

        // Default start PALING STABIL & INSTAN: Muxed MP4 (360p/720p) atau HLS Adaptif -> lalu 720p/480p DASH
        val defaultQuality = sortedQualities.firstOrNull { !it.isAudioOnly && it.isMuxed && it.ext != "hls" && it.height >= 360 }
            ?: sortedQualities.firstOrNull { it.ext == "hls" }
            ?: sortedQualities.firstOrNull { !it.isAudioOnly && it.height == 720 }
            ?: sortedQualities.firstOrNull { !it.isAudioOnly && it.height == 480 }
            ?: sortedQualities.first()

        val updatedVideo = video.copy(
            id = videoId,
            title = info.name.orEmpty().ifBlank { video.title },
            channelName = info.uploaderName.orEmpty().ifBlank { video.channelName },
            durationText = if (info.duration > 0) YtDlpEngine.formatDuration(info.duration) else video.durationText,
            viewCountText = if (info.viewCount >= 0) YtDlpEngine.formatViews(info.viewCount) else video.viewCountText,
            webpageUrl = targetUrl
        )

        // Verifikasi cepat HTTP 200/206 pada defaultQuality; jika kena 403 biar otomatis fallback ke metode yt-dlp
        val checkUrl = defaultQuality.videoUrl ?: defaultQuality.audioUrl
        if (checkUrl != null && !verifyPlayable(checkUrl)) {
            return null
        }

        return ResolvedStream(
            videoItem = updatedVideo,
            description = info.description?.content.orEmpty(),
            qualities = sortedQualities,
            defaultQuality = defaultQuality
        )
    }
}
