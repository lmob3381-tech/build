package com.streamtube.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val PureWhite = Color(0xFFFFFFFF)
val SoftSurface = Color(0xFFF2F2F2)
val SoftSurfaceHover = Color(0xFFE8E8E8)
val InkPrimary = Color(0xFF0F0F0F)
val InkSecondary = Color(0xFF606060)
val BrandAccent = Color(0xFFE52D27)
val TealBadge = Color(0xFF0097A7)
val DividerSoft = Color(0xFFEEEEEE)

private val StreamTubeLightColors = lightColorScheme(
    primary = InkPrimary,
    onPrimary = PureWhite,
    secondary = BrandAccent,
    onSecondary = PureWhite,
    tertiary = TealBadge,
    background = PureWhite,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SoftSurface,
    onSurfaceVariant = InkSecondary,
    outlineVariant = DividerSoft
)

private val StreamTubeTypography = Typography(
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        color = InkPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        color = InkPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        color = InkSecondary
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun StreamTubeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StreamTubeLightColors,
        typography = StreamTubeTypography,
        content = content
    )
}
