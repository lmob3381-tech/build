package com.streamtube.app.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamtube.app.data.DownloadStatus
import com.streamtube.app.data.DownloadTask
import com.streamtube.app.data.DownloadedFile
import com.streamtube.app.engine.YtDlpEngine
import com.streamtube.app.ui.theme.BrandAccent
import com.streamtube.app.ui.theme.InkPrimary
import com.streamtube.app.ui.theme.InkSecondary
import com.streamtube.app.ui.theme.PureWhite
import com.streamtube.app.ui.theme.SoftSurface
import com.streamtube.app.ui.theme.TealBadge

@Composable
fun DownloadsScreen(
    tasks: List<DownloadTask>,
    files: List<DownloadedFile>,
    onCancelTask: (String) -> Unit,
    onPlayFile: (DownloadedFile) -> Unit,
    onDeleteFile: (DownloadedFile) -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Unduhan & Offline",
                    style = MaterialTheme.typography.titleLarge
                )
                IconButton(onClick = onRefresh) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Muat ulang",
                        tint = InkPrimary
                    )
                }
            }
        }

        if (tasks.isNotEmpty()) {
            item {
                Text(
                    text = "Antrean Aktif",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = InkSecondary
                )
            }
            items(tasks, key = { it.processId }) { task ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SoftSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = InkPrimary
                                )
                                val statusDetail = when (task.status) {
                                    DownloadStatus.DOWNLOADING -> {
                                        val eta = if (task.etaSeconds > 0) " (ETA ${task.etaSeconds}d)" else ""
                                        "${task.progress.toInt()}%$eta"
                                    }
                                    DownloadStatus.COMPLETED -> "Selesai"
                                    DownloadStatus.FAILED -> task.errorMessage ?: "Gagal"
                                    DownloadStatus.CANCELLED -> "Dibatalkan"
                                    DownloadStatus.QUEUED -> "Menunggu..."
                                }
                                Text(
                                    text = "${task.formatLabel} • $statusDetail",
                                    fontSize = 12.sp,
                                    color = InkSecondary
                                )
                            }
                            if (task.status == DownloadStatus.DOWNLOADING) {
                                IconButton(onClick = { onCancelTask(task.processId) }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Cancel,
                                        contentDescription = "Batalkan",
                                        tint = BrandAccent
                                    )
                                }
                            }
                        }
                        if (task.status == DownloadStatus.DOWNLOADING) {
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { (task.progress / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape),
                                color = BrandAccent,
                                trackColor = PureWhite
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Tersimpan di Download/StreamTube (${files.size})",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = InkSecondary
            )
        }

        if (files.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SoftSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DownloadDone,
                            contentDescription = null,
                            tint = InkSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Belum ada video atau audio yang diunduh",
                            color = InkSecondary,
                            fontSize = 13.5.sp
                        )
                    }
                }
            }
        } else {
            items(files, key = { it.path }) { file ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SoftSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPlayFile(file) }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (file.isAudio) TealBadge else InkPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (file.isAudio) Icons.Rounded.Headphones else Icons.Rounded.Movie,
                                contentDescription = null,
                                tint = PureWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = file.name,
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                color = InkPrimary
                            )
                            Text(
                                text = YtDlpEngine.formatBytes(file.sizeBytes),
                                fontSize = 12.sp,
                                color = InkSecondary
                            )
                        }
                        IconButton(onClick = { onDeleteFile(file) }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "Hapus file",
                                tint = InkSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InfoScreen(
    engineStatus: String,
    isUpdating: Boolean,
    onUpdateYtDlp: () -> Unit
) {
    val abis = Build.SUPPORTED_ABIS.joinToString(", ")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Info & Mesin Streaming",
            style = MaterialTheme.typography.titleLarge
        )

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SoftSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Status Engine",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = InkPrimary
                )
                Text(text = engineStatus, fontSize = 13.5.sp, color = InkSecondary)
                Text(
                    text = "Arsitektur Perangkat: $abis",
                    fontSize = 13.sp,
                    color = InkSecondary
                )
                Text(
                    text = "Komponen: yt-dlp + FFmpeg + Aria2c + Media3 ExoPlayer",
                    fontSize = 13.sp,
                    color = InkSecondary
                )
            }
        }

        Button(
            onClick = onUpdateYtDlp,
            enabled = !isUpdating,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = InkPrimary, contentColor = PureWhite),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (isUpdating) {
                CircularProgressIndicator(
                    color = PureWhite,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Memperbarui yt-dlp...")
            } else {
                Icon(imageVector = Icons.Rounded.SystemUpdate, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Perbarui Core yt-dlp")
            }
        }
    }
}

@Composable
fun DirectUrlDialog(
    onDismiss: () -> Unit,
    onPlayUrl: (String) -> Unit
) {
    var urlText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Icon(
                imageVector = Icons.Rounded.Link,
                contentDescription = null,
                tint = InkPrimary
            )
        },
        title = {
            Text(
                text = "Buka Tautan Video",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            OutlinedTextField(
                value = urlText,
                onValueChange = { urlText = it },
                placeholder = { Text("https://youtu.be/... atau URL YouTube") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (urlText.isNotBlank()) {
                        onPlayUrl(urlText.trim())
                        onDismiss()
                    }
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = InkPrimary)
            ) {
                Text("Putar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = InkSecondary)
            }
        }
    )
}
