package com.streamtube.app.data

import androidx.compose.runtime.Immutable

@Immutable
data class VideoItem(
    val id: String,
    val title: String,
    val channelName: String,
    val thumbnailUrl: String,
    val durationText: String,
    val viewCountText: String,
    val uploadDateText: String,
    val webpageUrl: String,
    val isLive: Boolean = false
)

@Immutable
data class StreamQualityOption(
    val id: String,
    val label: String,
    val height: Int,
    val fps: Int?,
    val videoUrl: String?,
    val audioUrl: String?,
    val isAudioOnly: Boolean = false,
    val isMuxed: Boolean = false,
    val ext: String = "mp4",
    val fileSizeText: String = "",
    val userAgent: String = "",
    val httpHeaders: Map<String, String> = emptyMap()
)

@Immutable
data class ResolvedStream(
    val videoItem: VideoItem,
    val description: String,
    val qualities: List<StreamQualityOption>,
    val defaultQuality: StreamQualityOption
)

enum class DownloadFormat(val label: String, val height: Int, val isAudio: Boolean) {
    VIDEO_1080("Video 1080p (MP4)", 1080, false),
    VIDEO_720("Video 720p (MP4)", 720, false),
    VIDEO_480("Video 480p (MP4)", 480, false),
    VIDEO_360("Video 360p (MP4)", 360, false),
    AUDIO_MP3("Audio MP3 (FFmpeg)", 0, true),
    AUDIO_M4A("Audio M4A (Cepat)", 0, true)
}

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    COMPLETED,
    FAILED,
    CANCELLED
}

@Immutable
data class DownloadTask(
    val processId: String,
    val title: String,
    val thumbnailUrl: String,
    val formatLabel: String,
    val progress: Float = 0f,
    val etaSeconds: Long = -1L,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val outputPath: String? = null,
    val errorMessage: String? = null
)

@Immutable
data class DownloadedFile(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val isAudio: Boolean
)
