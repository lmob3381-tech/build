package com.streamtube.app.engine

import android.content.Context
import android.os.Environment
import com.streamtube.app.data.DownloadFormat
import com.streamtube.app.data.DownloadedFile
import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.zip.ZipFile

class YtDlpEngine(private val context: Context) {

    private val initMutex = Mutex()
    private val updateMutex = Mutex()

    @Volatile
    private var initialized = false

    private data class CachedStream(val stream: ResolvedStream, val timestampMs: Long)
    private val streamCache = HashMap<String, CachedStream>()
    private val cacheTtlMs = 15L * 60L * 1000L

    suspend fun ensureInitialized(): Result<Unit> = withContext(Dispatchers.IO) {
        if (initialized) return@withContext Result.success(Unit)
        initMutex.withLock {
            if (initialized) return@withContext Result.success(Unit)
            runCatching {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                runCatching { Aria2c.getInstance().init(context) }

                if (!isYtDlpZipValid()) {
                    repairYtDlpInternal()
                }
                initialized = true
            }
        }
    }

    private fun getYtDlpBinaryFile(): File {
        return File(context.noBackupFilesDir, "youtubedl-android/yt-dlp/yt-dlp")
    }

    private fun isYtDlpZipValid(): Boolean {
        val bin = getYtDlpBinaryFile()
        if (!bin.exists() || bin.length() < 100_000L) return false
        return runCatching {
            ZipFile(bin).use { zf ->
                zf.getEntry("__main__.py") != null
            }
        }.getOrDefault(false)
    }

    private fun repairYtDlpInternal() {
        val bin = getYtDlpBinaryFile()
        runCatching {
            if (bin.exists()) bin.delete()
        }
        val stableOk = runCatching {
            YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE)
        }.isSuccess
        if (!stableOk || !isYtDlpZipValid()) {
            runCatching {
                if (bin.exists()) bin.delete()
                YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.NIGHTLY)
            }
        }
    }

    private fun isZipCorruptionError(t: Throwable): Boolean {
        val msg = (t.message ?: "") + " " + (t.cause?.message ?: "")
        return msg.contains("ZipImportError", ignoreCase = true) ||
            msg.contains("bad local file header", ignoreCase = true) ||
            msg.contains("not a Zip file", ignoreCase = true) ||
            msg.contains("BadZipFile", ignoreCase = true)
    }

    private suspend fun executeWithAutoRepair(
        request: YoutubeDLRequest,
        processId: String? = null,
        callback: ((Float, Long, String) -> Unit)? = null
    ): YoutubeDLResponse {
        updateMutex.withLock { /* tunggu jika sedang update */ }

        return try {
            if (processId != null && callback != null) {
                YoutubeDL.getInstance().execute(request, processId, callback)
            } else {
                YoutubeDL.getInstance().execute(request)
            }
        } catch (err: Throwable) {
            if (isZipCorruptionError(err)) {
                updateMutex.withLock {
                    repairYtDlpInternal()
                }
                if (processId != null && callback != null) {
                    YoutubeDL.getInstance().execute(request, processId, callback)
                } else {
                    YoutubeDL.getInstance().execute(request)
                }
            } else {
                throw err
            }
        }
    }

    suspend fun updateBinary(): Result<String> = withContext(Dispatchers.IO) {
        ensureInitialized().onFailure { return@withContext Result.failure(it) }
        updateMutex.withLock {
            runCatching {
                if (!isYtDlpZipValid()) {
                    runCatching { getYtDlpBinaryFile().delete() }
                }
                val status = YoutubeDL.getInstance().updateYoutubeDL(
                    context,
                    YoutubeDL.UpdateChannel.STABLE
                )
                when (status) {
                    YoutubeDL.UpdateStatus.DONE -> "yt-dlp berhasil diperbarui ke versi terbaru"
                    YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "yt-dlp sudah menggunakan versi terbaru"
                    else -> "Pembaruan selesai"
                }
            }
        }
    }

    suspend fun searchYouTube(query: String, limit: Int = 18): Result<List<VideoItem>> =
        withContext(Dispatchers.IO) {
            val trimmed = query.trim()
            if (trimmed.isEmpty()) return@withContext Result.success(emptyList())

            // Jalur cepat (< 1 detik): Native Kotlin InnerTube Search tanpa booting Python
            if (!isDirectUrl(trimmed)) {
                val fastResult = runCatching { FastYouTubeClient.search(trimmed, limit) }.getOrNull()
                if (!fastResult.isNullOrEmpty()) {
                    return@withContext Result.success(fastResult)
                }
            }

            // Fallback ke yt-dlp untuk URL langsung atau jika InnerTube gagal
            ensureInitialized().onFailure { return@withContext Result.failure(it) }
            runCatching {
                val target = if (isDirectUrl(trimmed)) trimmed else "ytsearch$limit:$trimmed"
                val request = YoutubeDLRequest(target).apply {
                    addOption("--flat-playlist")
                    addOption("--dump-json")
                    addOption("--no-warnings")
                    addOption("--skip-download")
                    addOption("--ignore-errors")
                    addOption("--socket-timeout", "10")
                }
                val response = executeWithAutoRepair(request)
                parseFlatJsonLines(response.out.orEmpty())
            }.recoverCatching { err ->
                throw Exception(friendlyErrorMessage(err))
            }
        }

    suspend fun resolveStream(video: VideoItem, forceYtDlp: Boolean = false): Result<ResolvedStream> =
        withContext(Dispatchers.IO) {
            val cacheKey = FastYouTubeClient.extractVideoId(video.webpageUrl) ?: video.webpageUrl
            val now = System.currentTimeMillis()

            if (!forceYtDlp) {
                synchronized(streamCache) {
                    streamCache[cacheKey]?.let { cached ->
                        if (now - cached.timestampMs < cacheTtlMs) {
                            return@withContext Result.success(cached.stream)
                        }
                    }
                }

                // Jalur UTAMA: NewPipeExtractor v0.27.1 (JVM murni, n-parameter JS solver, anti-403 + HTTP probe)
                val npStream = runCatching { NewPipeResolver.resolveYouTubeStream(video) }.getOrNull()
                if (npStream != null && npStream.qualities.isNotEmpty()) {
                    synchronized(streamCache) {
                        streamCache[cacheKey] = CachedStream(npStream, System.currentTimeMillis())
                    }
                    return@withContext Result.success(npStream)
                }

                // Jalur cadangan 1: FastYouTubeClient InnerTube dengan verifikasi HTTP 200/206
                val fastStream = runCatching { FastYouTubeClient.resolvePlayer(video) }.getOrNull()
                if (fastStream != null && fastStream.qualities.isNotEmpty()) {
                    synchronized(streamCache) {
                        streamCache[cacheKey] = CachedStream(fastStream, System.currentTimeMillis())
                    }
                    return@withContext Result.success(fastStream)
                }
            }

            // Jalur cadangan 2 (metode persis skrip Termux user: player_client=android,web + full http_headers)
            ensureInitialized().onFailure { return@withContext Result.failure(it) }
            runCatching {
                val request = YoutubeDLRequest(video.webpageUrl).apply {
                    addOption("--dump-json")
                    addOption("--no-playlist")
                    addOption("--no-warnings")
                    addOption("--skip-download")
                    addOption("--socket-timeout", "12")
                    addOption("--extractor-args", "youtube:player_client=android,web")
                }
                val response = executeWithAutoRepair(request)
                val jsonText = response.out.orEmpty()
                    .lineSequence()
                    .firstOrNull { it.trim().startsWith("{") }
                    ?: error("Tidak ada respons metadata dari yt-dlp")

                val root = JSONObject(jsonText)
                val title = root.optString("title").ifBlank { video.title }
                val channel = root.optString("uploader")
                    .ifBlank { root.optString("channel") }
                    .ifBlank { video.channelName }
                val thumb = root.optString("thumbnail").ifBlank { video.thumbnailUrl }
                val durationSec = root.optLong("duration", 0L)
                val viewCount = root.optLong("view_count", -1L)
                val uploadDate = root.optString("upload_date", "")
                val description = root.optString("description", "")
                val isLive = root.optBoolean("is_live", false)

                val updatedItem = video.copy(
                    title = title,
                    channelName = channel,
                    thumbnailUrl = thumb,
                    durationText = if (isLive) "LIVE" else formatDuration(durationSec).ifBlank { video.durationText },
                    viewCountText = if (viewCount >= 0) formatViews(viewCount) else video.viewCountText,
                    uploadDateText = formatUploadDate(uploadDate).ifBlank { video.uploadDateText },
                    isLive = isLive
                )

                val qualities = extractQualities(root)
                if (qualities.isEmpty()) {
                    error("Tidak ditemukan stream video yang dapat diputar")
                }

                // Prioritas default persis metode Termux user: progressive muxed MP4 dulu (paling pasti play!)
                val defaultQuality = qualities.firstOrNull { !it.isAudioOnly && it.isMuxed && it.ext == "mp4" && it.height >= 360 }
                    ?: qualities.firstOrNull { !it.isAudioOnly && it.isMuxed }
                    ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 720 }
                    ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 480 }
                    ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 360 }
                    ?: qualities.first()

                ResolvedStream(
                    videoItem = updatedItem,
                    description = description,
                    qualities = qualities,
                    defaultQuality = defaultQuality
                ).also { resolved ->
                    synchronized(streamCache) {
                        streamCache[cacheKey] = CachedStream(resolved, System.currentTimeMillis())
                    }
                }
            }.recoverCatching { err ->
                throw Exception(friendlyErrorMessage(err))
            }
        }

    suspend fun downloadMedia(
        url: String,
        format: DownloadFormat,
        processId: String,
        onProgress: (Float, Long) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        ensureInitialized().onFailure { return@withContext Result.failure(it) }
        runCatching {
            val outputDir = getDownloadDirectory()
            if (!outputDir.exists()) outputDir.mkdirs()

            val template = File(outputDir, "%(title).80s [%(id)s].%(ext)s").absolutePath
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--no-warnings")
                addOption("-o", template)

                if (format.isAudio) {
                    addOption("-x")
                    if (format == DownloadFormat.AUDIO_MP3) {
                        addOption("--audio-format", "mp3")
                        addOption("--audio-quality", "0")
                    } else {
                        addOption("--audio-format", "m4a")
                    }
                } else {
                    val selector =
                        "bestvideo[height<=${format.height}][ext=mp4]+bestaudio[ext=m4a]/" +
                            "bestvideo[height<=${format.height}]+bestaudio/" +
                            "best[height<=${format.height}]/best"
                    addOption("-f", selector)
                    addOption("--merge-output-format", "mp4")
                }
            }

            executeWithAutoRepair(request, processId) { progress, etaInSeconds, _ ->
                onProgress(progress.coerceIn(0f, 100f), etaInSeconds)
            }

            outputDir.listFiles()
                ?.filter { it.isFile }
                ?.maxByOrNull { it.lastModified() }
                ?: outputDir
        }.recoverCatching { err ->
            throw Exception(friendlyErrorMessage(err))
        }
    }

    private fun friendlyErrorMessage(err: Throwable): String {
        val raw = err.localizedMessage ?: err.message ?: "Terjadi kesalahan"
        return when {
            isZipCorruptionError(err) ->
                "Core yt-dlp rusak saat diunduh. Pastikan internet aktif lalu ketuk 'Perbarui Core yt-dlp' di menu Info."
            raw.contains("Unable to resolve host", ignoreCase = true) ||
                raw.contains("Temporary failure in name resolution", ignoreCase = true) ->
                "Tidak ada koneksi internet. Periksa jaringan kamu lalu coba lagi."
            raw.length > 220 ->
                raw.lineSequence().lastOrNull { it.isNotBlank() }?.take(180) ?: raw.take(180)
            else -> raw
        }
    }

    fun cancelDownload(processId: String) {
        runCatching {
            YoutubeDL.getInstance().destroyProcessById(processId)
        }
    }

    fun getDownloadDirectory(): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return File(publicDownloads, "StreamTube")
    }

    fun listDownloadedFiles(): List<DownloadedFile> {
        val dir = getDownloadDirectory()
        if (!dir.exists()) return emptyList()
        val mediaExts = setOf("mp4", "mkv", "webm", "mp3", "m4a", "opus", "ogg")
        val audioExts = setOf("mp3", "m4a", "opus", "ogg")
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in mediaExts }
            ?.sortedByDescending { it.lastModified() }
            ?.map { file ->
                DownloadedFile(
                    name = file.name,
                    path = file.absolutePath,
                    sizeBytes = file.length(),
                    lastModified = file.lastModified(),
                    isAudio = file.extension.lowercase(Locale.ROOT) in audioExts
                )
            }
            ?: emptyList()
    }

    fun deleteDownloadedFile(path: String): Boolean {
        return runCatching { File(path).delete() }.getOrDefault(false)
    }

    private fun parseHttpHeaders(obj: JSONObject?): Map<String, String> {
        if (obj == null) return emptyMap()
        val map = LinkedHashMap<String, String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = obj.optString(k, "")
            if (v.isNotBlank()) map[k] = v
        }
        return map
    }

    private fun extractQualities(root: JSONObject): List<StreamQualityOption> {
        val formatsArray = root.optJSONArray("formats")
        val fallbackDirectUrl = root.optString("url", "")
        val rootHeaders = parseHttpHeaders(root.optJSONObject("http_headers"))
        val rootUa = rootHeaders["User-Agent"].orEmpty()

        if (formatsArray == null || formatsArray.length() == 0) {
            if (fallbackDirectUrl.isNotBlank()) {
                return listOf(
                    StreamQualityOption(
                        id = "default",
                        label = "Otomatis",
                        height = 720,
                        fps = null,
                        videoUrl = fallbackDirectUrl,
                        audioUrl = null,
                        isMuxed = true,
                        userAgent = rootUa,
                        httpHeaders = rootHeaders
                    )
                )
            }
            return emptyList()
        }

        var bestAudioUrl: String? = null
        var bestAudioAbr = -1.0
        var bestAudioExt = "m4a"
        var bestAudioSize = ""
        var bestAudioHeaders = rootHeaders

        data class RawVideo(
            val height: Int,
            val fps: Int?,
            val url: String,
            val ext: String,
            val isMuxed: Boolean,
            val vcodec: String,
            val sizeText: String,
            val headers: Map<String, String>
        )

        val candidates = mutableListOf<RawVideo>()

        for (i in 0 until formatsArray.length()) {
            val obj = formatsArray.optJSONObject(i) ?: continue
            val url = obj.optString("url", "")
            if (url.isBlank()) continue
            val protocol = obj.optString("protocol", "")
            if (protocol.contains("mhtml") || protocol.contains("storyboard")) continue

            val vcodec = obj.optString("vcodec", "none")
            val acodec = obj.optString("acodec", "none")
            val ext = obj.optString("ext", "mp4")
            val height = obj.optInt("height", 0)
            val fps = obj.optInt("fps", 0).takeIf { it > 0 }
            val filesize = obj.optLong("filesize", obj.optLong("filesize_approx", 0L))
            val sizeText = if (filesize > 0) formatBytes(filesize) else ""
            val fmtHeaders = parseHttpHeaders(obj.optJSONObject("http_headers")).ifEmpty { rootHeaders }

            val hasVideo = vcodec != "none" && vcodec.isNotBlank() && height > 0
            val hasAudio = acodec != "none" && acodec.isNotBlank()

            if (!hasVideo && hasAudio) {
                val abr = obj.optDouble("abr", obj.optDouble("tbr", 0.0))
                val bonus = if (ext == "m4a" || acodec.startsWith("mp4a")) 50.0 else 0.0
                if (abr + bonus > bestAudioAbr) {
                    bestAudioAbr = abr + bonus
                    bestAudioUrl = url
                    bestAudioExt = ext
                    bestAudioSize = sizeText
                    bestAudioHeaders = fmtHeaders
                }
            } else if (hasVideo) {
                candidates.add(
                    RawVideo(
                        height = height,
                        fps = fps,
                        url = url,
                        ext = ext,
                        isMuxed = hasAudio,
                        vcodec = vcodec,
                        sizeText = sizeText,
                        headers = fmtHeaders
                    )
                )
            }
        }

        val byHeight = candidates.groupBy { it.height }
        val result = mutableListOf<StreamQualityOption>()

        byHeight.keys.sortedDescending().forEach { height ->
            val group = byHeight[height].orEmpty()
            val best = group.maxByOrNull { item ->
                var score = 0
                if (item.vcodec.startsWith("avc1") || item.ext == "mp4") score += 40
                if (item.isMuxed) score += 25
                if ((item.fps ?: 30) >= 50) score += 10
                score
            } ?: return@forEach

            if (!best.isMuxed && bestAudioUrl == null) return@forEach

            val fpsSuffix = if ((best.fps ?: 0) >= 50) " ${best.fps}fps" else ""
            val ua = best.headers["User-Agent"] ?: rootUa
            result.add(
                StreamQualityOption(
                    id = "v_${height}_${best.ext}",
                    label = "${height}p$fpsSuffix",
                    height = height,
                    fps = best.fps,
                    videoUrl = best.url,
                    audioUrl = if (best.isMuxed) null else bestAudioUrl,
                    isAudioOnly = false,
                    isMuxed = best.isMuxed,
                    ext = best.ext,
                    fileSizeText = best.sizeText,
                    userAgent = ua,
                    httpHeaders = best.headers
                )
            )
        }

        if (bestAudioUrl != null) {
            result.add(
                StreamQualityOption(
                    id = "audio_only",
                    label = "Audio Saja (Hemat Kuota)",
                    height = 0,
                    fps = null,
                    videoUrl = null,
                    audioUrl = bestAudioUrl,
                    isAudioOnly = true,
                    isMuxed = true,
                    ext = bestAudioExt,
                    fileSizeText = bestAudioSize,
                    userAgent = bestAudioHeaders["User-Agent"] ?: rootUa,
                    httpHeaders = bestAudioHeaders
                )
            )
        }

        if (result.isEmpty() && fallbackDirectUrl.isNotBlank()) {
            result.add(
                StreamQualityOption(
                    id = "fallback",
                    label = "Otomatis",
                    height = 360,
                    fps = null,
                    videoUrl = fallbackDirectUrl,
                    audioUrl = null,
                    isMuxed = true,
                    userAgent = rootUa,
                    httpHeaders = rootHeaders
                )
            )
        }

        return result
    }

    private fun parseFlatJsonLines(output: String): List<VideoItem> {
        val list = mutableListOf<VideoItem>()
        output.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            if (!line.startsWith("{")) return@forEach
            runCatching {
                val obj = JSONObject(line)
                val id = obj.optString("id", "").ifBlank { return@runCatching }
                val title = obj.optString("title", "Tanpa Judul")
                val channel = obj.optString("channel")
                    .ifBlank { obj.optString("uploader") }
                    .ifBlank { "YouTube Channel" }

                val webpageUrl = obj.optString("webpage_url")
                    .ifBlank { obj.optString("url") }
                    .let { u ->
                        when {
                            u.startsWith("http") -> u
                            else -> "https://www.youtube.com/watch?v=$id"
                        }
                    }

                val thumb = extractBestThumbnail(obj, id)
                val durationSec = obj.optLong("duration", 0L)
                val isLive = obj.optString("live_status") == "is_live" || obj.optBoolean("is_live", false)
                val viewCount = obj.optLong("view_count", -1L)
                val uploadDate = obj.optString("upload_date", "")

                list.add(
                    VideoItem(
                        id = id,
                        title = title,
                        channelName = channel,
                        thumbnailUrl = thumb,
                        durationText = if (isLive) "LIVE" else formatDuration(durationSec),
                        viewCountText = if (viewCount >= 0) formatViews(viewCount) else "",
                        uploadDateText = formatUploadDate(uploadDate),
                        webpageUrl = webpageUrl,
                        isLive = isLive
                    )
                )
            }
        }
        return list
    }

    private fun extractBestThumbnail(obj: JSONObject, videoId: String): String {
        val direct = obj.optString("thumbnail", "")
        if (direct.startsWith("http")) return direct
        val thumbs = obj.optJSONArray("thumbnails")
        if (thumbs != null && thumbs.length() > 0) {
            val last = thumbs.optJSONObject(thumbs.length() - 1)
            val u = last?.optString("url", "").orEmpty()
            if (u.startsWith("http")) return u
        }
        return "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
    }

    private fun isDirectUrl(text: String): Boolean {
        return text.startsWith("http://", ignoreCase = true) ||
            text.startsWith("https://", ignoreCase = true)
    }

    companion object {
        fun formatDuration(seconds: Long): String {
            if (seconds <= 0L) return ""
            val h = seconds / 3600
            val m = (seconds % 3600) / 60
            val s = seconds % 60
            return if (h > 0) {
                String.format(Locale.US, "%d:%02d:%02d", h, m, s)
            } else {
                String.format(Locale.US, "%d:%02d", m, s)
            }
        }

        fun formatViews(views: Long): String {
            return when {
                views >= 1_000_000_000L -> String.format(Locale.US, "%.1f M", views / 1_000_000_000.0)
                views >= 1_000_000L -> String.format(Locale.US, "%.1f jt", views / 1_000_000.0)
                views >= 1_000L -> String.format(Locale.US, "%d rb", views / 1_000L)
                else -> "$views"
            }
        }

        fun formatUploadDate(yyyymmdd: String): String {
            if (yyyymmdd.length != 8) return ""
            val y = yyyymmdd.substring(0, 4)
            val m = yyyymmdd.substring(4, 6)
            val d = yyyymmdd.substring(6, 8)
            return "$d/$m/$y"
        }

        fun formatBytes(bytes: Long): String {
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb)
            }
        }
    }
}
