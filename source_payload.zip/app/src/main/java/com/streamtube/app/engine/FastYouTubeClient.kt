package com.streamtube.app.engine

import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object FastYouTubeClient {

    private const val SEARCH_URL = "https://www.youtube.com/youtubei/v1/search?prettyPrint=false"
    private const val PLAYER_URL = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"

    private const val UA_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
    private const val UA_IOS =
        "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
    private const val UA_ANDROID_VR =
        "com.google.android.apps.youtube.vr.oculus/1.71.26 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    private const val UA_PS4_TV =
        "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"

    private data class ClientProfile(
        val name: String,
        val version: String,
        val userAgent: String,
        val clientIdHeader: String,
        val extraClientFields: Map<String, Any> = emptyMap()
    )

    // Urutan prioritas: IOS (punya HLS anti-403) -> ANDROID_VR -> TVHTML5 (PS4 UA)
    private val playerProfiles = listOf(
        ClientProfile(
            name = "IOS",
            version = "20.10.4",
            userAgent = UA_IOS,
            clientIdHeader = "5",
            extraClientFields = mapOf(
                "deviceMake" to "Apple",
                "deviceModel" to "iPhone16,2",
                "osName" to "iPhone",
                "osVersion" to "18.3.2.22D82"
            )
        ),
        ClientProfile(
            name = "ANDROID_VR",
            version = "1.71.26",
            userAgent = UA_ANDROID_VR,
            clientIdHeader = "28",
            extraClientFields = mapOf(
                "deviceMake" to "Oculus",
                "deviceModel" to "Quest 3",
                "osName" to "Android",
                "osVersion" to "12L",
                "androidSdkVersion" to 32
            )
        ),
        ClientProfile(
            name = "TVHTML5",
            version = "7.20250219.16.00",
            userAgent = UA_PS4_TV,
            clientIdHeader = "7"
        )
    )

    fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) return trimmed
        val patterns = listOf(
            Regex("""(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/|youtube\.com/embed/|youtube\.com/live/)([a-zA-Z0-9_-]{11})""")
        )
        for (regex in patterns) {
            val match = regex.find(trimmed)
            if (match != null) return match.groupValues[1]
        }
        return null
    }

    fun search(query: String, limit: Int = 20): List<VideoItem> {
        val payload = JSONObject().apply {
            put("query", query)
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", "WEB")
                    put("clientVersion", "2.20250219.01.00")
                    put("hl", "id")
                    put("gl", "ID")
                })
            })
        }

        val responseText = postJson(
            urlStr = SEARCH_URL,
            body = payload.toString(),
            userAgent = UA_WEB,
            clientIdHeader = "1",
            clientVersionHeader = "2.20250219.01.00"
        )
        val root = JSONObject(responseText)
        val results = mutableListOf<VideoItem>()
        val seenIds = HashSet<String>()
        collectVideoRenderers(root, results, seenIds, limit)
        return results
    }

    fun resolvePlayer(video: VideoItem): ResolvedStream? {
        val videoId = extractVideoId(video.webpageUrl) ?: extractVideoId(video.id) ?: return null

        for (profile in playerProfiles) {
            val resolved = runCatching {
                fetchPlayerWithProfile(video, videoId, profile)
            }.getOrNull() ?: continue

            // Verifikasi URL default benar-benar bisa diakses (HTTP 200/206, bukan 403!)
            val testUrl = resolved.defaultQuality.videoUrl ?: resolved.defaultQuality.audioUrl
            if (testUrl != null && isUrlPlayable(testUrl, resolved.defaultQuality.userAgent)) {
                return resolved
            }
        }
        return null
    }

    private fun isUrlPlayable(urlStr: String, userAgent: String): Boolean {
        return runCatching {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", userAgent.ifBlank { UA_IOS })
                setRequestProperty("Range", "bytes=0-1023")
            }
            try {
                val code = conn.responseCode
                code in 200..299 || code == 206
            } finally {
                conn.disconnect()
            }
        }.getOrDefault(false)
    }

    private fun fetchPlayerWithProfile(
        video: VideoItem,
        videoId: String,
        profile: ClientProfile
    ): ResolvedStream? {
        val clientJson = JSONObject().apply {
            put("clientName", profile.name)
            put("clientVersion", profile.version)
            put("hl", "id")
            put("gl", "ID")
            profile.extraClientFields.forEach { (k, v) -> put(k, v) }
        }
        val payload = JSONObject().apply {
            put("videoId", videoId)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
            put("context", JSONObject().apply {
                put("client", clientJson)
            })
        }

        val responseText = postJson(
            urlStr = PLAYER_URL,
            body = payload.toString(),
            userAgent = profile.userAgent,
            clientIdHeader = profile.clientIdHeader,
            clientVersionHeader = profile.version
        )
        val root = JSONObject(responseText)
        val playability = root.optJSONObject("playabilityStatus")
        val status = playability?.optString("status", "") ?: ""
        if (status != "OK") return null

        val streamingData = root.optJSONObject("streamingData") ?: return null
        val details = root.optJSONObject("videoDetails")

        val title = details?.optString("title").orEmpty().ifBlank { video.title }
        val author = details?.optString("author").orEmpty().ifBlank { video.channelName }
        val lengthSec = details?.optString("lengthSeconds", "0")?.toLongOrNull() ?: 0L
        val viewCount = details?.optString("viewCount", "-1")?.toLongOrNull() ?: -1L
        val isLive = details?.optBoolean("isLiveContent", false) == true && lengthSec == 0L
        val description = details?.optString("shortDescription", "").orEmpty()
        val thumb = extractBestThumbnailFromDetails(details, videoId, video.thumbnailUrl)

        val updatedVideo = video.copy(
            id = videoId,
            title = title,
            channelName = author,
            thumbnailUrl = thumb,
            durationText = if (isLive) "LIVE" else YtDlpEngine.formatDuration(lengthSec).ifBlank { video.durationText },
            viewCountText = if (viewCount >= 0L) YtDlpEngine.formatViews(viewCount) else video.viewCountText,
            webpageUrl = "https://www.youtube.com/watch?v=$videoId",
            isLive = isLive
        )

        val qualities = parseStreamingData(streamingData, profile.userAgent)
        if (qualities.isEmpty()) return null

        // Prioritas default: HLS Adaptif -> Progressive MP4 -> DASH 720p/480p/360p
        val defaultQuality = qualities.firstOrNull { it.ext == "hls" }
            ?: qualities.firstOrNull { !it.isAudioOnly && it.isMuxed && it.height >= 360 }
            ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 720 }
            ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 480 }
            ?: qualities.firstOrNull { !it.isAudioOnly && it.height == 360 }
            ?: qualities.first()

        return ResolvedStream(
            videoItem = updatedVideo,
            description = description,
            qualities = qualities,
            defaultQuality = defaultQuality
        )
    }

    private fun parseStreamingData(
        streamingData: JSONObject,
        userAgent: String
    ): List<StreamQualityOption> {
        val result = mutableListOf<StreamQualityOption>()

        val hlsUrl = streamingData.optString("hlsManifestUrl", "")
        if (hlsUrl.startsWith("http")) {
            result.add(
                StreamQualityOption(
                    id = "hls_auto",
                    label = "Otomatis (Adaptif HD)",
                    height = 720,
                    fps = 30,
                    videoUrl = hlsUrl,
                    audioUrl = null,
                    isAudioOnly = false,
                    isMuxed = true,
                    ext = "hls",
                    fileSizeText = "Adaptif",
                    userAgent = userAgent
                )
            )
        }

        data class Candidate(
            val height: Int,
            val fps: Int?,
            val url: String,
            val ext: String,
            val isMuxed: Boolean,
            val isAvc: Boolean,
            val sizeText: String
        )

        val videoCandidates = mutableListOf<Candidate>()
        var bestAudioUrl: String? = null
        var bestAudioScore = -1.0
        var bestAudioExt = "m4a"
        var bestAudioSize = ""

        fun processArray(arr: JSONArray?, muxed: Boolean) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val directUrl = obj.optString("url", "")
                if (!directUrl.startsWith("http")) continue

                val mimeType = obj.optString("mimeType", "")
                val height = obj.optInt("height", 0)
                val fps = obj.optInt("fps", 0).takeIf { it > 0 }
                val bitrate = obj.optDouble("bitrate", 0.0)
                val contentLen = obj.optString("contentLength", "0").toLongOrNull() ?: 0L
                val sizeText = if (contentLen > 0L) YtDlpEngine.formatBytes(contentLen) else ""

                val isVideo = mimeType.startsWith("video/") && height > 0
                val isAudio = mimeType.startsWith("audio/")

                if (isAudio) {
                    val isMp4a = mimeType.contains("mp4a", ignoreCase = true) || mimeType.contains("audio/mp4")
                    val score = bitrate + (if (isMp4a) 1_000_000.0 else 0.0)
                    if (score > bestAudioScore) {
                        bestAudioScore = score
                        bestAudioUrl = directUrl
                        bestAudioExt = if (isMp4a) "m4a" else "webm"
                        bestAudioSize = sizeText
                    }
                } else if (isVideo) {
                    val isAvc = mimeType.contains("avc1", ignoreCase = true) || mimeType.contains("video/mp4")
                    val ext = if (mimeType.contains("mp4")) "mp4" else "webm"
                    videoCandidates.add(
                        Candidate(
                            height = height,
                            fps = fps,
                            url = directUrl,
                            ext = ext,
                            isMuxed = muxed,
                            isAvc = isAvc,
                            sizeText = sizeText
                        )
                    )
                }
            }
        }

        processArray(streamingData.optJSONArray("formats"), muxed = true)
        processArray(streamingData.optJSONArray("adaptiveFormats"), muxed = false)

        val byHeight = videoCandidates.groupBy { it.height }
        byHeight.keys.sortedDescending().forEach { height ->
            val group = byHeight[height].orEmpty()
            val best = group.maxByOrNull { c ->
                var s = 0
                if (c.isAvc) s += 50
                if (c.isMuxed) s += 30
                if ((c.fps ?: 30) >= 50) s += 10
                s
            } ?: return@forEach

            if (!best.isMuxed && bestAudioUrl == null) return@forEach

            val fpsSuffix = if ((best.fps ?: 0) >= 50) " ${best.fps}fps" else ""
            result.add(
                StreamQualityOption(
                    id = "it_${height}_${best.ext}_${best.isMuxed}",
                    label = "${height}p$fpsSuffix",
                    height = height,
                    fps = best.fps,
                    videoUrl = best.url,
                    audioUrl = if (best.isMuxed) null else bestAudioUrl,
                    isAudioOnly = false,
                    isMuxed = best.isMuxed,
                    ext = best.ext,
                    fileSizeText = best.sizeText,
                    userAgent = userAgent
                )
            )
        }

        if (bestAudioUrl != null) {
            result.add(
                StreamQualityOption(
                    id = "it_audio_only",
                    label = "Audio Saja (Hemat Kuota)",
                    height = 0,
                    fps = null,
                    videoUrl = null,
                    audioUrl = bestAudioUrl,
                    isAudioOnly = true,
                    isMuxed = true,
                    ext = bestAudioExt,
                    fileSizeText = bestAudioSize,
                    userAgent = userAgent
                )
            )
        }

        return result
    }

    private fun extractBestThumbnailFromDetails(
        details: JSONObject?,
        videoId: String,
        fallback: String
    ): String {
        val thumbs = details?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        if (thumbs != null && thumbs.length() > 0) {
            val last = thumbs.optJSONObject(thumbs.length() - 1)?.optString("url", "").orEmpty()
            if (last.startsWith("http")) return last
        }
        return fallback.ifBlank { "https://i.ytimg.com/vi/$videoId/hqdefault.jpg" }
    }

    private fun collectVideoRenderers(
        node: Any?,
        out: MutableList<VideoItem>,
        seenIds: MutableSet<String>,
        limit: Int
    ) {
        if (out.size >= limit || node == null) return
        when (node) {
            is JSONObject -> {
                val renderer = node.optJSONObject("videoRenderer")
                if (renderer != null) {
                    parseVideoRenderer(renderer)?.let { item ->
                        if (seenIds.add(item.id)) {
                            out.add(item)
                        }
                    }
                    return
                }
                val keys = node.keys()
                while (keys.hasNext() && out.size < limit) {
                    val key = keys.next()
                    collectVideoRenderers(node.opt(key), out, seenIds, limit)
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    if (out.size >= limit) break
                    collectVideoRenderers(node.opt(i), out, seenIds, limit)
                }
            }
        }
    }

    private fun parseVideoRenderer(obj: JSONObject): VideoItem? {
        val videoId = obj.optString("videoId", "")
        if (videoId.length != 11) return null

        val title = readText(obj.optJSONObject("title")).ifBlank { return null }
        val channel = readText(obj.optJSONObject("ownerText"))
            .ifBlank { readText(obj.optJSONObject("longBylineText")) }
            .ifBlank { "YouTube Channel" }

        val lengthText = readText(obj.optJSONObject("lengthText"))
        val isLive = lengthText.isBlank() && obj.toString().contains("LIVE")
        val viewText = readText(obj.optJSONObject("shortViewCountText"))
            .ifBlank { readText(obj.optJSONObject("viewCountText")) }
            .replace(" x ditonton", "", ignoreCase = true)
            .replace(" ditonton", "", ignoreCase = true)
            .replace(" views", "", ignoreCase = true)
            .trim()
        val publishedText = readText(obj.optJSONObject("publishedTimeText"))

        val thumbs = obj.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        var thumbUrl = ""
        if (thumbs != null && thumbs.length() > 0) {
            thumbUrl = thumbs.optJSONObject(thumbs.length() - 1)?.optString("url", "").orEmpty()
        }
        if (!thumbUrl.startsWith("http")) {
            thumbUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
        }

        return VideoItem(
            id = videoId,
            title = title,
            channelName = channel,
            thumbnailUrl = thumbUrl,
            durationText = if (isLive) "LIVE" else lengthText,
            viewCountText = viewText,
            uploadDateText = publishedText,
            webpageUrl = "https://www.youtube.com/watch?v=$videoId",
            isLive = isLive
        )
    }

    private fun readText(obj: JSONObject?): String {
        if (obj == null) return ""
        val simple = obj.optString("simpleText", "")
        if (simple.isNotBlank()) return simple
        val runs = obj.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            sb.append(runs.optJSONObject(i)?.optString("text", "").orEmpty())
        }
        return sb.toString()
    }

    private fun postJson(
        urlStr: String,
        body: String,
        userAgent: String,
        clientIdHeader: String,
        clientVersionHeader: String
    ): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 7_000
            readTimeout = 9_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("User-Agent", userAgent)
            setRequestProperty("X-YouTube-Client-Name", clientIdHeader)
            setRequestProperty("X-YouTube-Client-Version", clientVersionHeader)
            setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en-US;q=0.8")
        }
        return try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body)
                writer.flush()
            }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (conn.responseCode !in 200..299) {
                throw Exception("HTTP ${conn.responseCode}")
            }
            text
        } finally {
            conn.disconnect()
        }
    }
}
