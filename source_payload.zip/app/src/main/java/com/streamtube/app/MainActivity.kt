package com.streamtube.app

import android.Manifest
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.streamtube.app.data.VideoItem
import com.streamtube.app.ui.MainUiState
import com.streamtube.app.ui.MainViewModel
import com.streamtube.app.ui.NavTab
import com.streamtube.app.ui.components.ShimmerVideoPlaceholder
import com.streamtube.app.ui.components.VideoFeedCard
import com.streamtube.app.ui.components.bounceClick
import com.streamtube.app.ui.screens.DirectUrlDialog
import com.streamtube.app.ui.screens.DownloadPickerSheet
import com.streamtube.app.ui.screens.DownloadsScreen
import com.streamtube.app.ui.screens.FullPlayerOverlay
import com.streamtube.app.ui.screens.InfoScreen
import com.streamtube.app.ui.screens.MiniPlayerBar
import com.streamtube.app.ui.theme.DividerSoft
import com.streamtube.app.ui.theme.InkPrimary
import com.streamtube.app.ui.theme.InkSecondary
import com.streamtube.app.ui.theme.PureWhite
import com.streamtube.app.ui.theme.SoftSurface
import com.streamtube.app.ui.theme.StreamTubeTheme
import com.streamtube.app.ui.theme.TealBadge

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* izin diproses */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        handleIncomingIntent(intent)

        setContent {
            StreamTubeTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                StreamTubeRoot(
                    state = uiState,
                    viewModel = viewModel,
                    onEnterPip = { triggerPictureInPicture() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                viewModel.openDirectUrl(sharedText)
            }
        }
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    fun triggerPictureInPicture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            runCatching {
                viewModel.setPlayerExpanded(true)
                enterPictureInPictureMode(params)
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val state = viewModel.uiState.value
        if (state.activeStream != null && state.isPlayerExpanded && state.activeQuality?.isAudioOnly != true) {
            triggerPictureInPicture()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        viewModel.setPipMode(isInPictureInPictureMode)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StreamTubeRoot(
    state: MainUiState,
    viewModel: MainViewModel,
    onEnterPip: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val keyboard = LocalSoftwareKeyboardController.current

    var menuVideo by remember { mutableStateOf<VideoItem?>(null) }
    var downloadVideo by remember { mutableStateOf<VideoItem?>(null) }
    var showDirectUrlDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    BackHandler(enabled = state.isPlayerExpanded && !state.isInPipMode) {
        viewModel.setPlayerExpanded(false)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = PureWhite,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                if (!state.isInPipMode && (state.activeTab == NavTab.HOME || state.activeTab == NavTab.TRENDING)) {
                    ReferenceTopSearchBar(
                        query = state.searchQuery,
                        onQueryChange = viewModel::updateSearchQuery,
                        onSearch = {
                            keyboard?.hide()
                            viewModel.performSearch(state.searchQuery)
                        },
                        onClear = {
                            viewModel.updateSearchQuery("")
                        },
                        onBack = {
                            keyboard?.hide()
                            viewModel.updateSearchQuery("")
                            val firstCat = viewModel.categories.first()
                            viewModel.selectCategory(firstCat.first, firstCat.second)
                        },
                        onOpenDirectUrl = { showDirectUrlDialog = true },
                        onOpenInfo = { viewModel.selectTab(NavTab.INFO) }
                    )
                }
            },
            bottomBar = {
                if (!state.isInPipMode) {
                    Column {
                        AnimatedVisibility(
                            visible = state.activeStream != null && !state.isPlayerExpanded
                        ) {
                            state.activeStream?.let { active ->
                                MiniPlayerBar(
                                    stream = active,
                                    onExpand = { viewModel.setPlayerExpanded(true) },
                                    onClose = { viewModel.closePlayer() }
                                )
                            }
                        }
                        ReferenceBottomNavBar(
                            activeTab = state.activeTab,
                            onSelectTab = viewModel::selectTab,
                            onAddUrlClick = { showDirectUrlDialog = true }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = state.activeTab,
                    transitionSpec = {
                        fadeIn(tween(220)) togetherWith fadeOut(tween(180))
                    },
                    label = "tab_transition"
                ) { tab ->
                    when (tab) {
                        NavTab.HOME, NavTab.TRENDING -> {
                            FeedContent(
                                state = state,
                                categories = viewModel.categories,
                                onSelectCategory = viewModel::selectCategory,
                                onVideoClick = { viewModel.openAndPlayVideo(it) },
                                onVideoMoreClick = { menuVideo = it },
                                onRetry = {
                                    val q = state.searchQuery.ifBlank { viewModel.categories.first().second }
                                    viewModel.performSearch(q, updateInput = false)
                                }
                            )
                        }
                        NavTab.DOWNLOADS -> {
                            DownloadsScreen(
                                tasks = state.downloads,
                                files = state.downloadedFiles,
                                onCancelTask = viewModel::cancelDownload,
                                onPlayFile = viewModel::playLocalFile,
                                onDeleteFile = viewModel::deleteLocalFile,
                                onRefresh = viewModel::refreshDownloadedFiles
                            )
                        }
                        NavTab.INFO -> {
                            InfoScreen(
                                engineStatus = state.engineStatusText,
                                isUpdating = state.isUpdatingYtDlp,
                                onUpdateYtDlp = viewModel::updateYtDlp
                            )
                        }
                    }
                }
            }
        }

        // Full Player Overlay (dengan animasi mulus & dukungan PiP Floating)
        FullPlayerOverlay(
            visible = state.isPlayerExpanded || state.isInPipMode,
            isResolving = state.isResolvingStream,
            isInPipMode = state.isInPipMode,
            stream = state.activeStream,
            activeQuality = state.activeQuality,
            onMinimize = { viewModel.setPlayerExpanded(false) },
            onEnterPip = onEnterPip,
            onSwitchQuality = viewModel::switchQuality,
            onRequestDownload = { video, format ->
                viewModel.startDownload(video, format)
            }
        )
    }

    // Bottom Sheet Menu Cepat pada Video Card (tombol •••)
    menuVideo?.let { video ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { menuVideo = null },
            sheetState = sheetState,
            containerColor = PureWhite,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(
                    text = video.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 2,
                    color = InkPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))
                QuickSheetItem(Icons.Rounded.PlayArrow, "Putar Video") {
                    menuVideo = null
                    viewModel.openAndPlayVideo(video)
                }
                QuickSheetItem(Icons.Rounded.Headphones, "Putar di Latar Belakang (Audio)") {
                    menuVideo = null
                    viewModel.openAndPlayVideo(video, audioOnlyMode = true)
                }
                QuickSheetItem(Icons.Rounded.PictureInPictureAlt, "Putar Mode Floating (PiP)") {
                    menuVideo = null
                    viewModel.openAndPlayVideo(video)
                    onEnterPip()
                }
                QuickSheetItem(Icons.Rounded.Download, "Download Video / MP3") {
                    menuVideo = null
                    downloadVideo = video
                }
                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }

    // Bottom Sheet Format Download
    downloadVideo?.let { video ->
        DownloadPickerSheet(
            videoTitle = video.title,
            onSelectFormat = { fmt ->
                downloadVideo = null
                viewModel.startDownload(video, fmt)
            },
            onDismiss = { downloadVideo = null }
        )
    }

    // Dialog Tempel URL Langsung (tombol +)
    if (showDirectUrlDialog) {
        DirectUrlDialog(
            onDismiss = { showDirectUrlDialog = false },
            onPlayUrl = { url -> viewModel.openDirectUrl(url) }
        )
    }
}

@Composable
private fun ReferenceTopSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit,
    onOpenDirectUrl: () -> Unit,
    onOpenInfo: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Kembali",
                tint = InkPrimary
            )
        }

        // Pill-shaped Search Bar persis seperti referensi
        Row(
            modifier = Modifier
                .weight(1f)
                .height(42.dp)
                .clip(CircleShape)
                .background(SoftSurface)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (query.isEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = InkSecondary,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = "Cari di YouTube...",
                        color = InkSecondary,
                        fontSize = 15.sp
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = InkPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    cursorBrush = SolidColor(InkPrimary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (query.isNotEmpty()) {
                IconButton(
                    onClick = onClear,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Hapus",
                        tint = InkPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Tombol bundar abu lembut seperti tombol Mic di referensi (sekalian shortcut paste URL / cari)
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(SoftSurface)
                .bounceClick(onClick = {
                    if (query.isNotBlank()) onSearch() else onOpenDirectUrl()
                }),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (query.isNotBlank()) Icons.Rounded.Search else Icons.Rounded.Mic,
                contentDescription = "Cari / Tautan",
                tint = InkPrimary,
                modifier = Modifier.size(21.dp)
            )
        }

        IconButton(onClick = onOpenInfo, modifier = Modifier.size(36.dp)) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Pengaturan",
                tint = InkPrimary
            )
        }
    }
}

@Composable
private fun FeedContent(
    state: MainUiState,
    categories: List<Pair<String, String>>,
    onSelectCategory: (String, String) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onVideoMoreClick: (VideoItem) -> Unit,
    onRetry: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
    ) {
        // Chip Kategori horizontal lembut
        item(key = "categories_row") {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { (label, query) ->
                    val selected = state.selectedCategory == label && state.searchQuery.isBlank()
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) InkPrimary else SoftSurface,
                        modifier = Modifier.bounceClick { onSelectCategory(label, query) }
                    ) {
                        Text(
                            text = label,
                            color = if (selected) PureWhite else InkPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        when {
            state.isLoadingFeed -> {
                items(4) { ShimmerVideoPlaceholder() }
            }
            state.feedError != null -> {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = state.feedError,
                            color = InkSecondary,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onRetry,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = InkPrimary)
                        ) {
                            Text("Coba Lagi")
                        }
                    }
                }
            }
            else -> {
                items(state.feedVideos, key = { it.id }) { video ->
                    VideoFeedCard(
                        video = video,
                        onClick = { onVideoClick(video) },
                        onMoreClick = { onVideoMoreClick(video) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReferenceBottomNavBar(
    activeTab: NavTab,
    onSelectTab: (NavTab) -> Unit,
    onAddUrlClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(color = DividerSoft, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Beranda (Home)
            IconButton(onClick = { onSelectTab(NavTab.HOME) }) {
                Icon(
                    imageVector = Icons.Rounded.Home,
                    contentDescription = "Beranda",
                    tint = if (activeTab == NavTab.HOME) InkPrimary else InkSecondary,
                    modifier = Modifier.size(27.dp)
                )
            }

            // 2. Jelajah / Trending
            IconButton(onClick = { onSelectTab(NavTab.TRENDING) }) {
                Icon(
                    imageVector = Icons.Rounded.Whatshot,
                    contentDescription = "Trending",
                    tint = if (activeTab == NavTab.TRENDING) InkPrimary else InkSecondary,
                    modifier = Modifier.size(26.dp)
                )
            }

            // 3. Tombol + (Tempel URL YouTube) persis di tengah-kanan referensi
            IconButton(onClick = onAddUrlClick) {
                Icon(
                    imageVector = Icons.Rounded.AddCircleOutline,
                    contentDescription = "Buka Tautan",
                    tint = InkPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            // 4. Unduhan & Info (Avatar Teal bundar seperti referensi)
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (activeTab == NavTab.DOWNLOADS) InkPrimary else TealBadge)
                    .bounceClick { onSelectTab(NavTab.DOWNLOADS) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (activeTab == NavTab.DOWNLOADS) Icons.Rounded.Download else Icons.Rounded.Info,
                    contentDescription = "Unduhan",
                    tint = PureWhite,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickSheetItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = InkPrimary,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = InkPrimary
        )
    }
}
