package com.streamtube.app.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import java.io.File

object PlayerHolder {

    @Volatile
    private var exoPlayer: ExoPlayer? = null

    @OptIn(UnstableApi::class)
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        return exoPlayer ?: synchronized(this) {
            exoPlayer ?: run {
                // Buffer ringan & cepat mulai, hemat RAM untuk perangkat 32-bit
                val loadControl = DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        12_000, // minBufferMs
                        35_000, // maxBufferMs
                        1_500,  // bufferForPlaybackMs
                        3_000   // bufferForPlaybackAfterRebufferMs
                    )
                    .build()

                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(C.USAGE_MEDIA)
                    .build()

                ExoPlayer.Builder(context.applicationContext)
                    .setLoadControl(loadControl)
                    .setAudioAttributes(audioAttributes, true)
                    .setHandleAudioBecomingNoisy(true)
                    .build()
                    .also { exoPlayer = it }
            }
        }
    }

    @OptIn(UnstableApi::class)
    fun playStream(
        context: Context,
        video: VideoItem,
        quality: StreamQualityOption,
        startPositionMs: Long = 0L
    ) {
        startBackgroundService(context)
        val player = getOrCreatePlayer(context)

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val mediaMetadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelName)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val sourceFactory = DefaultMediaSourceFactory(httpFactory)

        when {
            quality.isAudioOnly && !quality.audioUrl.isNullOrBlank() -> {
                val item = MediaItem.Builder()
                    .setUri(quality.audioUrl)
                    .setMediaMetadata(mediaMetadata)
                    .build()
                player.setMediaSource(sourceFactory.createMediaSource(item))
            }
            quality.isMuxed && !quality.videoUrl.isNullOrBlank() -> {
                val item = MediaItem.Builder()
                    .setUri(quality.videoUrl)
                    .setMediaMetadata(mediaMetadata)
                    .build()
                player.setMediaSource(sourceFactory.createMediaSource(item))
            }
            !quality.videoUrl.isNullOrBlank() && !quality.audioUrl.isNullOrBlank() -> {
                val videoItem = MediaItem.Builder()
                    .setUri(quality.videoUrl)
                    .setMediaMetadata(mediaMetadata)
                    .build()
                val audioItem = MediaItem.Builder()
                    .setUri(quality.audioUrl)
                    .build()
                val videoSource = ProgressiveMediaSource.Factory(httpFactory).createMediaSource(videoItem)
                val audioSource = ProgressiveMediaSource.Factory(httpFactory).createMediaSource(audioItem)
                val merged = MergingMediaSource(videoSource, audioSource)
                player.setMediaSource(merged)
            }
            !quality.videoUrl.isNullOrBlank() -> {
                val item = MediaItem.Builder()
                    .setUri(quality.videoUrl)
                    .setMediaMetadata(mediaMetadata)
                    .build()
                player.setMediaSource(sourceFactory.createMediaSource(item))
            }
        }

        player.prepare()
        if (startPositionMs > 0L) {
            player.seekTo(startPositionMs)
        }
        player.playWhenReady = true
    }

    @OptIn(UnstableApi::class)
    fun playLocalFile(context: Context, file: File) {
        startBackgroundService(context)
        val player = getOrCreatePlayer(context)
        val dataSourceFactory = DefaultDataSource.Factory(context.applicationContext)
        val metadata = MediaMetadata.Builder()
            .setTitle(file.nameWithoutExtension)
            .setArtist("Unduhan Lokal")
            .build()
        val item = MediaItem.Builder()
            .setUri(Uri.fromFile(file))
            .setMediaMetadata(metadata)
            .build()
        val source = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(item)
        player.setMediaSource(source)
        player.prepare()
        player.playWhenReady = true
    }

    private fun startBackgroundService(context: Context) {
        val serviceIntent = Intent(context.applicationContext, PlaybackService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.applicationContext.startForegroundService(serviceIntent)
            } else {
                context.applicationContext.startService(serviceIntent)
            }
        }
    }

    fun release() {
        exoPlayer?.release()
        exoPlayer = null
    }
}
