package com.streamtube.app.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import com.streamtube.app.engine.NewPipeResolver
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import java.io.File

object PlayerHolder {

    @Volatile
    private var exoPlayer: ExoPlayer? = null

    @Volatile
    private var sessionConnected = false

    @Volatile
    var onErrorCallback: ((String) -> Unit)? = null

    @OptIn(UnstableApi::class)
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        return exoPlayer ?: synchronized(this) {
            exoPlayer ?: run {
                val loadControl = DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        10_000, // minBufferMs
                        30_000, // maxBufferMs
                        800,    // bufferForPlaybackMs (instan)
                        2_000   // bufferForPlaybackAfterRebufferMs
                    )
                    .build()

                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(C.USAGE_MEDIA)
                    .build()

                ExoPlayer.Builder(context.applicationContext)
                    .setLoadControl(loadControl)
                    .setAudioAttributes(audioAttributes, true)
                    .setHandleAudioBecomingNoisy(true)
                    .setWakeMode(C.WAKE_MODE_NETWORK)
                    .build()
                    .also { player ->
                        player.addListener(object : Player.Listener {
                            override fun onPlayerError(error: PlaybackException) {
                                onErrorCallback?.invoke(error.errorCodeName)
                            }
                        })
                        exoPlayer = player
                    }
            }
        }
    }

    // Hubungkan ke PlaybackService secara aman via MediaController (anti ForegroundServiceDidNotStartInTimeException!)
    fun ensureMediaSessionConnected(context: Context) {
        if (sessionConnected) return
        runCatching {
            val appCtx = context.applicationContext
            val token = SessionToken(appCtx, ComponentName(appCtx, PlaybackService::class.java))
            val future = MediaController.Builder(appCtx, token).buildAsync()
            future.addListener(
                {
                    runCatching {
                        future.get()
                        sessionConnected = true
                    }
                },
                MoreExecutors.directExecutor()
            )
        }
    }

    @OptIn(UnstableApi::class)
    fun playStream(
        context: Context,
        video: VideoItem,
        quality: StreamQualityOption,
        startPositionMs: Long = 0L
    ): Boolean {
        return runCatching {
            val player = getOrCreatePlayer(context)
            ensureMediaSessionConnected(context)

            val ua = quality.httpHeaders["User-Agent"]
                ?: quality.userAgent.ifBlank { NewPipeResolver.USER_AGENT }

            val httpFactory = OkHttpDataSource.Factory(NewPipeResolver.sharedOkHttpClient)
                .setUserAgent(ua)
                .apply {
                    if (quality.httpHeaders.isNotEmpty()) {
                        setDefaultRequestProperties(quality.httpHeaders)
                    }
                }

            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(video.title)
                .setArtist(video.channelName)
            if (video.thumbnailUrl.startsWith("http")) {
                metadataBuilder.setArtworkUri(Uri.parse(video.thumbnailUrl))
            }
            val mediaMetadata = metadataBuilder.build()

            when {
                quality.ext == "hls" && !quality.videoUrl.isNullOrBlank() -> {
                    val item = MediaItem.Builder()
                        .setUri(quality.videoUrl)
                        .setMimeType(MimeTypes.APPLICATION_M3U8)
                        .setMediaMetadata(mediaMetadata)
                        .build()
                    val hlsSource = HlsMediaSource.Factory(httpFactory).createMediaSource(item)
                    player.setMediaSource(hlsSource)
                }
                quality.isAudioOnly && !quality.audioUrl.isNullOrBlank() -> {
                    val item = MediaItem.Builder()
                        .setUri(quality.audioUrl)
                        .setMediaMetadata(mediaMetadata)
                        .build()
                    player.setMediaSource(ProgressiveMediaSource.Factory(httpFactory).createMediaSource(item))
                }
                quality.isMuxed && !quality.videoUrl.isNullOrBlank() -> {
                    val item = MediaItem.Builder()
                        .setUri(quality.videoUrl)
                        .setMediaMetadata(mediaMetadata)
                        .build()
                    player.setMediaSource(ProgressiveMediaSource.Factory(httpFactory).createMediaSource(item))
                }
                !quality.videoUrl.isNullOrBlank() && !quality.audioUrl.isNullOrBlank() -> {
                    val videoItem = MediaItem.Builder()
                        .setUri(quality.videoUrl)
                        .setMediaMetadata(mediaMetadata)
                        .build()
                    val audioItem = MediaItem.Builder()
                        .setUri(quality.audioUrl)
                        .build()
                    val videoSource = ProgressiveMediaSource.Factory(httpFactory).createMediaSource(videoItem)
                    val audioSource = ProgressiveMediaSource.Factory(httpFactory).createMediaSource(audioItem)
                    player.setMediaSource(MergingMediaSource(videoSource, audioSource))
                }
                !quality.videoUrl.isNullOrBlank() -> {
                    val item = MediaItem.Builder()
                        .setUri(quality.videoUrl)
                        .setMediaMetadata(mediaMetadata)
                        .build()
                    player.setMediaSource(DefaultMediaSourceFactory(httpFactory).createMediaSource(item))
                }
                else -> return false
            }

            player.prepare()
            if (startPositionMs > 0L) {
                player.seekTo(startPositionMs)
            }
            player.playWhenReady = true
            true
        }.getOrElse {
            onErrorCallback?.invoke(it.localizedMessage ?: "Gagal memulai pemutar")
            false
        }
    }

    @OptIn(UnstableApi::class)
    fun playLocalFile(context: Context, file: File) {
        runCatching {
            val player = getOrCreatePlayer(context)
            ensureMediaSessionConnected(context)
            val dataSourceFactory = DefaultDataSource.Factory(context.applicationContext)
            val metadata = MediaMetadata.Builder()
                .setTitle(file.nameWithoutExtension)
                .setArtist("Unduhan Lokal")
                .build()
            val item = MediaItem.Builder()
                .setUri(Uri.fromFile(file))
                .setMediaMetadata(metadata)
                .build()
            val source = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(item)
            player.setMediaSource(source)
            player.prepare()
            player.playWhenReady = true
        }
    }

    fun release() {
        runCatching { exoPlayer?.release() }
        exoPlayer = null
        sessionConnected = false
    }
}
