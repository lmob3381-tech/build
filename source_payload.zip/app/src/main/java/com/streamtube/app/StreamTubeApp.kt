package com.streamtube.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.graphics.Bitmap
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

class StreamTubeApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK,
                "Pemutar Latar Belakang",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kontrol pemutaran video dan audio di latar belakang"
                setShowBadge(false)
            }
            val downloadChannel = NotificationChannel(
                CHANNEL_DOWNLOAD,
                "Unduhan Video & Audio",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status progres unduhan yt-dlp dan FFmpeg"
                setShowBadge(false)
            }
            manager.createNotificationChannel(playbackChannel)
            manager.createNotificationChannel(downloadChannel)
        }
    }

    // Ultra-optimize untuk 32-bit: RGB_565 hemat RAM 50% & decode 2x lebih cepat saat scroll
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .allowHardware(true)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("coil_thumb_cache"))
                    .maxSizeBytes(50L * 1024L * 1024L)
                    .build()
            }
            .crossfade(120)
            .respectCacheHeaders(false)
            .build()
    }

    companion object {
        const val CHANNEL_PLAYBACK = "streamtube_playback"
        const val CHANNEL_DOWNLOAD = "streamtube_download"
    }
}
