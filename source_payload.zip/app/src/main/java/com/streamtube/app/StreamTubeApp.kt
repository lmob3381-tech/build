package com.streamtube.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

class StreamTubeApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK,
                "Pemutar Latar Belakang",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kontrol pemutaran video dan audio di latar belakang"
                setShowBadge(false)
            }
            val downloadChannel = NotificationChannel(
                CHANNEL_DOWNLOAD,
                "Unduhan Video & Audio",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status progres unduhan yt-dlp dan FFmpeg"
                setShowBadge(false)
            }
            manager.createNotificationChannel(playbackChannel)
            manager.createNotificationChannel(downloadChannel)
        }
    }

    // Optimasi cache gambar agar perangkat 32-bit dengan RAM 2GB-3GB tetap mulus & bebas OOM
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.18)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("coil_thumb_cache"))
                    .maxSizeBytes(40L * 1024L * 1024L)
                    .build()
            }
            .crossfade(220)
            .respectCacheHeaders(false)
            .build()
    }

    companion object {
        const val CHANNEL_PLAYBACK = "streamtube_playback"
        const val CHANNEL_DOWNLOAD = "streamtube_download"
    }
}
