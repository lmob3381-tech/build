package com.streamtube.app.ui.screens

import android.view.LayoutInflater
import android.view.ViewGroup
import com.streamtube.app.R
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.streamtube.app.data.DownloadFormat
import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import com.streamtube.app.player.PlayerHolder
import com.streamtube.app.ui.components.ChannelAvatar
import com.streamtube.app.ui.components.bounceClick
import com.streamtube.app.ui.theme.BrandAccent
import com.streamtube.app.ui.theme.DividerSoft
import com.streamtube.app.ui.theme.InkPrimary
import com.streamtube.app.ui.theme.InkSecondary
import com.streamtube.app.ui.theme.PureWhite
import com.streamtube.app.ui.theme.SoftSurface

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun FullPlayerOverlay(
    visible: Boolean,
    isResolving: Boolean,
    isInPipMode: Boolean,
    stream: ResolvedStream?,
    activeQuality: StreamQualityOption?,
    onMinimize: () -> Unit,
    onEnterPip: () -> Unit,
    onSwitchQuality: (StreamQualityOption) -> Unit,
    onRequestDownload: (VideoItem, DownloadFormat) -> Unit
) {
    val context = LocalContext.current
    val player = remember { PlayerHolder.getOrCreatePlayer(context) }

    var showQualitySheet by remember { mutableStateOf(false) }
    var showDownloadSheet by remember { mutableStateOf(false) }

    val smoothOutEasing = remember { CubicBezierEasing(0.22f, 1f, 0.36f, 1f) }
    var mountPlayerView by remember { mutableStateOf(false) }

    LaunchedEffect(visible) {
        if (visible) {
            delay(200)
            mountPlayerView = true
        } else {
            mountPlayerView = false
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            animationSpec = tween(durationMillis = 300, easing = smoothOutEasing),
            initialOffsetY = { it }
        ) + fadeIn(animationSpec = tween(durationMillis = 220)),
        exit = slideOutVertically(
            animationSpec = tween(durationMillis = 240, easing = smoothOutEasing),
            targetOffsetY = { it }
        ) + fadeOut(animationSpec = tween(durationMillis = 180))
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (isInPipMode) Color.Black else PureWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (!isInPipMode) Modifier.statusBarsPadding() else Modifier)
            ) {
                // Area Video 16:9 (penuh layar jika mode PiP)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (isInPipMode) Modifier.fillMaxSize()
                            else Modifier.aspectRatio(16f / 9f)
                        )
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (activeQuality?.isAudioOnly == true && stream != null) {
                        AsyncImage(
                            model = stream.videoItem.thumbnailUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.55f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.Headphones,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Mode Audio Latar Belakang",
                                    color = PureWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    } else if (!mountPlayerView) {
                        if (stream != null && stream.videoItem.thumbnailUrl.isNotBlank()) {
                            AsyncImage(
                                model = stream.videoItem.thumbnailUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        AndroidView(
                            factory = { ctx ->
                                (LayoutInflater.from(ctx).inflate(
                                    R.layout.view_player_texture,
                                    null,
                                    false
                                ) as PlayerView).apply {
                                    this.player = player
                                    useController = !isInPipMode
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    layoutParams = FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { view ->
                                if (view.player !== player) view.player = player
                                view.useController = !isInPipMode
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    if (isResolving) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.6f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = PureWhite, strokeWidth = 3.dp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Memuat video...",
                                    color = PureWhite,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    if (!isInPipMode) {
                        // Tombol minimize & PiP di pojok atas video
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onMinimize,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.45f))
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.KeyboardArrowDown,
                                    contentDescription = "Perkecil ke Mini Player",
                                    tint = PureWhite
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (activeQuality != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(Color.Black.copy(alpha = 0.55f))
                                            .clickable { showQualitySheet = true }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = activeQuality.label,
                                            color = PureWhite,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = onEnterPip,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.45f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PictureInPictureAlt,
                                        contentDescription = "Mode Floating PiP",
                                        tint = PureWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Detail Video & Tombol Aksi (disembunyikan saat mode Floating PiP)
                if (!isInPipMode && stream != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text(
                            text = stream.videoItem.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = InkPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = listOf(
                                stream.videoItem.viewCountText.takeIf { it.isNotBlank() }?.let { "$it ditonton" },
                                stream.videoItem.uploadDateText.takeIf { it.isNotBlank() },
                                activeQuality?.label?.let { "Kualitas: $it" }
                            ).filterNotNull().joinToString("  •  "),
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkSecondary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ChannelAvatar(name = stream.videoItem.channelName)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stream.videoItem.channelName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkPrimary
                                )
                                Text(
                                    text = "YouTube Stream via yt-dlp",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = InkSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Pill Action Buttons (Resolusi, Floating PiP, Audio BG, Download)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(end = 8.dp)
                        ) {
                            item {
                                PlayerActionPill(
                                    icon = Icons.Rounded.HighQuality,
                                    label = activeQuality?.label ?: "Resolusi",
                                    onClick = { showQualitySheet = true }
                                )
                            }
                            item {
                                PlayerActionPill(
                                    icon = Icons.Rounded.PictureInPictureAlt,
                                    label = "Floating",
                                    onClick = onEnterPip
                                )
                            }
                            item {
                                PlayerActionPill(
                                    icon = Icons.Rounded.Headphones,
                                    label = "Latar Belakang",
                                    onClick = {
                                        val audioOpt = stream.qualities.firstOrNull { it.isAudioOnly }
                                        if (audioOpt != null) onSwitchQuality(audioOpt)
                                        onMinimize()
                                    }
                                )
                            }
                            item {
                                PlayerActionPill(
                                    icon = Icons.Rounded.Download,
                                    label = "Download",
                                    onClick = { showDownloadSheet = true }
                                )
                            }
                        }

                        if (stream.description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(18.dp))
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = SoftSurface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Deskripsi",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.5.sp,
                                        color = InkPrimary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = stream.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = InkSecondary,
                                        maxLines = 12,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Bottom Sheet Pilih Resolusi
    if (showQualitySheet && stream != null) {
        QualityPickerSheet(
            qualities = stream.qualities,
            selectedId = activeQuality?.id,
            onSelect = { opt ->
                showQualitySheet = false
                onSwitchQuality(opt)
            },
            onDismiss = { showQualitySheet = false }
        )
    }

    // Bottom Sheet Pilih Format Download
    if (showDownloadSheet && stream != null) {
        DownloadPickerSheet(
            videoTitle = stream.videoItem.title,
            onSelectFormat = { fmt ->
                showDownloadSheet = false
                onRequestDownload(stream.videoItem, fmt)
            },
            onDismiss = { showDownloadSheet = false }
        )
    }
}

@Composable
private fun PlayerActionPill(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = SoftSurface,
        modifier = Modifier.bounceClick(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = InkPrimary,
                modifier = Modifier.size(19.dp)
            )
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = InkPrimary
            )
        }
    }
}

@Composable
fun MiniPlayerBar(
    stream: ResolvedStream,
    onExpand: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val player = remember { PlayerHolder.getOrCreatePlayer(context) }
    var isPlaying by remember { mutableStateOf(player.isPlaying) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onExpand),
        color = PureWhite,
        shadowElevation = 6.dp
    ) {
        Column {
            HorizontalDivider(color = DividerSoft, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = stream.videoItem.thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(72.dp)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SoftSurface)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stream.videoItem.title,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = InkPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = stream.videoItem.channelName,
                        fontSize = 12.sp,
                        color = InkSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = {
                    if (player.isPlaying) player.pause() else player.play()
                }) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Jeda" else "Putar",
                        tint = InkPrimary
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Tutup Pemutar",
                        tint = InkSecondary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QualityPickerSheet(
    qualities: List<StreamQualityOption>,
    selectedId: String?,
    onSelect: (StreamQualityOption) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                text = "Pilih Resolusi Video",
                style = MaterialTheme.typography.titleLarge,
                color = InkPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
            qualities.forEach { opt ->
                val isSelected = opt.id == selectedId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) SoftSurface else Color.Transparent)
                        .clickable { onSelect(opt) }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = opt.label,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 15.sp,
                            color = InkPrimary
                        )
                        val detail = listOf(
                            opt.ext.uppercase(),
                            opt.fileSizeText.takeIf { it.isNotBlank() },
                            if (opt.isMuxed) "Stream Langsung" else "DASH HD (Video+Audio)"
                        ).filterNotNull().joinToString(" • ")
                        Text(
                            text = detail,
                            fontSize = 12.sp,
                            color = InkSecondary
                        )
                    }
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Aktif",
                            tint = BrandAccent
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadPickerSheet(
    videoTitle: String,
    onSelectFormat: (DownloadFormat) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                text = "Unduh via yt-dlp + FFmpeg",
                style = MaterialTheme.typography.titleLarge,
                color = InkPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = videoTitle,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(14.dp))
            DownloadFormat.entries.forEach { fmt ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onSelectFormat(fmt) }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (fmt.isAudio) Icons.Rounded.Headphones else Icons.Rounded.Download,
                        contentDescription = null,
                        tint = InkPrimary
                    )
                    Text(
                        text = fmt.label,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = InkPrimary
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
