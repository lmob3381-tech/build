package com.streamtube.app.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamtube.app.data.DownloadFormat
import com.streamtube.app.data.DownloadStatus
import com.streamtube.app.data.DownloadTask
import com.streamtube.app.data.DownloadedFile
import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import com.streamtube.app.engine.YtDlpEngine
import com.streamtube.app.player.PlayerHolder
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class NavTab {
    HOME,
    TRENDING,
    DOWNLOADS,
    INFO
}

@Immutable
data class MainUiState(
    val engineReady: Boolean = true,
    val engineStatusText: String = "Mode Cepat (InnerTube) aktif • yt-dlp & FFmpeg siap saat unduh",
    val activeTab: NavTab = NavTab.HOME,
    val searchQuery: String = "",
    val selectedCategory: String = "Semua",
    val isLoadingFeed: Boolean = true,
    val feedVideos: List<VideoItem> = emptyList(),
    val feedError: String? = null,
    val isResolvingStream: Boolean = false,
    val activeStream: ResolvedStream? = null,
    val activeQuality: StreamQualityOption? = null,
    val isPlayerExpanded: Boolean = false,
    val isInPipMode: Boolean = false,
    val downloads: List<DownloadTask> = emptyList(),
    val downloadedFiles: List<DownloadedFile> = emptyList(),
    val snackbarMessage: String? = null,
    val isUpdatingYtDlp: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = YtDlpEngine(application.applicationContext)
    private val prefs = application.getSharedPreferences("streamtube_cache", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null
    private var resolveJob: Job? = null
    private var fallbackAttempts = 0
    private var triedYtDlpFallback = false

    val categories = listOf(
        "Semua" to "trending indonesia hari ini",
        "Gaming" to "roblox gaming indonesia terbaru",
        "Musik" to "musik hits indonesia terbaru",
        "Teknologi" to "review gadget teknologi indonesia",
        "Berita" to "berita terkini indonesia",
        "Film" to "trailer film terbaru 2026"
    )

    init {
        // Pasang auto-fallback jika 1 stream URL gagal diputar ExoPlayer
        PlayerHolder.onErrorCallback = { code ->
            handlePlaybackError(code)
        }
        startupInstant()
    }

    private fun startupInstant() {
        // 1. Langsung tampilkan feed cache terakhir (0.1 detik, nol layar polosan!)
        val cached = loadCachedFeed()
        if (cached.isNotEmpty()) {
            _uiState.update {
                it.copy(
                    isLoadingFeed = false,
                    feedVideos = cached
                )
            }
        }
        // 2. Refresh feed terbaru lewat Native Kotlin InnerTube (tanpa booting Python/yt-dlp!)
        performSearch(categories.first().second, updateInput = false, silentIfHasData = cached.isNotEmpty())
        refreshDownloadedFiles()
    }

    private fun handlePlaybackError(errorCode: String) {
        viewModelScope.launch {
            val stream = _uiState.value.activeStream ?: return@launch
            val current = _uiState.value.activeQuality ?: return@launch

            // Maksimal 2x ganti kualitas di sumber yang sama (anti loop tak terbatas!)
            if (fallbackAttempts < 2) {
                val preferred = stream.qualities
                    .filter { it.id != current.id }
                    .sortedByDescending { (if (it.ext == "hls") 100 else 0) + (if (it.isMuxed) 50 else 0) }
                val next = preferred.getOrNull(fallbackAttempts)
                if (next != null) {
                    fallbackAttempts++
                    PlayerHolder.playStream(getApplication(), stream.videoItem, next, 0L)
                    _uiState.update {
                        it.copy(
                            activeQuality = next,
                            snackbarMessage = "Mencoba kualitas ${next.label}..."
                        )
                    }
                    return@launch
                }
            }

            // Jika InnerTube gagal, coba 1x otomatis via yt-dlp solver
            if (!triedYtDlpFallback && stream.videoItem.webpageUrl.startsWith("http")) {
                triedYtDlpFallback = true
                _uiState.update {
                    it.copy(
                        isResolvingStream = true,
                        snackbarMessage = "Mengambil stream cadangan via yt-dlp..."
                    )
                }
                val ytResult = engine.resolveStream(stream.videoItem, forceYtDlp = true)
                ytResult.onSuccess { fresh ->
                    val chosen = fresh.qualities.firstOrNull { it.ext == "hls" }
                        ?: fresh.qualities.firstOrNull { !it.isAudioOnly && it.isMuxed }
                        ?: fresh.defaultQuality
                    PlayerHolder.playStream(getApplication(), fresh.videoItem, chosen, 0L)
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            activeStream = fresh,
                            activeQuality = chosen
                        )
                    }
                }.onFailure {
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            snackbarMessage = "Video gagal diputar ($errorCode). Ketuk Resolusi atau coba lagi."
                        )
                    }
                }
                return@launch
            }

            _uiState.update {
                it.copy(
                    isResolvingStream = false,
                    snackbarMessage = "Gagal memutar video ($errorCode). Coba pilih resolusi lain."
                )
            }
        }
    }

    fun selectTab(tab: NavTab) {
        _uiState.update { it.copy(activeTab = tab) }
        if (tab == NavTab.TRENDING) {
            performSearch("youtube trending indonesia 2026", updateInput = false)
        } else if (tab == NavTab.DOWNLOADS) {
            refreshDownloadedFiles()
        }
    }

    fun updateSearchQuery(newQuery: String) {
        _uiState.update { it.copy(searchQuery = newQuery) }
    }

    fun selectCategory(label: String, query: String) {
        _uiState.update { it.copy(selectedCategory = label, searchQuery = "") }
        performSearch(query, updateInput = false)
    }

    fun performSearch(
        query: String,
        updateInput: Boolean = true,
        silentIfHasData: Boolean = false
    ) {
        val clean = query.trim()
        if (clean.isEmpty()) return
        if (updateInput) {
            _uiState.update { it.copy(searchQuery = clean, activeTab = NavTab.HOME) }
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            if (!silentIfHasData) {
                _uiState.update { it.copy(isLoadingFeed = true, feedError = null) }
            }
            val result = engine.searchYouTube(clean, limit = 18)
            result.onSuccess { list ->
                if (list.isNotEmpty() && !updateInput) {
                    saveCachedFeed(list)
                }
                _uiState.update {
                    it.copy(
                        isLoadingFeed = false,
                        feedVideos = if (list.isNotEmpty()) list else it.feedVideos,
                        feedError = if (list.isEmpty() && it.feedVideos.isEmpty()) {
                            "Tidak ada video ditemukan untuk '$clean'"
                        } else null
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isLoadingFeed = false,
                        feedError = if (it.feedVideos.isEmpty()) {
                            "Gagal memuat video: ${err.localizedMessage ?: "Periksa koneksi internet"}"
                        } else null
                    )
                }
            }
        }
    }

    fun openAndPlayVideo(video: VideoItem, audioOnlyMode: Boolean = false) {
        resolveJob?.cancel()
        fallbackAttempts = 0
        triedYtDlpFallback = false
        resolveJob = viewModelScope.launch {
            val previewQuality = StreamQualityOption(
                id = "loading",
                label = "Memuat...",
                height = 720,
                fps = null,
                videoUrl = null,
                audioUrl = null,
                isMuxed = true
            )
            _uiState.update {
                it.copy(
                    isResolvingStream = true,
                    isPlayerExpanded = true,
                    activeStream = ResolvedStream(
                        videoItem = video,
                        description = "",
                        qualities = emptyList(),
                        defaultQuality = previewQuality
                    ),
                    activeQuality = previewQuality,
                    snackbarMessage = null
                )
            }
            val result = engine.resolveStream(video)
            result.onSuccess { resolved ->
                val chosen = if (audioOnlyMode) {
                    resolved.qualities.firstOrNull { it.isAudioOnly } ?: resolved.defaultQuality
                } else {
                    resolved.defaultQuality
                }
                PlayerHolder.playStream(getApplication(), resolved.videoItem, chosen, 0L)
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        activeStream = resolved,
                        activeQuality = chosen,
                        isPlayerExpanded = true
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        snackbarMessage = "Gagal memutar video: ${err.localizedMessage ?: "Error"}"
                    )
                }
            }
        }
    }

    fun openDirectUrl(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) return
        val stub = VideoItem(
            id = "direct",
            title = "Memuat video dari tautan...",
            channelName = "YouTube",
            thumbnailUrl = "",
            durationText = "",
            viewCountText = "",
            uploadDateText = "",
            webpageUrl = clean
        )
        openAndPlayVideo(stub)
    }

    fun switchQuality(quality: StreamQualityOption) {
        val stream = _uiState.value.activeStream ?: return
        val player = PlayerHolder.getOrCreatePlayer(getApplication())
        val currentPos = player.currentPosition.coerceAtLeast(0L)
        fallbackAttempts = 0
        triedYtDlpFallback = false
        PlayerHolder.playStream(getApplication(), stream.videoItem, quality, currentPos)
        _uiState.update {
            it.copy(
                activeQuality = quality,
                snackbarMessage = "Resolusi diubah ke ${quality.label}"
            )
        }
    }

    fun setPlayerExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isPlayerExpanded = expanded) }
    }

    fun setPipMode(inPip: Boolean) {
        _uiState.update { it.copy(isInPipMode = inPip) }
    }

    fun closePlayer() {
        runCatching {
            val player = PlayerHolder.getOrCreatePlayer(getApplication())
            player.stop()
            player.clearMediaItems()
        }
        _uiState.update {
            it.copy(
                activeStream = null,
                activeQuality = null,
                isPlayerExpanded = false
            )
        }
    }

    fun startDownload(video: VideoItem, format: DownloadFormat) {
        val processId = "dl_${UUID.randomUUID().toString().take(8)}"
        val newTask = DownloadTask(
            processId = processId,
            title = video.title,
            thumbnailUrl = video.thumbnailUrl,
            formatLabel = format.label,
            status = DownloadStatus.DOWNLOADING
        )
        _uiState.update {
            it.copy(
                downloads = listOf(newTask) + it.downloads,
                snackbarMessage = "Menyiapkan yt-dlp & mulai unduh (${format.label})..."
            )
        }

        viewModelScope.launch {
            val result = engine.downloadMedia(
                url = video.webpageUrl,
                format = format,
                processId = processId
            ) { progress, eta ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId && task.status == DownloadStatus.DOWNLOADING) {
                                task.copy(progress = progress, etaSeconds = eta)
                            } else task
                        }
                    )
                }
            }

            result.onSuccess { file ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId) {
                                task.copy(
                                    progress = 100f,
                                    status = DownloadStatus.COMPLETED,
                                    outputPath = file.absolutePath
                                )
                            } else task
                        },
                        snackbarMessage = "Unduhan selesai: ${file.name}"
                    )
                }
                refreshDownloadedFiles()
            }.onFailure { err ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId && task.status != DownloadStatus.CANCELLED) {
                                task.copy(
                                    status = DownloadStatus.FAILED,
                                    errorMessage = err.localizedMessage ?: "Unduhan gagal"
                                )
                            } else task
                        },
                        snackbarMessage = "Unduhan gagal: ${err.localizedMessage ?: "Error"}"
                    )
                }
            }
        }
    }

    fun cancelDownload(processId: String) {
        engine.cancelDownload(processId)
        _uiState.update { state ->
            state.copy(
                downloads = state.downloads.map { task ->
                    if (task.processId == processId) {
                        task.copy(status = DownloadStatus.CANCELLED)
                    } else task
                },
                snackbarMessage = "Unduhan dibatalkan"
            )
        }
    }

    fun refreshDownloadedFiles() {
        val files = engine.listDownloadedFiles()
        _uiState.update { it.copy(downloadedFiles = files) }
    }

    fun playLocalFile(downloaded: DownloadedFile) {
        val file = File(downloaded.path)
        if (!file.exists()) {
            _uiState.update { it.copy(snackbarMessage = "File tidak ditemukan") }
            refreshDownloadedFiles()
            return
        }
        PlayerHolder.playLocalFile(getApplication(), file)
        val localItem = VideoItem(
            id = downloaded.name,
            title = file.nameWithoutExtension,
            channelName = "Unduhan Lokal (Offline)",
            thumbnailUrl = "",
            durationText = "",
            viewCountText = YtDlpEngine.formatBytes(downloaded.sizeBytes),
            uploadDateText = "Offline",
            webpageUrl = downloaded.path
        )
        val localQuality = StreamQualityOption(
            id = "local",
            label = if (downloaded.isAudio) "Audio Lokal" else "Video Lokal",
            height = 720,
            fps = null,
            videoUrl = downloaded.path,
            audioUrl = null,
            isAudioOnly = downloaded.isAudio,
            isMuxed = true
        )
        _uiState.update {
            it.copy(
                activeStream = ResolvedStream(
                    videoItem = localItem,
                    description = "Diputar langsung dari penyimpanan: ${downloaded.path}",
                    qualities = listOf(localQuality),
                    defaultQuality = localQuality
                ),
                activeQuality = localQuality,
                isPlayerExpanded = true
            )
        }
    }

    fun deleteLocalFile(downloaded: DownloadedFile) {
        if (engine.deleteDownloadedFile(downloaded.path)) {
            refreshDownloadedFiles()
            _uiState.update { it.copy(snackbarMessage = "File dihapus") }
        }
    }

    fun updateYtDlp() {
        if (_uiState.value.isUpdatingYtDlp) return
        viewModelScope.launch {
            _uiState.update { it.copy(isUpdatingYtDlp = true, snackbarMessage = "Memeriksa pembaruan yt-dlp...") }
            val result = engine.updateBinary()
            _uiState.update {
                it.copy(
                    isUpdatingYtDlp = false,
                    snackbarMessage = result.getOrElse { err -> "Gagal memperbarui: ${err.localizedMessage}" }
                )
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun saveCachedFeed(videos: List<VideoItem>) {
        runCatching {
            val arr = JSONArray()
            videos.take(15).forEach { v ->
                arr.put(
                    JSONObject().apply {
                        put("id", v.id)
                        put("title", v.title)
                        put("channelName", v.channelName)
                        put("thumbnailUrl", v.thumbnailUrl)
                        put("durationText", v.durationText)
                        put("viewCountText", v.viewCountText)
                        put("uploadDateText", v.uploadDateText)
                        put("webpageUrl", v.webpageUrl)
                        put("isLive", v.isLive)
                    }
                )
            }
            prefs.edit().putString("home_feed_json", arr.toString()).apply()
        }
    }

    private fun loadCachedFeed(): List<VideoItem> {
        return runCatching {
            val raw = prefs.getString("home_feed_json", null) ?: return emptyList()
            val arr = JSONArray(raw)
            val list = mutableListOf<VideoItem>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    VideoItem(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        channelName = o.optString("channelName"),
                        thumbnailUrl = o.optString("thumbnailUrl"),
                        durationText = o.optString("durationText"),
                        viewCountText = o.optString("viewCountText"),
                        uploadDateText = o.optString("uploadDateText"),
                        webpageUrl = o.optString("webpageUrl"),
                        isLive = o.optBoolean("isLive", false)
                    )
                )
            }
            list
        }.getOrDefault(emptyList())
    }
}
