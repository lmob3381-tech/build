package com.streamtube.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamtube.app.data.DownloadFormat
import com.streamtube.app.data.DownloadStatus
import com.streamtube.app.data.DownloadTask
import com.streamtube.app.data.DownloadedFile
import com.streamtube.app.data.ResolvedStream
import com.streamtube.app.data.StreamQualityOption
import com.streamtube.app.data.VideoItem
import com.streamtube.app.engine.YtDlpEngine
import com.streamtube.app.player.PlayerHolder
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class NavTab {
    HOME,
    TRENDING,
    DOWNLOADS,
    INFO
}

data class MainUiState(
    val engineReady: Boolean = false,
    val engineStatusText: String = "Menyiapkan mesin yt-dlp & FFmpeg...",
    val activeTab: NavTab = NavTab.HOME,
    val searchQuery: String = "",
    val selectedCategory: String = "Semua",
    val isLoadingFeed: Boolean = true,
    val feedVideos: List<VideoItem> = emptyList(),
    val feedError: String? = null,
    val isResolvingStream: Boolean = false,
    val activeStream: ResolvedStream? = null,
    val activeQuality: StreamQualityOption? = null,
    val isPlayerExpanded: Boolean = false,
    val isInPipMode: Boolean = false,
    val downloads: List<DownloadTask> = emptyList(),
    val downloadedFiles: List<DownloadedFile> = emptyList(),
    val snackbarMessage: String? = null,
    val isUpdatingYtDlp: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = YtDlpEngine(application.applicationContext)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null
    private var resolveJob: Job? = null

    val categories = listOf(
        "Semua" to "trending indonesia hari ini",
        "Gaming" to "roblox gaming indonesia terbaru",
        "Musik" to "musik hits indonesia terbaru",
        "Teknologi" to "review gadget teknologi indonesia",
        "Berita" to "berita terkini indonesia",
        "Film" to "trailer film terbaru 2026"
    )

    init {
        initializeEngine()
    }

    private fun initializeEngine() {
        viewModelScope.launch {
            val result = engine.ensureInitialized()
            result.onSuccess {
                _uiState.update {
                    it.copy(
                        engineReady = true,
                        engineStatusText = "yt-dlp + FFmpeg siap (32-bit/64-bit)"
                    )
                }
                refreshDownloadedFiles()
                performSearch(categories.first().second, updateInput = false)
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        engineReady = false,
                        isLoadingFeed = false,
                        engineStatusText = "Gagal inisialisasi: ${err.message}",
                        feedError = "Mesin yt-dlp gagal dimulai: ${err.message}"
                    )
                }
            }
        }
    }

    fun selectTab(tab: NavTab) {
        _uiState.update { it.copy(activeTab = tab) }
        if (tab == NavTab.TRENDING) {
            performSearch("youtube trending indonesia 2026", updateInput = false)
        } else if (tab == NavTab.DOWNLOADS) {
            refreshDownloadedFiles()
        }
    }

    fun updateSearchQuery(newQuery: String) {
        _uiState.update { it.copy(searchQuery = newQuery) }
    }

    fun selectCategory(label: String, query: String) {
        _uiState.update { it.copy(selectedCategory = label, searchQuery = "") }
        performSearch(query, updateInput = false)
    }

    fun performSearch(query: String, updateInput: Boolean = true) {
        val clean = query.trim()
        if (clean.isEmpty()) return
        if (updateInput) {
            _uiState.update { it.copy(searchQuery = clean, activeTab = NavTab.HOME) }
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoadingFeed = true, feedError = null) }
            val result = engine.searchYouTube(clean, limit = 15)
            result.onSuccess { list ->
                _uiState.update {
                    it.copy(
                        isLoadingFeed = false,
                        feedVideos = list,
                        feedError = if (list.isEmpty()) "Tidak ada video ditemukan untuk "$clean"" else null
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isLoadingFeed = false,
                        feedError = "Gagal memuat video: ${err.localizedMessage ?: "Periksa koneksi internet"}"
                    )
                }
            }
        }
    }

    fun openAndPlayVideo(video: VideoItem, audioOnlyMode: Boolean = false) {
        resolveJob?.cancel()
        resolveJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isResolvingStream = true,
                    isPlayerExpanded = true,
                    snackbarMessage = null
                )
            }
            val result = engine.resolveStream(video)
            result.onSuccess { resolved ->
                val chosen = if (audioOnlyMode) {
                    resolved.qualities.firstOrNull { it.isAudioOnly } ?: resolved.defaultQuality
                } else {
                    resolved.defaultQuality
                }
                PlayerHolder.playStream(getApplication(), resolved.videoItem, chosen, 0L)
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        activeStream = resolved,
                        activeQuality = chosen,
                        isPlayerExpanded = true
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        isPlayerExpanded = it.activeStream != null,
                        snackbarMessage = "Gagal memutar video: ${err.localizedMessage ?: "Error"}"
                    )
                }
            }
        }
    }

    fun openDirectUrl(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) return
        val stub = VideoItem(
            id = "direct",
            title = "Memuat video dari tautan...",
            channelName = "YouTube",
            thumbnailUrl = "",
            durationText = "",
            viewCountText = "",
            uploadDateText = "",
            webpageUrl = clean
        )
        openAndPlayVideo(stub)
    }

    fun switchQuality(quality: StreamQualityOption) {
        val stream = _uiState.value.activeStream ?: return
        val player = PlayerHolder.getOrCreatePlayer(getApplication())
        val currentPos = player.currentPosition.coerceAtLeast(0L)
        PlayerHolder.playStream(getApplication(), stream.videoItem, quality, currentPos)
        _uiState.update {
            it.copy(
                activeQuality = quality,
                snackbarMessage = "Resolusi diubah ke ${quality.label}"
            )
        }
    }

    fun setPlayerExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isPlayerExpanded = expanded) }
    }

    fun setPipMode(inPip: Boolean) {
        _uiState.update { it.copy(isInPipMode = inPip) }
    }

    fun closePlayer() {
        val player = PlayerHolder.getOrCreatePlayer(getApplication())
        player.stop()
        player.clearMediaItems()
        _uiState.update {
            it.copy(
                activeStream = null,
                activeQuality = null,
                isPlayerExpanded = false
            )
        }
    }

    fun startDownload(video: VideoItem, format: DownloadFormat) {
        val processId = "dl_${UUID.randomUUID().toString().take(8)}"
        val newTask = DownloadTask(
            processId = processId,
            title = video.title,
            thumbnailUrl = video.thumbnailUrl,
            formatLabel = format.label,
            status = DownloadStatus.DOWNLOADING
        )
        _uiState.update {
            it.copy(
                downloads = listOf(newTask) + it.downloads,
                snackbarMessage = "Mulai mengunduh (${format.label})..."
            )
        }

        viewModelScope.launch {
            val result = engine.downloadMedia(
                url = video.webpageUrl,
                format = format,
                processId = processId
            ) { progress, eta ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId && task.status == DownloadStatus.DOWNLOADING) {
                                task.copy(progress = progress, etaSeconds = eta)
                            } else task
                        }
                    )
                }
            }

            result.onSuccess { file ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId) {
                                task.copy(
                                    progress = 100f,
                                    status = DownloadStatus.COMPLETED,
                                    outputPath = file.absolutePath
                                )
                            } else task
                        },
                        snackbarMessage = "Unduhan selesai: ${file.name}"
                    )
                }
                refreshDownloadedFiles()
            }.onFailure { err ->
                _uiState.update { state ->
                    state.copy(
                        downloads = state.downloads.map { task ->
                            if (task.processId == processId && task.status != DownloadStatus.CANCELLED) {
                                task.copy(
                                    status = DownloadStatus.FAILED,
                                    errorMessage = err.localizedMessage ?: "Unduhan gagal"
                                )
                            } else task
                        },
                        snackbarMessage = "Unduhan gagal: ${err.localizedMessage ?: "Error"}"
                    )
                }
            }
        }
    }

    fun cancelDownload(processId: String) {
        engine.cancelDownload(processId)
        _uiState.update { state ->
            state.copy(
                downloads = state.downloads.map { task ->
                    if (task.processId == processId) {
                        task.copy(status = DownloadStatus.CANCELLED)
                    } else task
                },
                snackbarMessage = "Unduhan dibatalkan"
            )
        }
    }

    fun refreshDownloadedFiles() {
        val files = engine.listDownloadedFiles()
        _uiState.update { it.copy(downloadedFiles = files) }
    }

    fun playLocalFile(downloaded: DownloadedFile) {
        val file = File(downloaded.path)
        if (!file.exists()) {
            _uiState.update { it.copy(snackbarMessage = "File tidak ditemukan") }
            refreshDownloadedFiles()
            return
        }
        PlayerHolder.playLocalFile(getApplication(), file)
        val localItem = VideoItem(
            id = downloaded.name,
            title = file.nameWithoutExtension,
            channelName = "Unduhan Lokal (Offline)",
            thumbnailUrl = "",
            durationText = "",
            viewCountText = YtDlpEngine.formatBytes(downloaded.sizeBytes),
            uploadDateText = "Offline",
            webpageUrl = downloaded.path
        )
        val localQuality = StreamQualityOption(
            id = "local",
            label = if (downloaded.isAudio) "Audio Lokal" else "Video Lokal",
            height = 720,
            fps = null,
            videoUrl = downloaded.path,
            audioUrl = null,
            isAudioOnly = downloaded.isAudio,
            isMuxed = true
        )
        _uiState.update {
            it.copy(
                activeStream = ResolvedStream(
                    videoItem = localItem,
                    description = "Diputar langsung dari penyimpanan: ${downloaded.path}",
                    qualities = listOf(localQuality),
                    defaultQuality = localQuality
                ),
                activeQuality = localQuality,
                isPlayerExpanded = true
            )
        }
    }

    fun deleteLocalFile(downloaded: DownloadedFile) {
        if (engine.deleteDownloadedFile(downloaded.path)) {
            refreshDownloadedFiles()
            _uiState.update { it.copy(snackbarMessage = "File dihapus") }
        }
    }

    fun updateYtDlp() {
        if (_uiState.value.isUpdatingYtDlp) return
        viewModelScope.launch {
            _uiState.update { it.copy(isUpdatingYtDlp = true, snackbarMessage = "Memeriksa pembaruan yt-dlp...") }
            val result = engine.updateBinary()
            _uiState.update {
                it.copy(
                    isUpdatingYtDlp = false,
                    snackbarMessage = result.getOrElse { err -> "Gagal memperbarui: ${err.localizedMessage}" }
                )
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
