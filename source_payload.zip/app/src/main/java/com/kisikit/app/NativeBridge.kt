package com.kisikit.app

object NativeBridge {
    init {
        System.loadLibrary("kisikit_core")
    }

    /**
     * Starts the embedded Rust Axum+Tokio engine bound to 127.0.0.1:0.
     * Safe to call multiple times; returns the already-bound port if running,
     * or -1 if initialization fails.
     */
    external fun startServer(dataDir: String): Int
}
