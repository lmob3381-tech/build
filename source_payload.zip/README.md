# KisiKit Android (Flutter Native On-Device)

Aplikasi Android native **KisiKit - Belajar Cepat & Kuis CBT Sebelum Ujian** berbasis **Flutter** yang berjalan **100% langsung di HP** tanpa VPS, tanpa Termux, dan tanpa Python.

## Kenapa Versi Flutter Ini Lebih Stabil?
- **Build Resmi Flutter AOT (32-bit & 64-bit)**: Memakai `flutter create --platforms=android` langsung di GitHub Actions sehingga konfigurasi Gradle, Kotlin, dan engine native (`libflutter.so` + `libapp.so`) selalu sinkron dan tidak force close.
- **UI 100% Identik**: Mempertahankan seluruh tampilan KisiKit (mode terang/gelap, animasi GSAP/Lenis/Motion, CBT 7 menit, Daftar Soal drawer, cheat sheet, jebakan ujian) dengan tambahan tombol **API Key Google AI Studio** di pojok kanan atas.
- **Tanpa VPS**: Engine Dart (`dart:io` `HttpServer` di `127.0.0.1` + `http`) berkomunikasi langsung dari HP ke `generativelanguage.googleapis.com` dengan rotasi multi-API key, fallback 8 model otomatis, pembuatan 15 PG + 5 Essay paralel, dan parser PDF/DOCX/TXT/Gambar on-device.

## Cara Build APK 32-bit & 64-bit di GitHub Actions
1. Ekstrak arsip ini dan push seluruh isinya ke repository GitHub (branch `main` atau `master`).
2. Buka tab **Actions** -> workflow **Build KisiKit Flutter Android APK (32-bit & 64-bit)** akan berjalan otomatis (atau klik **Run workflow**).
3. Unduh artifact **KisiKit-Flutter-Android-APKs** yang berisi:
   - `KisiKit-32bit-armeabi-v7a.apk` (Android 32-bit)
   - `KisiKit-64bit-arm64-v8a.apk` (Android 64-bit modern)
   - `KisiKit-universal.apk` (gabungan 32-bit + 64-bit)
   - `SHA256SUMS.txt`

## Cara Pemakaian di HP
1. Instal APK sesuai arsitektur HP (`arm64-v8a` untuk HP 64-bit, `armeabi-v7a` untuk HP 32-bit).
2. Buka **KisiKit**, ketuk **ikon kunci** di pojok kanan atas, masukkan 1 atau beberapa API Key dari `https://aistudio.google.com/apikey`, lalu klik **Simpan API Key**.
3. Tempel kisi-kisi atau unggah file PDF/DOCX/TXT/MD/Foto dan mulai belajar.
