# StreamTube (Android 32-bit & 64-bit Video Streamer)

Aplikasi Android native berbasis **Kotlin + Jetpack Compose**, **yt-dlp**, **FFmpeg**, **Aria2c**, dan **AndroidX Media3 ExoPlayer** yang dirancang ringan, mulus (60fps), ikon serba rounded, dan mendukung penuh perangkat **32-bit (`armeabi-v7a`)** mulai Android 7.0 (API 24) hingga Android 15 (API 35).

## Fitur Utama
- **Support 32-bit (`armeabi-v7a`) & 64-bit (`arm64-v8a`)** dengan ABI Splits otomatis sehingga ukuran APK 32-bit jauh lebih kecil dan hemat RAM.
- **YouTube Default + Pencarian Cepat**: Menggunakan `yt-dlp --flat-playlist` untuk pencarian responsif, lengkap dengan saran kategori, riwayat pencarian, dan dukungan tempel URL langsung.
- **Pemutar Video Stabil (Media3 ExoPlayer)**: Mendukung progressive stream & DASH adaptive (`MergingMediaSource` untuk video 720p/1080p+ + audio sinkron).
- **Atur Resolusi Real-Time**: Pilih 144p, 240p, 360p, 480p, 720p, 1080p+, atau Audio Saja tanpa mengulang posisi video.
- **Play Latar Belakang (Background Playback)**: Menggunakan `MediaSessionService` Foreground Service sehingga audio/video tetap berjalan saat layar mati atau pindah aplikasi.
- **Floating Mode (Picture-in-Picture & In-App MiniPlayer)**: Jendela melayang PiP 16:9 dengan tombol kontrol, serta mini-player mengambang di dalam aplikasi.
- **Download Video (MP4) & Audio (MP3)**: Pengunduhan multi-kualitas berbasis `yt-dlp` + muxing otomatis via `FFmpeg` bawaan, tersimpan di `Download/StreamTube/`, lengkap dengan progress real-time & pemutar offline.
- **Update yt-dlp dari Dalam Aplikasi**: Cukup ketuk tombol perbarui di tab Info/Unduhan kapan pun YouTube mengubah algoritma.

## Cara Build APK di GitHub Actions
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder proyek ini ke repository tersebut (`main` atau `master`).
3. Buka tab **Actions** di GitHub — workflow **Build StreamTube APK (32-bit & 64-bit)** akan berjalan otomatis (atau klik **Run workflow**).
4. Setelah selesai (~3–5 menit), unduh hasil build di bagian **Artifacts**:
   - `StreamTube-32bit-armeabi-v7a` → untuk HP Android 32-bit
   - `StreamTube-64bit-arm64-v8a` → untuk HP Android 64-bit
   - `StreamTube-universal` → cocok untuk semua perangkat
