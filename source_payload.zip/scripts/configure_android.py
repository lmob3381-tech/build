#!/usr/bin/env python3
"""Configure generated Flutter Android project for KisiKit (loopback 127.0.0.1, permissions, label, icon)."""
from pathlib import Path
import re

android_dir = Path("android")
main_dir = android_dir / "app" / "src" / "main"
manifest_path = main_dir / "AndroidManifest.xml"
res_dir = main_dir / "res"

# 1. Write network_security_config.xml allowing cleartext strictly for 127.0.0.1
xml_dir = res_dir / "xml"
xml_dir.mkdir(parents=True, exist_ok=True)
(xml_dir / "network_security_config.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">localhost</domain>
    </domain-config>
</network-security-config>
''',
    encoding="utf-8",
)

# 2. Patch AndroidManifest.xml cleanly
manifest = manifest_path.read_text(encoding="utf-8")

if "android.permission.INTERNET" not in manifest:
    manifest = manifest.replace(
        "<application",
        '    <uses-permission android:name="android.permission.INTERNET" />\n'
        '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\n\n'
        '    <application',
        1,
    )

manifest = re.sub(r'android:label="[^"]*"', 'android:label="KisiKit"', manifest, count=1)

if "android:networkSecurityConfig" not in manifest:
    manifest = manifest.replace(
        "<application",
        '<application\n        android:networkSecurityConfig="@xml/network_security_config"\n        android:usesCleartextTraffic="true"',
        1,
    )

if 'android:scheme="https"' not in manifest:
    https_intent = (
        '        <intent>\n'
        '            <action android:name="android.intent.action.VIEW" />\n'
        '            <data android:scheme="https" />\n'
        '        </intent>\n'
    )
    if "<queries>" in manifest:
        manifest = manifest.replace("<queries>", "<queries>\n" + https_intent, 1)
    else:
        manifest = manifest.replace("</manifest>", f"    <queries>\n{https_intent}    </queries>\n</manifest>", 1)

manifest_path.write_text(manifest, encoding="utf-8")

# 3. Install KisiKit brand vector icon (works on Android 5 through 15)
drawable_dir = res_dir / "drawable"
drawable_dir.mkdir(parents=True, exist_ok=True)
(drawable_dir / "ic_kisikit_fg.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#2563EB"
        android:pathData="M0,0h108v108h-108z" />
    <group
        android:translateX="27"
        android:translateY="27"
        android:scaleX="2.25"
        android:scaleY="2.25">
        <path
            android:pathData="M4,19.5A2.5,2.5 0 0,1 6.5,17H20"
            android:strokeWidth="2.3"
            android:strokeColor="#FFFFFF"
            android:strokeLineCap="round"
            android:strokeLineJoin="round" />
        <path
            android:pathData="M6.5,2H20v20H6.5A2.5,2.5 0 0,1 4,19.5v-15A2.5,2.5 0 0,1 6.5,2z"
            android:strokeWidth="2.3"
            android:strokeColor="#FFFFFF"
            android:strokeLineCap="round"
            android:strokeLineJoin="round" />
        <path
            android:pathData="M10,8h6"
            android:strokeWidth="2.3"
            android:strokeColor="#FFFFFF"
            android:strokeLineCap="round"
            android:strokeLineJoin="round" />
        <path
            android:pathData="M10,12h4"
            android:strokeWidth="2.3"
            android:strokeColor="#FFFFFF"
            android:strokeLineCap="round"
            android:strokeLineJoin="round" />
    </group>
</vector>
''',
    encoding="utf-8",
)

values_dir = res_dir / "values"
values_dir.mkdir(parents=True, exist_ok=True)
(values_dir / "ic_kisikit_bg.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_kisikit_bg">#2563EB</color>
</resources>
''',
    encoding="utf-8",
)

anydpi_v26 = res_dir / "mipmap-anydpi-v26"
anydpi_v26.mkdir(parents=True, exist_ok=True)
(anydpi_v26 / "ic_launcher.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_kisikit_bg" />
    <foreground android:drawable="@drawable/ic_kisikit_fg" />
</adaptive-icon>
''',
    encoding="utf-8",
)


# 4. Disable lintVital tasks on subprojects (prevents AGP Lint JDK 17 vs JDK 21 List.removeLast NoSuchMethodError)
root_kts = android_dir / "build.gradle.kts"
if root_kts.exists():
    kts_txt = root_kts.read_text(encoding="utf-8")
    if "lintVital" not in kts_txt:
        kts_txt += (
            '\nsubprojects {\n'
            '    tasks.configureEach {\n'
            '        if (name.contains("lintVital", ignoreCase = true)) {\n'
            '            enabled = false\n'
            '        }\n'
            '    }\n'
            '}\n'
        )
        root_kts.write_text(kts_txt, encoding="utf-8")

root_groovy = android_dir / "build.gradle"
if root_groovy.exists():
    g_txt = root_groovy.read_text(encoding="utf-8")
    if "lintVital" not in g_txt:
        g_txt += (
            '\nsubprojects {\n'
            '    tasks.configureEach { task ->\n'
            '        if (task.name.toLowerCase().contains("lintvital")) {\n'
            '            task.enabled = false\n'
            '        }\n'
            '    }\n'
            '}\n'
        )
        root_groovy.write_text(g_txt, encoding="utf-8")

print("[OK] Configured AndroidManifest.xml, network_security_config.xml, and KisiKit launcher icon.")
