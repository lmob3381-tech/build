#!/usr/bin/env python3
"""Configure generated Flutter Android project for KisiKit by Ilmi:
- Loopback 127.0.0.1 cleartext network security config
- Aesthetic launcher icon (legacy mipmaps + Android 8+ adaptive icon + status bar icon)
- Matching dark midnight native launch_background.xml
- Scheduled study reminder notifications (29 Nov - 4 Des 2026, 19:00 WIB) in Android notification bar
- Disable lintVital tasks for JDK 17 compatibility
"""
from pathlib import Path
import re
import shutil

project_dir = Path.cwd()
android_dir = project_dir / "android"
main_dir = android_dir / "app" / "src" / "main"
manifest_path = main_dir / "AndroidManifest.xml"
res_dir = main_dir / "res"
brand_dir = project_dir / "assets" / "branding"

# 1. Write network_security_config.xml allowing cleartext strictly for 127.0.0.1
xml_dir = res_dir / "xml"
xml_dir.mkdir(parents=True, exist_ok=True)
(xml_dir / "network_security_config.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">127.0.0.1</domain>
        <domain includeSubdomains="false">localhost</domain>
    </domain-config>
</network-security-config>
''',
    encoding="utf-8",
)

# 2. Patch AndroidManifest.xml cleanly (permissions, label, cleartext, receivers)
manifest = manifest_path.read_text(encoding="utf-8")

required_permissions = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.SCHEDULE_EXACT_ALARM",
]
perm_lines = []
for perm in required_permissions:
    if perm not in manifest:
        perm_lines.append(f'    <uses-permission android:name="{perm}" />')

if perm_lines:
    manifest = manifest.replace(
        "<application",
        "\n".join(perm_lines) + "\n\n    <application",
        1,
    )

manifest = re.sub(r'android:label="[^"]*"', 'android:label="KisiKit"', manifest, count=1)

if "android:networkSecurityConfig" not in manifest:
    manifest = manifest.replace(
        "<application",
        '<application\n        android:networkSecurityConfig="@xml/network_security_config"\n        android:usesCleartextTraffic="true"',
        1,
    )

if "StudyReminderReceiver" not in manifest:
    receivers_xml = '''
        <receiver
            android:name=".StudyReminderReceiver"
            android:exported="false" />

        <receiver
            android:name=".StudyReminderBootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
        </receiver>
    </application>'''
    manifest = manifest.replace("</application>", receivers_xml, 1)

if 'android:scheme="https"' not in manifest:
    https_intent = (
        '        <intent>\n'
        '            <action android:name="android.intent.action.VIEW" />\n'
        '            <data android:scheme="https" />\n'
        '        </intent>\n'
    )
    if "<queries>" in manifest:
        manifest = manifest.replace("<queries>", "<queries>\n" + https_intent, 1)
    else:
        manifest = manifest.replace("</manifest>", f"    <queries>\n{https_intent}    </queries>\n</manifest>", 1)

manifest_path.write_text(manifest, encoding="utf-8")

# 3. Install KisiKit by Ilmi aesthetic app icons (legacy mipmaps + adaptive icon + status bar icon)
drawable_dir = res_dir / "drawable"
drawable_dir.mkdir(parents=True, exist_ok=True)
old_vec = drawable_dir / "ic_kisikit_fg.xml"
if old_vec.exists():
    old_vec.unlink()

# Copy legacy mipmap PNGs
for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
    src_icon = brand_dir / f"mipmap-{density}" / "ic_launcher.png"
    dst_dir = res_dir / f"mipmap-{density}"
    dst_dir.mkdir(parents=True, exist_ok=True)
    if src_icon.exists():
        shutil.copy2(src_icon, dst_dir / "ic_launcher.png")

# Copy adaptive foreground PNG
fg_src = brand_dir / "adaptive" / "ic_launcher_foreground.png"
drawable_xxxhdpi = res_dir / "drawable-xxxhdpi"
drawable_xxxhdpi.mkdir(parents=True, exist_ok=True)
if fg_src.exists():
    shutil.copy2(fg_src, drawable_xxxhdpi / "ic_kisikit_fg.png")

values_dir = res_dir / "values"
values_dir.mkdir(parents=True, exist_ok=True)
(values_dir / "ic_kisikit_bg.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_kisikit_bg">#0B1136</color>
</resources>
''',
    encoding="utf-8",
)

anydpi_v26 = res_dir / "mipmap-anydpi-v26"
anydpi_v26.mkdir(parents=True, exist_ok=True)
(anydpi_v26 / "ic_launcher.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_kisikit_bg" />
    <foreground android:drawable="@drawable/ic_kisikit_fg" />
</adaptive-icon>
''',
    encoding="utf-8",
)

# Crisp monochrome vector icon for Android status bar notification
(drawable_dir / "ic_stat_kisikit.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M4,5.5L9.5,7.8V19.5L4,17.2V5.5Z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M11,8.5C11,5.6 13.4,3.4 16.5,3V9.2C14.1,9.7 12.2,11.2 11,13.1V8.5Z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M11,14.8L16.2,9.8H19.4L14.2,14.8L19.6,19.8H16.3L12.6,16.2L11,17.7V19.8H9.5V14.8H11Z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,2L19.7,4.1L21.8,4.8L19.7,5.5L19,7.6L18.3,5.5L16.2,4.8L18.3,4.1L19,2Z" />
</vector>
''',
    encoding="utf-8",
)

# Matching dark midnight native cold-start launch background (no white flash)
launch_bg_xml = '''<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item>
        <color android:color="#090F2A" />
    </item>
</layer-list>
'''
(drawable_dir / "launch_background.xml").write_text(launch_bg_xml, encoding="utf-8")
drawable_v21 = res_dir / "drawable-v21"
drawable_v21.mkdir(parents=True, exist_ok=True)
(drawable_v21 / "launch_background.xml").write_text(launch_bg_xml, encoding="utf-8")

# 4. Install native Kotlin study reminder notification scheduler (29 Nov - 4 Des 2026, 19:00 WIB)
kotlin_root = main_dir / "kotlin"
main_activities = list(kotlin_root.rglob("MainActivity.kt"))
if main_activities:
    main_act_path = main_activities[0]
    pkg_dir = main_act_path.parent
    existing_act = main_act_path.read_text(encoding="utf-8")
    pkg_match = re.search(r'^\s*package\s+([a-zA-Z0-9_.]+)', existing_act, re.MULTILINE)
    pkg_name = pkg_match.group(1) if pkg_match else "com.kisikit.kisikit"

    (pkg_dir / "StudyReminderScheduler.kt").write_text(
        f'''package {pkg_name}

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import java.util.TimeZone

object StudyReminderScheduler {{
    const val CHANNEL_ID = "kisikit_study_reminders"
    const val CHANNEL_NAME = "Pengingat Belajar KisiKit"
    const val EXTRA_NOTIF_ID = "notif_id"
    const val EXTRA_TITLE = "notif_title"
    const val EXTRA_BODY = "notif_body"

    private data class ReminderSpec(
        val id: Int,
        val year: Int,
        val monthZeroBased: Int,
        val day: Int,
        val title: String,
        val body: String
    )

    // Jadwal pengingat belajar: Minggu 29 November 2026 s/d Jumat 4 Desember 2026 pukul 19:00 WIB
    private val SCHEDULE = listOf(
        ReminderSpec(
            id = 261129,
            year = 2026,
            monthZeroBased = Calendar.NOVEMBER,
            day = 29,
            title = "Waktunya Belajar di KisiKit!",
            body = "Minggu 19.00 WIB — Yuk mulai cicil rangkuman kisi-kisi & latihan kuis CBT 7 menit malam ini."
        ),
        ReminderSpec(
            id = 261130,
            year = 2026,
            monthZeroBased = Calendar.NOVEMBER,
            day = 30,
            title = "Pengingat Belajar Malam Ini",
            body = "Senin 19.00 WIB — Buka KisiKit, review catatan inti, dan uji pemahamanmu lewat kuis CBT."
        ),
        ReminderSpec(
            id = 261201,
            year = 2026,
            monthZeroBased = Calendar.DECEMBER,
            day = 1,
            title = "Saatnya Latihan KisiKit!",
            body = "Selasa 19.00 WIB — Luangkan 7 menit untuk latihan soal biar makin siap hadapi ujian."
        ),
        ReminderSpec(
            id = 261202,
            year = 2026,
            monthZeroBased = Calendar.DECEMBER,
            day = 2,
            title = "Jangan Lupa Belajar Malam Ini",
            body = "Rabu 19.00 WIB — Cek cheat sheet & jebakan ujian di KisiKit supaya tidak terkecoh soal."
        ),
        ReminderSpec(
            id = 261203,
            year = 2026,
            monthZeroBased = Calendar.DECEMBER,
            day = 3,
            title = "Waktunya Review Kisi-Kisi!",
            body = "Kamis 19.00 WIB — Sedikit lagi! Mantapkan materi di KisiKit dengan satu paket kuis baru."
        ),
        ReminderSpec(
            id = 261204,
            year = 2026,
            monthZeroBased = Calendar.DECEMBER,
            day = 4,
            title = "Sesi Belajar Terakhir Minggu Ini",
            body = "Jumat 19.00 WIB — Tutup pekan belajarmu dengan review cepat & kuis CBT di KisiKit. Semangat!"
        )
    )

    fun ensureChannel(context: Context) {{
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {{
                description = "Notifikasi pengingat belajar rutin pukul 19.00 WIB dari KisiKit"
                enableVibration(true)
            }}
            manager.createNotificationChannel(channel)
        }}
    }}

    fun scheduleAll(context: Context): Int {{
        ensureChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            ?: return 0
        val wibZone = TimeZone.getTimeZone("Asia/Jakarta")
        val nowMs = System.currentTimeMillis()
        var scheduledCount = 0

        for (spec in SCHEDULE) {{
            val cal = Calendar.getInstance(wibZone).apply {{
                set(Calendar.YEAR, spec.year)
                set(Calendar.MONTH, spec.monthZeroBased)
                set(Calendar.DAY_OF_MONTH, spec.day)
                set(Calendar.HOUR_OF_DAY, 19)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }}
            val triggerAtMs = cal.timeInMillis
            if (triggerAtMs <= nowMs) {{
                continue
            }}

            val intent = Intent(context, StudyReminderReceiver::class.java).apply {{
                putExtra(EXTRA_NOTIF_ID, spec.id)
                putExtra(EXTRA_TITLE, spec.title)
                putExtra(EXTRA_BODY, spec.body)
            }}

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
            val pendingIntent = PendingIntent.getBroadcast(context, spec.id, intent, flags)

            try {{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {{
                    if (alarmManager.canScheduleExactAlarms()) {{
                        alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMs,
                            pendingIntent
                        )
                    }} else {{
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMs,
                            pendingIntent
                        )
                    }}
                }} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {{
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMs,
                        pendingIntent
                    )
                }} else {{
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMs,
                        pendingIntent
                    )
                }}
                scheduledCount++
            }} catch (_: SecurityException) {{
                try {{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {{
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMs,
                            pendingIntent
                        )
                    }} else {{
                        alarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMs,
                            pendingIntent
                        )
                    }}
                    scheduledCount++
                }} catch (_: Exception) {{
                }}
            }}
        }}
        return scheduledCount
    }}
}}
''',
        encoding="utf-8",
    )

    (pkg_dir / "StudyReminderReceiver.kt").write_text(
        f'''package {pkg_name}

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class StudyReminderReceiver : BroadcastReceiver() {{
    override fun onReceive(context: Context, intent: Intent) {{
        StudyReminderScheduler.ensureChannel(context)
        val notifId = intent.getIntExtra(StudyReminderScheduler.EXTRA_NOTIF_ID, 261129)
        val title = intent.getStringExtra(StudyReminderScheduler.EXTRA_TITLE)
            ?: "Waktunya Belajar di KisiKit!"
        val body = intent.getStringExtra(StudyReminderScheduler.EXTRA_BODY)
            ?: "Yuk buka KisiKit dan latihan kuis CBT 7 menit malam ini."

        val openIntent = Intent(context, MainActivity::class.java).apply {{
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }}
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val contentIntent = PendingIntent.getActivity(context, notifId, openIntent, piFlags)

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            Notification.Builder(context, StudyReminderScheduler.CHANNEL_ID)
        }} else {{
            @Suppress("DEPRECATION")
            Notification.Builder(context)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
        }}

        val notification = builder
            .setSmallIcon(R.drawable.ic_stat_kisikit)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(notifId, notification)
    }}
}}
''',
        encoding="utf-8",
    )

    (pkg_dir / "StudyReminderBootReceiver.kt").write_text(
        f'''package {pkg_name}

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StudyReminderBootReceiver : BroadcastReceiver() {{
    override fun onReceive(context: Context, intent: Intent) {{
        StudyReminderScheduler.scheduleAll(context)
    }}
}}
''',
        encoding="utf-8",
    )

    main_act_path.write_text(
        f'''package {pkg_name}

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    companion object {{
        private const val NOTIF_CHANNEL = "com.kisikit/notifications"
        private const val REQ_POST_NOTIFICATIONS = 1001
    }}

    override fun onCreate(savedInstanceState: Bundle?) {{
        super.onCreate(savedInstanceState)
        StudyReminderScheduler.ensureChannel(this)
        requestNotificationPermissionIfNeeded()
        StudyReminderScheduler.scheduleAll(this)
    }}

    private fun requestNotificationPermissionIfNeeded() {{
        if (Build.VERSION.SDK_INT >= 33) {{
            val perm = "android.permission.POST_NOTIFICATIONS"
            if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {{
                requestPermissions(arrayOf(perm), REQ_POST_NOTIFICATIONS)
            }}
        }}
    }}

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NOTIF_CHANNEL)
            .setMethodCallHandler {{ call, result ->
                when (call.method) {{
                    "ensureScheduled" -> {{
                        val count = StudyReminderScheduler.scheduleAll(this)
                        result.success(count)
                    }}
                    else -> result.notImplemented()
                }}
            }}
    }}
}}
''',
        encoding="utf-8",
    )

# 5. Disable lintVital tasks on subprojects (prevents AGP Lint JDK 17 vs JDK 21 List.removeLast NoSuchMethodError)
root_kts = android_dir / "build.gradle.kts"
if root_kts.exists():
    kts_txt = root_kts.read_text(encoding="utf-8")
    if "lintVital" not in kts_txt:
        kts_txt += (
            '\nsubprojects {\n'
            '    tasks.configureEach {\n'
            '        if (name.contains("lintVital", ignoreCase = true)) {\n'
            '            enabled = false\n'
            '        }\n'
            '    }\n'
            '}\n'
        )
        root_kts.write_text(kts_txt, encoding="utf-8")

root_groovy = android_dir / "build.gradle"
if root_groovy.exists():
    g_txt = root_groovy.read_text(encoding="utf-8")
    if "lintVital" not in g_txt:
        g_txt += (
            '\nsubprojects {\n'
            '    tasks.configureEach { task ->\n'
            '        if (task.name.toLowerCase().contains("lintvital")) {\n'
            '            task.enabled = false\n'
            '        }\n'
            '    }\n'
            '}\n'
        )
        root_groovy.write_text(g_txt, encoding="utf-8")

print("[OK] Configured AndroidManifest, aesthetic KisiKit by Ilmi icons, dark launch screen, and 29 Nov - 4 Des 19:00 WIB notifications.")
