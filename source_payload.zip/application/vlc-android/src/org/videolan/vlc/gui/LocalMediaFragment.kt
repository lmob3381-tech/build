/*
 * Unified Local Media Fragment for LelePlay
 * Groups local Audio (Lagu) and local Video into dedicated tabs under the "Local" bottom menu.
 */
package org.videolan.vlc.gui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.view.ActionMode
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import org.videolan.vlc.R
import org.videolan.vlc.gui.audio.AudioBrowserFragment
import org.videolan.vlc.gui.video.VideoBrowserFragment

class LocalMediaFragment : BaseFragment() {

    override fun getTitle(): String = getString(R.string.nav_local)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_local_media, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabLayout = view.findViewById<TabLayout>(R.id.local_tab_layout)
        val viewPager = view.findViewById<ViewPager2>(R.id.local_view_pager)

        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 2
            override fun createFragment(position: Int): Fragment {
                return if (position == 0) AudioBrowserFragment() else VideoBrowserFragment()
            }
        }

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = if (position == 0) getString(R.string.local_tab_music) else getString(R.string.local_tab_video)
        }.attach()
    }

    override fun onStart() {
        super.onStart()
        (activity as? ContentActivity)?.setTabLayoutVisibility(false)
    }

    override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean = false
    override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean = false
    override fun onDestroyActionMode(mode: ActionMode?) {}
}
