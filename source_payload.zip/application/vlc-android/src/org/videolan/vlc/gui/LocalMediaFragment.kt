/*
 * Unified Local Media Fragment for LelePlay
 * Hosts AudioBrowserFragment (Lagu) and VideoBrowserFragment (Video) one at a time
 * so MainActivity's sliding_tabs and fast scroller attach cleanly without NPE or tab collision.
 */
package org.videolan.vlc.gui

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.view.ActionMode
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import org.videolan.vlc.R
import org.videolan.vlc.gui.audio.AudioBrowserFragment
import org.videolan.vlc.gui.video.VideoBrowserFragment

class LocalMediaFragment : BaseFragment() {

    private lateinit var btnMusic: MaterialButton
    private lateinit var btnVideo: MaterialButton
    private var showingVideo: Boolean = false

    override fun getTitle(): String = getString(R.string.nav_local)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_local_media, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnMusic = view.findViewById(R.id.local_btn_music)
        btnVideo = view.findViewById(R.id.local_btn_video)

        showingVideo = savedInstanceState?.getBoolean(KEY_SHOWING_VIDEO, false) ?: false

        btnMusic.setOnClickListener {
            if (showingVideo) showChild(video = false)
        }
        btnVideo.setOnClickListener {
            if (!showingVideo) showChild(video = true)
        }

        if (childFragmentManager.findFragmentById(R.id.local_fragment_container) == null) {
            showChild(video = showingVideo)
        } else {
            updateButtonStyles()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(KEY_SHOWING_VIDEO, showingVideo)
        super.onSaveInstanceState(outState)
    }

    private fun showChild(video: Boolean) {
        showingVideo = video
        updateButtonStyles()
        val fragment: Fragment = if (video) VideoBrowserFragment() else AudioBrowserFragment()
        childFragmentManager.beginTransaction()
            .replace(R.id.local_fragment_container, fragment)
            .commitAllowingStateLoss()
    }

    private fun updateButtonStyles() {
        val orange = Color.parseColor("#FF6D00")
        val white = Color.WHITE
        val borderGray = Color.parseColor("#E0E0E0")
        val strokePx = (1.5f * resources.displayMetrics.density).toInt().coerceAtLeast(2)

        fun applyStyle(button: MaterialButton, active: Boolean) {
            button.alpha = 1.0f
            if (active) {
                button.backgroundTintList = ColorStateList.valueOf(orange)
                button.setTextColor(white)
                button.strokeWidth = 0
                button.strokeColor = ColorStateList.valueOf(Color.TRANSPARENT)
            } else {
                button.backgroundTintList = ColorStateList.valueOf(white)
                button.setTextColor(orange)
                button.strokeWidth = strokePx
                button.strokeColor = ColorStateList.valueOf(borderGray)
            }
        }

        applyStyle(btnMusic, active = !showingVideo)
        applyStyle(btnVideo, active = showingVideo)
    }

    override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean = false
    override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean = false
    override fun onDestroyActionMode(mode: ActionMode?) {}

    companion object {
        private const val KEY_SHOWING_VIDEO = "local_showing_video"
    }
}
