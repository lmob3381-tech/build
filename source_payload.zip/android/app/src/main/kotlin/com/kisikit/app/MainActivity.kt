package com.kisikit.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
